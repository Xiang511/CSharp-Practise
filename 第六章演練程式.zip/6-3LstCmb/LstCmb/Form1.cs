﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LstCmb
{
    public partial class FrmLstCmb : Form
    {
        public FrmLstCmb()
        {
            InitializeComponent();
        }

        private void Lst_SelectedIndexChanged(object sender, EventArgs e)
        {//清單方塊被選項目及索引秀在標籤上
            LblSlctIdx.Text = "SelectedIndex:" + Lst.SelectedIndex;
            LblSlctItm.Text = "SelectedItem:" + Lst.SelectedItem;
        }

        private void BtnMulCol_Click(object sender, EventArgs e)
        {//設定清單方塊多欄屬性，採on-off作法
            Lst.MultiColumn = !Lst.MultiColumn;
        }

        //因兩處處理函式會用到，所以宣告成全域變數
        string[] StrLst = new string[12];//無法用Lst.Items.Count，所以用12，解法得再思考，可能這時清單方塊尚未建立
        bool First = true;//表示是否已排過序之旗標，用於排序前將原順序資料儲存，以便事後的還原
        private void BtnSorted_Click(object sender, EventArgs e)
        {//設定排序屬性，原序資料先儲存
            if (First) { Lst.Items.CopyTo(StrLst, 0); First = false; }//若為第一次排序，把原順序內容存起來以便還原使用
            Lst.Sorted = !Lst.Sorted;//採on-off作法，也示範排序後，再把Sorted設成false並不會還原回原來的順序
            BtnSorted.Text = "Sorted:" + Lst.Sorted;//秀出現在Sorted的屬性
            BtnSortedBack.Enabled = true;//還原鈕原設定為未作動，排序後便作動
        }

        private void BtnSortedBack_Click(object sender, EventArgs e)
        {//排序後還原原序資料
            Lst.Sorted = false;//還原即未排序，故Sorted屬性為false，要先設定，把項目複製回去再設定就來不及了，因為複製回去時是true，它就又排序了
            BtnSorted.Text = "Sorted:" + Lst.Sorted;//秀出現在Sorted的屬性
            Lst.Items.Clear();//清空清單，以便把儲存的陣列加入，未清空會變成有兩份資料
            Lst.Items.AddRange(StrLst);//利用儲存的資料還原清單內容
            BtnSortedBack.Enabled = false;//還原了，就不用再還原
        }

        private void RdbOne_CheckedChanged(object sender, EventArgs e)
        {//用選項按鈕設定清單方塊選擇模式為單選
            if (RdbOne.Checked) Lst.SelectionMode = SelectionMode.One;
        }

        private void RdbNone_CheckedChanged(object sender, EventArgs e)
        {//用選項按鈕設定清單方塊選擇模式為不可選
            if (RdbNone.Checked) Lst.SelectionMode = SelectionMode.None;
        }

        private void RdbMS_CheckedChanged(object sender, EventArgs e)
        {//用選項按鈕設定清單方塊選擇模式為簡單多選，即用滑鼠直接多選
            if (RdbMS.Checked) Lst.SelectionMode = SelectionMode.MultiSimple;
        }

        private void RdbME_CheckedChanged(object sender, EventArgs e)
        {//用選項按鈕設定清單方塊選擇模式為延伸多選，即可用Shift及Ctrl鍵選擇連續或不連續的多個
            if (RdbME.Checked) Lst.SelectionMode = SelectionMode.MultiExtended;
        }

        private void BtnRmv_Click(object sender, EventArgs e)
        {//移除清單方塊內項目，使用文字或索引。使用文字可先用Contains判斷是否存在，若存在才移除。使用索引要判斷是否在範圍內
            string StrIn = Microsoft.VisualBasic.Interaction.InputBox("請輸入要移除的文字");//需要的是字串，可使用InputBox
            if (Lst.Items.Contains(StrIn)) Lst.Items.Remove(StrIn);//有此字串則移除，用Remove
            else MessageBox.Show("清單中未包含「" + StrIn + "」");//否則訊息告知
            do
            {//需要的是整數，要做例外處理，包含是否為整數及是否在範圍內。以下為SOP
                int RmvIdx;//接輸入的整數
                StrIn = Microsoft.VisualBasic.Interaction.InputBox("請輸入要移除項目的索引，0到" + (Lst.Items.Count - 1));
                if (StrIn == "") { MessageBox.Show("輸入空字串或按了取消，將結束此程序返回表單"); return; }
                else
                {
                    try { RmvIdx = Convert.ToInt32(StrIn); }
                    catch { MessageBox.Show("請輸入要移除項目的索引，0到" + (Lst.Items.Count - 1)); continue; }
                }
                if (RmvIdx<0 || RmvIdx>= Lst.Items.Count) MessageBox.Show("請輸入要移除項目的索引，0到" + (Lst.Items.Count - 1));
                else { Lst.Items.RemoveAt(RmvIdx); break; }//輸入數字正常，用RemoveAt
            } while (true);
        }

        private void BtnAdd_Click(object sender, EventArgs e)
        {//示範清單方塊在最後加入或在任意位置插入新項目
            Lst.Items.Add(Microsoft.VisualBasic.Interaction.InputBox("請輸入要加在最後的文字"));//使用Add將輸入直接加在最後
            do
            {//需要的是整數，要做例外處理，包含是否為整數及是否在範圍內。以下為SOP
                int InsertIdx;//Insert的第一個參數為索引值，即項目加入後所在位置，故InsertIdx可以從0到Count
                string StrIn = Microsoft.VisualBasic.Interaction.InputBox("請輸入要插入位置的索引，0到" + Lst.Items.Count);//Lst.Items.Count表插在最後
                if (StrIn == "") { MessageBox.Show("輸入空字串或按了取消，將結束此程序返回表單"); return; }
                else
                {
                    try { InsertIdx = Convert.ToInt32(StrIn); }
                    catch { MessageBox.Show("請輸入要插入位置的索引，0到" + Lst.Items.Count); continue; }
                }
                if (InsertIdx < 0 || InsertIdx > Lst.Items.Count) MessageBox.Show("請輸入要插入位置的索引，0到" + Lst.Items.Count);
                else { Lst.Items.Insert(InsertIdx, Microsoft.VisualBasic.Interaction.InputBox("請輸入要加在索引" + InsertIdx + "位置的文字")); break; }
            } while (true);
        }

        private void BtnSetSlct_Click(object sender, EventArgs e)
        {//示範在清單方塊設定選取某項目或取消選取，可以使用文字或索引
            bool BlStr;//布林變數，存true或false
            string StrAct, StrItm;//選取或取消動作這二個字的字串，選取或取消項目的內容宇串
            int Idx;//選取或取消項目的索引值
            do
            {//輸入要執行的動作，因為字串，所以不用例外處理，但仍要判斷是否是指定的動作(用數字代表)
                string StrIn = Microsoft.VisualBasic.Interaction.InputBox("請選擇選取或取消，輸入：1表選取，0表取消，9表清除全部選取。輸入空白或按取消表跳出此程序");
                if (StrIn == "") { MessageBox.Show("輸入空白或按取消故跳出此程序"); return; }
                else if (StrIn == "1") { BlStr = true; StrAct = "選取"; break; }//依輸入數字決定要做的動作，且設定此動作的字串，以便最後訊息使用
                else if (StrIn == "0") { BlStr = false; StrAct = "取消"; break; }//補充：經測試，在單選模式，即使取消的不是已被選的那一項，原被選依然被取消
                else if (StrIn == "9") { Lst.ClearSelected(); MessageBox.Show("已清除所有選取"); return; }//取消所有選取並返回表單
                else MessageBox.Show("輸入不正確，請重新輸入");//除了指字數字外，要求重新輸入，除非輸入空字串為返回表單
            } while (true);//無窮迴圈，由迴圈內敘述決定走向
            do
            {//輸入數字含例外處理的SOP
                string StrIn = Microsoft.VisualBasic.Interaction.InputBox("請輸入要選取或取消位置的索引，0到" + (Lst.Items.Count-1));//Lst.Items.Count會發生例外，因為超過範圍
                if (StrIn == "") { MessageBox.Show("輸入空字串或按了取消，將結束此程序返回表單"); return; }
                else
                {
                    try { Idx = Convert.ToInt32(StrIn); }
                    catch { MessageBox.Show("請輸入要插入位置的索引，0到" + (Lst.Items.Count - 1)); continue; }
                }
                if (Idx < 0 || Idx >= Lst.Items.Count) MessageBox.Show("請輸入要插入位置的索引，0到" + (Lst.Items.Count - 1));
                else { StrItm = Lst.Items[Idx].ToString(); Lst.SetSelected(Idx, BlStr); break; }
            } while (true);
            MessageBox.Show("已" + StrAct + "項目：" + StrItm + "，索引值為" + Idx);//輸出訊息表示選取或取消哪個項目及索引值
        }

        private void BtnSrch_Click(object sender, EventArgs e)
        {//示範尋找清單方塊內某字串的位置，在此使用新的項目內容，所以先將舊的儲存再還原
            Lst.Items.CopyTo(StrLst, 0);//將清單方塊內容存在陣列StrLst，以便還原使用
            string StrA = "1,12,21,123,23,231,321,312";//新資料字串，Split成陣列，再AddRange到清單方塊
            string[] StrArray = StrA.Split(',');
            Lst.Items.Clear(); Lst.Items.AddRange(StrArray);//清單方塊Clear清空，再用AddRange將整個陣列加入清單方塊，AddRange是加在最後，所以要先清空原來的
            MessageBox.Show("置換成新的內容");

            for (int i = -1; i < 4; i++) MessageBox.Show("LstItms.FindString(\"1\", " + i + ")表找1，從" + (i + 1) + "開始找，傳回索引" + Lst.FindString("1", i));
            //語法：回傳值 = 清單方塊名稱.FindString(字串, 索引);其中回傳值為找到項目的索引。參數索引是指要從下一個開始找，故-1表示從索引0開始找起
            MessageBox.Show("表示有繞回從頭找");//這是加給最後一次搜尋的，因為它用來示範，FindString若從中間找到最後仍未發現，會繞回從頭開始找，直到全部都找過，若沒找到則回傳-1
            //FingString只要開頭相同即可，FingStringExact則要完全一樣才算找到
            MessageBox.Show("LstItms.FindStringExact(\"231\")表找231，從頭開始找，傳回索引" + Lst.FindStringExact("231"));//語法：同FindStringExact(字串, 索引)，其中索引未給表從頭開始找
            MessageBox.Show("LstItms.FindStringExact(\"233\")表找233，從頭開始找，傳回索引" + Lst.FindStringExact("233"));//未找到，會回傳-1

            Lst.Items.Clear();//清空清單，以便把儲存的陣列加入，未清空會變成有兩份資料
            Lst.Items.AddRange(StrLst);//利用儲存的資料還原清單內容
            MessageBox.Show("還原回原內容");
        }

        private void BtnMltSlct_Click(object sender, EventArgs e)
        {//示範多選的結果，包括項目及索引，故需先確定是否為多選模式。當然，若非，仍可以有傳回值
            if (MessageBox.Show("請確定是否已是多選模式","多選確定", MessageBoxButtons.YesNo)==DialogResult.No) { MessageBox.Show("請選擇多選模式"); return; }
            string Idxs = "", Itms = "";//多選的索引及項目先設為空字串，後面再陸續累積串接，給最後輸出的訊息方塊使用
            LblSlctIdx.Text = "SelectedIndexes:";
            LblSlctItm.Text = "SelectedItems:";//設定二個輸出標籤的初值
            bool First = true;//為了加上逗號區隔，使用一個旗標表第一個，因第一個不用加逗號
            foreach (int i in Lst.SelectedIndices)
            {//用foreach將多選的結果一一取出
                Idxs += i.ToString() + "\n";//給最後輸出的訊息方塊使用，ToString亦可不用，會自動轉換型別
                if (First) { LblSlctIdx.Text += i; First = false; }//輸出標籤累串，第一次旗標First為true時不用加逗號，過後要加，所以要變成false
                else LblSlctIdx.Text += ", " + i;
            }
            First = true;
            foreach (string s in Lst.SelectedItems)
            {//用foreach將多選的結果一一取出
                Itms += s + "\n";//給最後輸出的訊息方塊使用
                if (First) { LblSlctItm.Text += s; First = false; }//輸出標籤累串，第一次旗標First為true時不用加逗號，過後要加，所以要變成false
                else LblSlctItm.Text += ", " + s;
            }
            MessageBox.Show("所選索引有：\n" + Idxs + "目前所選項目有：\n" + Itms);//最後輸出的訊息方塊
        }

        private void FrmLstCmb_Load(object sender, EventArgs e)
        {//表單一載入，看DroppedDown一開始的初值
            LblDD.Text += "F" + Cmb.DroppedDown;//串接方式，且加個字母，以便追踪順序
            BtnIH.Text = "IntegralHeight:" + Cmb.IntegralHeight.ToString();//在按鈕上顯示IntegralHeight屬性
            TxtMaxItm.Text = "8";//給定最大下拉項目數初值
            TxtMaxH.Text = "106";//給定下拉高度初值
            TxtSizeH.Text = "12";//給定下拉清單高度補值
        }

        private void Cmb_Click(object sender, EventArgs e)
        {//IntegralHeight原設計時給true，但一點下拉清單，IntegralHeight就變false
            BtnIH.Text = "IntegralHeight:" + Cmb.IntegralHeight.ToString();//在按鈕上顯示IntegralHeight屬性
        }

        private void Cmb_DropDownClosed(object sender, EventArgs e)
        {//下拉收回會觸動，看它是何時動作，排在哪個動作之後
            LblDD.Text += "C" + Cmb.DroppedDown;//串接方式，且加個字母，以便追踪順序
        }

        private void Cmb_DropDown(object sender, EventArgs e)
        {//下拉展開會觸動，看它是何時動作，排在哪個動作之後
            LblDD.Text += "D" + Cmb.DroppedDown;//串接方式，且加個字母，以便追踪順序
        }

        private void RdbDD_CheckedChanged(object sender, EventArgs e)
        {//用選項按鈕決定下拉式清單的下拉樣式，並顯示已下拉DroppedDown的屬性。設定下拉式，DroppedDown定為false
            if (RdbDD.Checked)
            {
                Cmb.DropDownStyle = ComboBoxStyle.DropDown;
                LblDD.Text = "DroppedDown:" + Cmb.DroppedDown;
            }
        }

        private void RdbDDL_CheckedChanged(object sender, EventArgs e)
        {//用選項按鈕決定下拉式清單的下拉樣式，並顯示已下拉DroppedDown的屬性。設定下拉清單式，DroppedDown定為false
            if (RdbDDL.Checked)
            {
                Cmb.DropDownStyle = ComboBoxStyle.DropDownList;
                LblDD.Text = "DroppedDown:" + Cmb.DroppedDown;
            }
        }

        private void RdbSmp_CheckedChanged(object sender, EventArgs e)
        {//用選項按鈕決定下拉式清單的下拉樣式，並顯示已下拉DroppedDown的屬性。設定簡易式，DroppedDown定為true
            if (RdbSmp.Checked)
            {
                Cmb.DropDownStyle = ComboBoxStyle.Simple;
                LblDD.Text = "DroppedDown:" + Cmb.DroppedDown;
            }
        }

        private void TxtMaxItm_TextChanged(object sender, EventArgs e)
        {//設定最大下拉項目，看顯示如何變化
            //Cmb.IntegralHeight = false; Cmb.DropDownHeight = 106;
            //若這兩個屬性值不是如此，MaxDropDownItems之設定無效。前者合於想像，但後者應是CS之bug
            try { Cmb.MaxDropDownItems = Convert.ToInt32(TxtMaxItm.Text); }
            catch { Cmb.MaxDropDownItems = 8; }
        }

        private void TxtMaxH_TextChanged(object sender, EventArgs e)
        {//設定下拉高度，看顯示如何變化
            try { Cmb.DropDownHeight = Convert.ToInt32(TxtMaxH.Text); }
            catch { Cmb.DropDownHeight = 106; }
        }

        private void TxtSizeH_TextChanged(object sender, EventArgs e)
        {//設定下拉選單高度，看顯示如何變化
            try { Cmb.Height = Convert.ToInt32(TxtSizeH.Text); }//只在下拉樣式為simple才有影響。以此表單之設定，文字方塊24，每項目16，但第一項前空約6
            catch { Cmb.Height = 12; }
        }

        private void BtnIH_Click(object sender, EventArgs e)
        {//設定下拉清單屬性IntegralHeight，會影響MaxDropDownItems設定是否有效，要false才有效
            Cmb.IntegralHeight = !Cmb.IntegralHeight;//on-off作法
            BtnIH.Text = "IntegralHeight:" + Cmb.IntegralHeight.ToString();//屬性true或false也顯示出來
        }

        private void BtnDD_Click(object sender, EventArgs e)
        {//設定DroppedDown屬性，採on-off作法，此屬性直接驅動下拉式清單是否出現下拉
            //bool tmpf = !Cmb.DroppedDown;
            //bool tmpf = false;
            //Cmb.DroppedDown = tmpf;//經上二式分別與此式搭配測試，並使用F11逐步執行，發現DroppedDown要變true前會先觸動DropDown事件，完成才變true並出現下拉選單
            Cmb.DroppedDown = !Cmb.DroppedDown;//經測試，由true變false時，先變false再觸動DropDownClose，但執行完不會返回此事件處理函或，所以未秀出B開頭的字串
            LblDD.Text += "B" + Cmb.DroppedDown;//串接方式，且加個字母，以便追踪順序
        }

        private void Cmb_SelectedIndexChanged(object sender, EventArgs e)
        {//類似清單方塊，示範點選的結果，只示範項目，未示範索引
            LblCmbItm.Text = "所選項目：" + Cmb.SelectedItem.ToString();
        }

        private void Cmb_TextChanged(object sender, EventArgs e)
        {//示範下拉式清單Text屬性。不管是輸入或點選，都會觸動
            LblCmbTxt.Text = "下拉清單Text:" + Cmb.Text;
        }

        private void Cmb_KeyUp(object sender, KeyEventArgs e)
        {//輸入新項目，當在下拉式清單的文字方塊中輸入，最後按Enter則Add到清單中
            if (e.KeyCode == Keys.Enter) Cmb.Items.Add(Cmb.Text);
        }

        private void BtnClrLbl_Click(object sender, EventArgs e)
        {//若DroppedDown輸出字串太長，以此還原
            LblDD.Text = "DroppedDown:";
        }
    }
}
