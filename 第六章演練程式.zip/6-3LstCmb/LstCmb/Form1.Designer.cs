﻿namespace LstCmb
{
    partial class FrmLstCmb
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.Lst = new System.Windows.Forms.ListBox();
            this.LblSlctIdx = new System.Windows.Forms.Label();
            this.LblSlctItm = new System.Windows.Forms.Label();
            this.BtnMulCol = new System.Windows.Forms.Button();
            this.BtnSorted = new System.Windows.Forms.Button();
            this.BtnSortedBack = new System.Windows.Forms.Button();
            this.GrpSlctMd = new System.Windows.Forms.GroupBox();
            this.RdbME = new System.Windows.Forms.RadioButton();
            this.RdbMS = new System.Windows.Forms.RadioButton();
            this.RdbNone = new System.Windows.Forms.RadioButton();
            this.RdbOne = new System.Windows.Forms.RadioButton();
            this.BtnRmv = new System.Windows.Forms.Button();
            this.BtnAdd = new System.Windows.Forms.Button();
            this.BtnSetSlct = new System.Windows.Forms.Button();
            this.BtnSrch = new System.Windows.Forms.Button();
            this.BtnMltSlct = new System.Windows.Forms.Button();
            this.GrpDDS = new System.Windows.Forms.GroupBox();
            this.RdbSmp = new System.Windows.Forms.RadioButton();
            this.RdbDDL = new System.Windows.Forms.RadioButton();
            this.RdbDD = new System.Windows.Forms.RadioButton();
            this.Cmb = new System.Windows.Forms.ComboBox();
            this.TxtMaxItm = new System.Windows.Forms.TextBox();
            this.TxtMaxH = new System.Windows.Forms.TextBox();
            this.TxtSizeH = new System.Windows.Forms.TextBox();
            this.LblMaxItm = new System.Windows.Forms.Label();
            this.LblMaxH = new System.Windows.Forms.Label();
            this.LblSizeH = new System.Windows.Forms.Label();
            this.BtnDD = new System.Windows.Forms.Button();
            this.LblDD = new System.Windows.Forms.Label();
            this.LblCmbTxt = new System.Windows.Forms.Label();
            this.BtnClrLbl = new System.Windows.Forms.Button();
            this.LblCmbItm = new System.Windows.Forms.Label();
            this.BtnIH = new System.Windows.Forms.Button();
            this.GrpSlctMd.SuspendLayout();
            this.GrpDDS.SuspendLayout();
            this.SuspendLayout();
            // 
            // Lst
            // 
            this.Lst.FormattingEnabled = true;
            this.Lst.ItemHeight = 16;
            this.Lst.Items.AddRange(new object[] {
            "子",
            "丑",
            "寅",
            "卯",
            "辰",
            "巳",
            "午",
            "未",
            "申",
            "酉",
            "戌",
            "亥"});
            this.Lst.Location = new System.Drawing.Point(35, 105);
            this.Lst.Name = "Lst";
            this.Lst.Size = new System.Drawing.Size(120, 84);
            this.Lst.TabIndex = 0;
            this.Lst.SelectedIndexChanged += new System.EventHandler(this.Lst_SelectedIndexChanged);
            // 
            // LblSlctIdx
            // 
            this.LblSlctIdx.AutoSize = true;
            this.LblSlctIdx.Location = new System.Drawing.Point(32, 36);
            this.LblSlctIdx.Name = "LblSlctIdx";
            this.LblSlctIdx.Size = new System.Drawing.Size(100, 16);
            this.LblSlctIdx.TabIndex = 1;
            this.LblSlctIdx.Text = "SelectedIndex:";
            // 
            // LblSlctItm
            // 
            this.LblSlctItm.AutoSize = true;
            this.LblSlctItm.Location = new System.Drawing.Point(32, 75);
            this.LblSlctItm.Name = "LblSlctItm";
            this.LblSlctItm.Size = new System.Drawing.Size(92, 16);
            this.LblSlctItm.TabIndex = 2;
            this.LblSlctItm.Text = "SelectedItem:";
            // 
            // BtnMulCol
            // 
            this.BtnMulCol.AutoSize = true;
            this.BtnMulCol.Location = new System.Drawing.Point(35, 209);
            this.BtnMulCol.Name = "BtnMulCol";
            this.BtnMulCol.Size = new System.Drawing.Size(111, 34);
            this.BtnMulCol.TabIndex = 3;
            this.BtnMulCol.Text = "MultiColumns";
            this.BtnMulCol.UseVisualStyleBackColor = true;
            this.BtnMulCol.Click += new System.EventHandler(this.BtnMulCol_Click);
            // 
            // BtnSorted
            // 
            this.BtnSorted.AutoSize = true;
            this.BtnSorted.Location = new System.Drawing.Point(35, 254);
            this.BtnSorted.Name = "BtnSorted";
            this.BtnSorted.Size = new System.Drawing.Size(107, 34);
            this.BtnSorted.TabIndex = 4;
            this.BtnSorted.Text = "Sorted";
            this.BtnSorted.UseVisualStyleBackColor = true;
            this.BtnSorted.Click += new System.EventHandler(this.BtnSorted_Click);
            // 
            // BtnSortedBack
            // 
            this.BtnSortedBack.AutoSize = true;
            this.BtnSortedBack.Enabled = false;
            this.BtnSortedBack.Location = new System.Drawing.Point(169, 105);
            this.BtnSortedBack.Name = "BtnSortedBack";
            this.BtnSortedBack.Size = new System.Drawing.Size(111, 34);
            this.BtnSortedBack.TabIndex = 5;
            this.BtnSortedBack.Text = "Sorted還原";
            this.BtnSortedBack.UseVisualStyleBackColor = true;
            this.BtnSortedBack.Click += new System.EventHandler(this.BtnSortedBack_Click);
            // 
            // GrpSlctMd
            // 
            this.GrpSlctMd.Controls.Add(this.RdbME);
            this.GrpSlctMd.Controls.Add(this.RdbMS);
            this.GrpSlctMd.Controls.Add(this.RdbNone);
            this.GrpSlctMd.Controls.Add(this.RdbOne);
            this.GrpSlctMd.Location = new System.Drawing.Point(318, 117);
            this.GrpSlctMd.Name = "GrpSlctMd";
            this.GrpSlctMd.Size = new System.Drawing.Size(168, 126);
            this.GrpSlctMd.TabIndex = 6;
            this.GrpSlctMd.TabStop = false;
            this.GrpSlctMd.Text = "SelectionMode";
            // 
            // RdbME
            // 
            this.RdbME.AutoSize = true;
            this.RdbME.Location = new System.Drawing.Point(19, 96);
            this.RdbME.Name = "RdbME";
            this.RdbME.Size = new System.Drawing.Size(118, 20);
            this.RdbME.TabIndex = 3;
            this.RdbME.Text = "MultiExtended";
            this.RdbME.UseVisualStyleBackColor = true;
            this.RdbME.CheckedChanged += new System.EventHandler(this.RdbME_CheckedChanged);
            // 
            // RdbMS
            // 
            this.RdbMS.AutoSize = true;
            this.RdbMS.Location = new System.Drawing.Point(19, 64);
            this.RdbMS.Name = "RdbMS";
            this.RdbMS.Size = new System.Drawing.Size(102, 20);
            this.RdbMS.TabIndex = 2;
            this.RdbMS.Text = "MultiSimple";
            this.RdbMS.UseVisualStyleBackColor = true;
            this.RdbMS.CheckedChanged += new System.EventHandler(this.RdbMS_CheckedChanged);
            // 
            // RdbNone
            // 
            this.RdbNone.AutoSize = true;
            this.RdbNone.Location = new System.Drawing.Point(92, 31);
            this.RdbNone.Name = "RdbNone";
            this.RdbNone.Size = new System.Drawing.Size(60, 20);
            this.RdbNone.TabIndex = 1;
            this.RdbNone.Text = "None";
            this.RdbNone.UseVisualStyleBackColor = true;
            this.RdbNone.CheckedChanged += new System.EventHandler(this.RdbNone_CheckedChanged);
            // 
            // RdbOne
            // 
            this.RdbOne.AutoSize = true;
            this.RdbOne.Checked = true;
            this.RdbOne.Location = new System.Drawing.Point(19, 31);
            this.RdbOne.Name = "RdbOne";
            this.RdbOne.Size = new System.Drawing.Size(52, 20);
            this.RdbOne.TabIndex = 0;
            this.RdbOne.TabStop = true;
            this.RdbOne.Text = "One";
            this.RdbOne.UseVisualStyleBackColor = true;
            this.RdbOne.CheckedChanged += new System.EventHandler(this.RdbOne_CheckedChanged);
            // 
            // BtnRmv
            // 
            this.BtnRmv.AutoSize = true;
            this.BtnRmv.Location = new System.Drawing.Point(169, 155);
            this.BtnRmv.Name = "BtnRmv";
            this.BtnRmv.Size = new System.Drawing.Size(50, 34);
            this.BtnRmv.TabIndex = 7;
            this.BtnRmv.Text = "移除";
            this.BtnRmv.UseVisualStyleBackColor = true;
            this.BtnRmv.Click += new System.EventHandler(this.BtnRmv_Click);
            // 
            // BtnAdd
            // 
            this.BtnAdd.AutoSize = true;
            this.BtnAdd.Location = new System.Drawing.Point(233, 155);
            this.BtnAdd.Name = "BtnAdd";
            this.BtnAdd.Size = new System.Drawing.Size(50, 34);
            this.BtnAdd.TabIndex = 8;
            this.BtnAdd.Text = "加入";
            this.BtnAdd.UseVisualStyleBackColor = true;
            this.BtnAdd.Click += new System.EventHandler(this.BtnAdd_Click);
            // 
            // BtnSetSlct
            // 
            this.BtnSetSlct.Location = new System.Drawing.Point(169, 209);
            this.BtnSetSlct.Name = "BtnSetSlct";
            this.BtnSetSlct.Size = new System.Drawing.Size(50, 68);
            this.BtnSetSlct.TabIndex = 9;
            this.BtnSetSlct.Text = "選取取消清除";
            this.BtnSetSlct.UseVisualStyleBackColor = true;
            this.BtnSetSlct.Click += new System.EventHandler(this.BtnSetSlct_Click);
            // 
            // BtnSrch
            // 
            this.BtnSrch.AutoSize = true;
            this.BtnSrch.Location = new System.Drawing.Point(236, 209);
            this.BtnSrch.Name = "BtnSrch";
            this.BtnSrch.Size = new System.Drawing.Size(50, 34);
            this.BtnSrch.TabIndex = 10;
            this.BtnSrch.Text = "尋找";
            this.BtnSrch.UseVisualStyleBackColor = true;
            this.BtnSrch.Click += new System.EventHandler(this.BtnSrch_Click);
            // 
            // BtnMltSlct
            // 
            this.BtnMltSlct.AutoSize = true;
            this.BtnMltSlct.Location = new System.Drawing.Point(318, 254);
            this.BtnMltSlct.Name = "BtnMltSlct";
            this.BtnMltSlct.Size = new System.Drawing.Size(111, 34);
            this.BtnMltSlct.TabIndex = 11;
            this.BtnMltSlct.Text = "多選的結果";
            this.BtnMltSlct.UseVisualStyleBackColor = true;
            this.BtnMltSlct.Click += new System.EventHandler(this.BtnMltSlct_Click);
            // 
            // GrpDDS
            // 
            this.GrpDDS.Controls.Add(this.RdbSmp);
            this.GrpDDS.Controls.Add(this.RdbDDL);
            this.GrpDDS.Controls.Add(this.RdbDD);
            this.GrpDDS.Location = new System.Drawing.Point(520, 117);
            this.GrpDDS.Name = "GrpDDS";
            this.GrpDDS.Size = new System.Drawing.Size(168, 126);
            this.GrpDDS.TabIndex = 12;
            this.GrpDDS.TabStop = false;
            this.GrpDDS.Text = "DropDownStyle";
            // 
            // RdbSmp
            // 
            this.RdbSmp.AutoSize = true;
            this.RdbSmp.Location = new System.Drawing.Point(19, 96);
            this.RdbSmp.Name = "RdbSmp";
            this.RdbSmp.Size = new System.Drawing.Size(69, 20);
            this.RdbSmp.TabIndex = 3;
            this.RdbSmp.Text = "Simple";
            this.RdbSmp.UseVisualStyleBackColor = true;
            this.RdbSmp.CheckedChanged += new System.EventHandler(this.RdbSmp_CheckedChanged);
            // 
            // RdbDDL
            // 
            this.RdbDDL.AutoSize = true;
            this.RdbDDL.Location = new System.Drawing.Point(19, 64);
            this.RdbDDL.Name = "RdbDDL";
            this.RdbDDL.Size = new System.Drawing.Size(119, 20);
            this.RdbDDL.TabIndex = 2;
            this.RdbDDL.Text = "DropDownList";
            this.RdbDDL.UseVisualStyleBackColor = true;
            this.RdbDDL.CheckedChanged += new System.EventHandler(this.RdbDDL_CheckedChanged);
            // 
            // RdbDD
            // 
            this.RdbDD.AutoSize = true;
            this.RdbDD.Checked = true;
            this.RdbDD.Location = new System.Drawing.Point(19, 31);
            this.RdbDD.Name = "RdbDD";
            this.RdbDD.Size = new System.Drawing.Size(96, 20);
            this.RdbDD.TabIndex = 0;
            this.RdbDD.TabStop = true;
            this.RdbDD.Text = "DropDown";
            this.RdbDD.UseVisualStyleBackColor = true;
            this.RdbDD.CheckedChanged += new System.EventHandler(this.RdbDD_CheckedChanged);
            // 
            // Cmb
            // 
            this.Cmb.FormattingEnabled = true;
            this.Cmb.ItemHeight = 16;
            this.Cmb.Items.AddRange(new object[] {
            "甲",
            "乙",
            "丙",
            "丁",
            "戊",
            "己",
            "庚",
            "辛",
            "壬",
            "癸"});
            this.Cmb.Location = new System.Drawing.Point(529, 32);
            this.Cmb.Name = "Cmb";
            this.Cmb.Size = new System.Drawing.Size(137, 24);
            this.Cmb.TabIndex = 13;
            this.Cmb.DropDown += new System.EventHandler(this.Cmb_DropDown);
            this.Cmb.SelectedIndexChanged += new System.EventHandler(this.Cmb_SelectedIndexChanged);
            this.Cmb.DropDownClosed += new System.EventHandler(this.Cmb_DropDownClosed);
            this.Cmb.TextChanged += new System.EventHandler(this.Cmb_TextChanged);
            this.Cmb.Click += new System.EventHandler(this.Cmb_Click);
            this.Cmb.KeyUp += new System.Windows.Forms.KeyEventHandler(this.Cmb_KeyUp);
            // 
            // TxtMaxItm
            // 
            this.TxtMaxItm.Location = new System.Drawing.Point(805, 34);
            this.TxtMaxItm.Name = "TxtMaxItm";
            this.TxtMaxItm.Size = new System.Drawing.Size(74, 27);
            this.TxtMaxItm.TabIndex = 14;
            this.TxtMaxItm.TextChanged += new System.EventHandler(this.TxtMaxItm_TextChanged);
            // 
            // TxtMaxH
            // 
            this.TxtMaxH.Location = new System.Drawing.Point(805, 75);
            this.TxtMaxH.Name = "TxtMaxH";
            this.TxtMaxH.Size = new System.Drawing.Size(74, 27);
            this.TxtMaxH.TabIndex = 15;
            this.TxtMaxH.TextChanged += new System.EventHandler(this.TxtMaxH_TextChanged);
            // 
            // TxtSizeH
            // 
            this.TxtSizeH.Location = new System.Drawing.Point(805, 117);
            this.TxtSizeH.Name = "TxtSizeH";
            this.TxtSizeH.Size = new System.Drawing.Size(74, 27);
            this.TxtSizeH.TabIndex = 16;
            this.TxtSizeH.TextChanged += new System.EventHandler(this.TxtSizeH_TextChanged);
            // 
            // LblMaxItm
            // 
            this.LblMaxItm.AutoSize = true;
            this.LblMaxItm.Location = new System.Drawing.Point(695, 37);
            this.LblMaxItm.Name = "LblMaxItm";
            this.LblMaxItm.Size = new System.Drawing.Size(104, 16);
            this.LblMaxItm.TabIndex = 17;
            this.LblMaxItm.Text = "最大下拉項目";
            // 
            // LblMaxH
            // 
            this.LblMaxH.AutoSize = true;
            this.LblMaxH.Location = new System.Drawing.Point(727, 78);
            this.LblMaxH.Name = "LblMaxH";
            this.LblMaxH.Size = new System.Drawing.Size(72, 16);
            this.LblMaxH.TabIndex = 18;
            this.LblMaxH.Text = "下拉高度";
            // 
            // LblSizeH
            // 
            this.LblSizeH.AutoSize = true;
            this.LblSizeH.Location = new System.Drawing.Point(694, 123);
            this.LblSizeH.Name = "LblSizeH";
            this.LblSizeH.Size = new System.Drawing.Size(104, 16);
            this.LblSizeH.TabIndex = 19;
            this.LblSizeH.Text = "下拉清單高度";
            // 
            // BtnDD
            // 
            this.BtnDD.AutoSize = true;
            this.BtnDD.Location = new System.Drawing.Point(698, 194);
            this.BtnDD.Name = "BtnDD";
            this.BtnDD.Size = new System.Drawing.Size(111, 34);
            this.BtnDD.TabIndex = 20;
            this.BtnDD.Text = "DroppedDown";
            this.BtnDD.UseVisualStyleBackColor = true;
            this.BtnDD.Click += new System.EventHandler(this.BtnDD_Click);
            // 
            // LblDD
            // 
            this.LblDD.AutoSize = true;
            this.LblDD.Location = new System.Drawing.Point(435, 265);
            this.LblDD.Name = "LblDD";
            this.LblDD.Size = new System.Drawing.Size(105, 16);
            this.LblDD.TabIndex = 21;
            this.LblDD.Text = "DroppedDown:";
            // 
            // LblCmbTxt
            // 
            this.LblCmbTxt.AutoSize = true;
            this.LblCmbTxt.Location = new System.Drawing.Point(702, 235);
            this.LblCmbTxt.Name = "LblCmbTxt";
            this.LblCmbTxt.Size = new System.Drawing.Size(104, 16);
            this.LblCmbTxt.TabIndex = 22;
            this.LblCmbTxt.Text = "下拉清單Text:";
            // 
            // BtnClrLbl
            // 
            this.BtnClrLbl.AutoSize = true;
            this.BtnClrLbl.Location = new System.Drawing.Point(810, 262);
            this.BtnClrLbl.Name = "BtnClrLbl";
            this.BtnClrLbl.Size = new System.Drawing.Size(75, 26);
            this.BtnClrLbl.TabIndex = 23;
            this.BtnClrLbl.Text = "清標籤";
            this.BtnClrLbl.UseVisualStyleBackColor = true;
            this.BtnClrLbl.Click += new System.EventHandler(this.BtnClrLbl_Click);
            // 
            // LblCmbItm
            // 
            this.LblCmbItm.AutoSize = true;
            this.LblCmbItm.Location = new System.Drawing.Point(532, 80);
            this.LblCmbItm.Name = "LblCmbItm";
            this.LblCmbItm.Size = new System.Drawing.Size(92, 16);
            this.LblCmbItm.TabIndex = 24;
            this.LblCmbItm.Text = "SelectedItem:";
            // 
            // BtnIH
            // 
            this.BtnIH.AutoSize = true;
            this.BtnIH.Location = new System.Drawing.Point(698, 154);
            this.BtnIH.Name = "BtnIH";
            this.BtnIH.Size = new System.Drawing.Size(111, 34);
            this.BtnIH.TabIndex = 25;
            this.BtnIH.Text = "IntergalHeight";
            this.BtnIH.UseVisualStyleBackColor = true;
            this.BtnIH.Click += new System.EventHandler(this.BtnIH_Click);
            // 
            // FrmLstCmb
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(984, 324);
            this.Controls.Add(this.BtnIH);
            this.Controls.Add(this.LblCmbItm);
            this.Controls.Add(this.BtnClrLbl);
            this.Controls.Add(this.LblCmbTxt);
            this.Controls.Add(this.LblDD);
            this.Controls.Add(this.BtnDD);
            this.Controls.Add(this.LblSizeH);
            this.Controls.Add(this.LblMaxH);
            this.Controls.Add(this.LblMaxItm);
            this.Controls.Add(this.TxtSizeH);
            this.Controls.Add(this.TxtMaxH);
            this.Controls.Add(this.TxtMaxItm);
            this.Controls.Add(this.Cmb);
            this.Controls.Add(this.GrpDDS);
            this.Controls.Add(this.BtnMltSlct);
            this.Controls.Add(this.BtnSrch);
            this.Controls.Add(this.BtnSetSlct);
            this.Controls.Add(this.BtnAdd);
            this.Controls.Add(this.BtnRmv);
            this.Controls.Add(this.GrpSlctMd);
            this.Controls.Add(this.BtnSortedBack);
            this.Controls.Add(this.BtnSorted);
            this.Controls.Add(this.BtnMulCol);
            this.Controls.Add(this.LblSlctItm);
            this.Controls.Add(this.LblSlctIdx);
            this.Controls.Add(this.Lst);
            this.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "FrmLstCmb";
            this.Text = "清單與組合方塊";
            this.Load += new System.EventHandler(this.FrmLstCmb_Load);
            this.GrpSlctMd.ResumeLayout(false);
            this.GrpSlctMd.PerformLayout();
            this.GrpDDS.ResumeLayout(false);
            this.GrpDDS.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox Lst;
        private System.Windows.Forms.Label LblSlctIdx;
        private System.Windows.Forms.Label LblSlctItm;
        private System.Windows.Forms.Button BtnMulCol;
        private System.Windows.Forms.Button BtnSorted;
        private System.Windows.Forms.Button BtnSortedBack;
        private System.Windows.Forms.GroupBox GrpSlctMd;
        private System.Windows.Forms.RadioButton RdbME;
        private System.Windows.Forms.RadioButton RdbMS;
        private System.Windows.Forms.RadioButton RdbNone;
        private System.Windows.Forms.RadioButton RdbOne;
        private System.Windows.Forms.Button BtnRmv;
        private System.Windows.Forms.Button BtnAdd;
        private System.Windows.Forms.Button BtnSetSlct;
        private System.Windows.Forms.Button BtnSrch;
        private System.Windows.Forms.Button BtnMltSlct;
        private System.Windows.Forms.GroupBox GrpDDS;
        private System.Windows.Forms.RadioButton RdbSmp;
        private System.Windows.Forms.RadioButton RdbDDL;
        private System.Windows.Forms.RadioButton RdbDD;
        private System.Windows.Forms.ComboBox Cmb;
        private System.Windows.Forms.TextBox TxtMaxItm;
        private System.Windows.Forms.TextBox TxtMaxH;
        private System.Windows.Forms.TextBox TxtSizeH;
        private System.Windows.Forms.Label LblMaxItm;
        private System.Windows.Forms.Label LblMaxH;
        private System.Windows.Forms.Label LblSizeH;
        private System.Windows.Forms.Button BtnDD;
        private System.Windows.Forms.Label LblDD;
        private System.Windows.Forms.Label LblCmbTxt;
        private System.Windows.Forms.Button BtnClrLbl;
        private System.Windows.Forms.Label LblCmbItm;
        private System.Windows.Forms.Button BtnIH;
    }
}

