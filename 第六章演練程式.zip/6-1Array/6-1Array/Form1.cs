﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _6_1Array
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            int k = 5;
            double a = 7;
            int[] ScoreA;//整數短陣宣告，可把[]想成代表矩陣，所以接在int後面，不是變數後面
            int Score1, Score2, Score3, Score4, Score5;
            ScoreA = new int[6];//陣列宣告完要用new建立，此例為int陣列建立6個元素
            ScoreA = new int[k];//陣列可以再用new重新建立，後者會覆寫前者，此例用變數宣告大小
            ScoreA = new int[k + 5];//可用運算式宣告大小
            //ScoreA = new int[a];//不可用非整數型別來宣告大小
            //ScoreA = new int[1.3];//不可用非整數型別來宣告大小
            //ScoreA = new int[1.3+1.7];//不可用非整數型別來宣告大小
            ScoreA = new int[(int)(1.3+1.7)];//不可用非整數型別來宣告大小，但若強制轉型即可
            MessageBox.Show("用ScoreA.Length取得ScoreA陣列大小為：" + (ScoreA.Length).ToString());
            int[] ScoreB = new int[5];//宣告及建立同時
            //Score = { 90, 96, 83, 67, 91 };//不能這樣給初值
            int[] ScoreC = { 90, 96, 83, 67, 91 };//宣告、建立、給初值同時。有二種方法
            int[] Score = new int[] { 90, 96, 83, 69, 91 };//宣告、建立、給初值同時

            int avg, sum = 0;//平均變數；加總變數並設初值0
            for (int i = 0; i < Score.Length; i++) sum += Score[i]; //迴圈加總成績，Length是物件score的長度即個數
            avg = sum / Score.Length;//算平均，會直接刪去小數
            MessageBox.Show("用for算的平均分數為：" + avg);

            sum = 0;
            foreach (int i in Score) sum += i;//迴圈加總成績，i是依序從score的每個成績
            avg = sum / Score.Length;//算平均
            MessageBox.Show("用foreach算的平均分數為：" + avg);

            int[,] PgScrA = new int[3, 4];//若未有初值，最常用是同時宣告及建立
            int[,] PgScrB;//也可以先宣告
            PgScrB = new int[3, 4];//再建立
            int[,] PgScrC = { { 90, 80, 70, 60 }, { 60, 70, 80, 90 }, { 10, 0, 3, 5 } };//若有初值，可在宣告建立同時給初值
            int[,] PgScr = new int[,] { { 90, 80, 70, 60 }, { 60, 70, 80, 90 }, { 10, 0, 3, 5 } };//另一種較完整但較少用的宣告、建立、給初值同時的方式
            int[,,] PgScr3 = new int[3, 50, 4];//三維陣列同時宣告及建立
            int Dim0 = PgScr3.GetUpperBound(0);//陣列維度0的上界2
            int Dim1 = PgScr3.GetUpperBound(1);//陣列維度1的上界49
            int Dim2 = PgScr3.GetUpperBound(2);//陣列維度2的上界3
            MessageBox.Show("用GetUpperBound取得三維陣列每維的上界，分別為" + Dim0 + "、" + Dim1 + "、" + Dim2);
            int[,,] PgScrD = new int[,,] { { { 1, 2, 3, 4 }, { 5, 6, 7, 8 }, { 4, 3, 2, 1 } },  //試範三維[2,3,4]陣列給初值
                                           { { 8, 7, 6, 5 }, { 1, 2, 3, 4 }, { 4, 3, 2, 1 } } };
            Application.Exit();
        }
    }
}
