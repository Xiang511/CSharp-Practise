﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _6_2SortSrch
{
    public partial class FrmSortSrch : Form
    {
        public FrmSortSrch()
        {
            InitializeComponent();
        }

        //宣告全域變數：分數陣列及姓名陣列，因為多處用到
        int[] Score = { 88, 65, 95 };
        string[] Nam = { "趙大", "錢二", "孫三" };

        private void FrmSortSrch_Load(object sender, EventArgs e)
        {
            ShowNamScore();//顯示原始陣列內容
        }

        private void BtnSort_Click(object sender, EventArgs e)
        {
            int[] score = new int[3];//宣告小寫score陣列，存一份大寫Score陣列的複本，以便還原使用
            Score.CopyTo(score, 0);//Score複製到score
            Array.Sort(Score);//Score排序
            ShowNamScore();//顯示目前姓名及分數陣列內容
            MessageBox.Show("現在只排序分數");//因只有排序分數，故對應錯誤
            score.CopyTo(Score, 0);//還原分數，將備份的score複製回Score
            ShowNamScore();//再顯示目前姓名及分數陣列內容
            MessageBox.Show("現在還原分數排序");//因分數已還原，故對應是正確的
            Array.Sort(Score, Nam);//分數與姓名同時排序，以分數為主導
            ShowNamScore();//再顯示目前姓名及分數陣列內容
            MessageBox.Show("現在同時排序分數及姓名");//因同時排序，所以對應關係是正確的
        }

        private void ShowNamScore()
        {//自訂方法，顯示目前姓名及分數陣列內容
            LblName0.Text = Nam[0];//將分數陣列內的元素一一放到對應的標籤
            LblName1.Text = Nam[1];
            LblName2.Text = Nam[2];
            LblScore0.Text = Score[0].ToString();//將姓名陣列內的元素一一放到對應的標籤
            LblScore1.Text = Score[1].ToString();
            LblScore2.Text = Score[2].ToString();
        }

        private void BtnRvs_Click(object sender, EventArgs e)
        {
            Array.Reverse(Score);//成績陣列反轉
            ShowNamScore();//顯示目前姓名及分數陣列內容
            MessageBox.Show("現在只反轉分數");//因只有反轉分數，所以對應錯誤
            Array.Reverse(Nam);//姓名陣列也反轉
            ShowNamScore();//顯示目前姓名及分數陣列內容
            MessageBox.Show("現在也反轉姓名");//分數姓名皆有反轉，所以對應關係是正確的
        }

        private void BtnSrch_Click(object sender, EventArgs e)
        {//示範搜尋方法Array.IndexOf
            int[] ScoreS = { 88, 65, 95, 88 };//給定搜尋示範用的分數陣列ScoreS
            LblScoreS0.Text = ScoreS[0].ToString();//將分數陣列ScoreS內的元素一一放到對應的標籤
            LblScoreS1.Text = ScoreS[1].ToString();
            LblScoreS2.Text = ScoreS[2].ToString();
            LblScoreS3.Text = ScoreS[3].ToString();
            MessageBox.Show("Array.IndexOf(ScoreS, 65)索引未寫表從頭，數目未寫表到底，結果：" + Array.IndexOf(ScoreS, 65));
            MessageBox.Show("Array.IndexOf(ScoreS, 65, 2)數目未寫表到底，結果：" + Array.IndexOf(ScoreS, 65, 2) + "表示找不到");
            //int value = Array.IndexOf(ScoreS, 65, , 3);//數目未省略，則起始索引也必須存在，即使是從頭開始，也要寫上0
            MessageBox.Show("Array.IndexOf(ScoreS, 88, 0, 3)從索引0開始找3個，結果：" + Array.IndexOf(ScoreS, 88, 0, 3));
            MessageBox.Show("Array.IndexOf(ScoreS, 88, 4)從索引4 (最大索引值3，超過1)開始找到底，結果：" + Array.IndexOf(ScoreS, 88, 4) + "表示找不到");

            try
            {//從超過最大索引值1(含)以上且有要求數目會發生例外。上例未要求數目只會回傳-1，不會發生例外
                MessageBox.Show("Array.IndexOf(ScoreS, 88, 4, 1)結果：" + Array.IndexOf(ScoreS, 88, 4, 1));
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }//錯誤訊息表示數目錯誤

            try
            {//從超過最大索引值2(含)以上會發生例外，即使未要求數目。上例未要求數目且只超過1，只會回傳-1，不會發生例外
                MessageBox.Show("Array.IndexOf(ScoreS, 88, 5)結果：" + Array.IndexOf(ScoreS, 88, 5));
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }//錯誤訊息表示起始索引錯誤
        }

        private void BtnRnkLnth_Click(object sender, EventArgs e)
        {//示範取陣列維度、大小及各維的大小，先建立二個陣列，一個是二維3X4，一個是一維
            int[,] PgScr = { { 90, 80, 70, 60 }, { 60, 70, 80, 90 }, { 10, 0, 3, 5 } };
            string[] Nam = { "趙大", "錢二", "孫三" };
            MessageBox.Show("PgScr = { 90, 80, 70, 60 }, { 60, 70, 80, 90 }, { 10, 0, 3, 5 } }的維度用(PgScr.Rank).ToString()得：" + (PgScr.Rank).ToString());
            MessageBox.Show("Nam = { \"趙大\", \"錢二\", \"孫三\" }的維度用(Nam.Rank).ToString()得：" + (Nam.Rank).ToString());
            MessageBox.Show("PgScr = { 90, 80, 70, 60 }, { 60, 70, 80, 90 }, { 10, 0, 3, 5 } }的大小長度用(PgScr.Length).ToString()得：" + (PgScr.Length).ToString());
            MessageBox.Show("Nam = { \"趙大\", \"錢二\", \"孫三\" }的大小長度用(Nam.Length).ToString()得：" + (Nam.Length).ToString());
            MessageBox.Show("PgScr = { 90, 80, 70, 60 }, { 60, 70, 80, 90 }, { 10, 0, 3, 5 } }的第1維大小長度用(PgScr.GetLength(0)).ToString()得：" + (PgScr.GetLength(0)).ToString());
            MessageBox.Show("PgScr = { 90, 80, 70, 60 }, { 60, 70, 80, 90 }, { 10, 0, 3, 5 } }的第2維大小長度用(PgScr.GetLength(1)).ToString()得：" + (PgScr.GetLength(1)).ToString());
        }

        private void BtnCpClr_Click(object sender, EventArgs e)
        {//示範陣列方法：複製及清除
            int[] a = { 10, 11, 12, 13 };//給定來源陣列a，並顯示在對應的標籤上
            LblSrc1.Text = a[0].ToString();
            LblSrc2.Text = a[1].ToString();
            LblSrc3.Text = a[2].ToString();
            LblSrc4.Text = a[3].ToString();
            MessageBox.Show("來源陣列a為{ 10, 11, 12, 13 }");
            int[] b = new int[7];//建立目的陣列b，此時b為{0, 0, 0, 0, 0, 0, 0}，並顯示在對應的標籤上
            LblTgt1.Text = b[0].ToString();
            LblTgt2.Text = b[1].ToString();
            LblTgt3.Text = b[2].ToString();
            LblTgt4.Text = b[3].ToString();
            LblTgt5.Text = b[4].ToString();
            LblTgt6.Text = b[5].ToString();
            LblTgt7.Text = b[6].ToString();
            MessageBox.Show("目的陣列b新建未給初值，所以整數預設為0");
            a.CopyTo(b, 2);//a複製到b，從b[2]開始放，結果b為{0, 0, 10, 11, 12, 13, 0}，並顯示在對應的標籤上
            LblTgt1.Text = b[0].ToString();
            LblTgt2.Text = b[1].ToString();
            LblTgt3.Text = b[2].ToString();
            LblTgt4.Text = b[3].ToString();
            LblTgt5.Text = b[4].ToString();
            LblTgt6.Text = b[5].ToString();
            LblTgt7.Text = b[6].ToString();
            MessageBox.Show("使用a.CopyTo(b, 2)後，目的陣列改變");

            int[] c = { 8, 11, 25, 12, 5, 13, 9, 47 };//建立陣列c供示範清除方法
            Array.Clear(c, 2, 5);//此時c為{8, 11, 0, 0, 0, 0, 0, 47}，以下先串接元素，再用訊息方塊顯示
            string ArNew = "{ ";
            for (int i = 0; i < c.Length-1; i++) ArNew += c[i] + ", ";//用迴圈把陣列每個元素串到字串輸出
            ArNew += c[c.GetUpperBound(0)] + " }";//最後一個的後面不是逗點，是大括號，所以獨立處理
            MessageBox.Show("c = { 8, 11, 25, 12, 5, 13, 9, 47 }, Array.Clear(c, 2, 5)結果為：" + ArNew);//最後把輸出字串用訊息方塊輸出

            string StrOut = "c = "+ArNew;
            Array.Clear(c, 8, 0);//Array.Clear(陣列, 起始索引, 數目)其中(起始索引-1)+數目要<=索引上界。所以這個敘述OK，雖無意義
            StrOut += ", Array.Clear(c, 8, 0)結果為：";//其實起始索引是減1後，開始加數目，若0就不用加，所以不會超過索引上界
            ArNew = "{ ";
            for (int i = 0; i < c.Length - 1; i++) ArNew += c[i] + ", ";//用迴圈把陣列每個元素串到字串輸出
            ArNew += c[c.GetUpperBound(0)] + " }";//最後一個的後面不是逗點，是大括號，所以獨立處理
            MessageBox.Show(StrOut + ArNew);//最後把輸出字串用訊息方塊輸出

            try { Array.Clear(c, 2, 7); }//只要清除的元素超出陣列就會發生例外，因為(2-1)+7=8超過上界7
            catch (Exception ex) { MessageBox.Show("Array.Clear(c, 2, 7)" + ex.Message); }
        }

        private void BtnRsz_Click(object sender, EventArgs e)
        {//示範陣列重新定義大小Resize方法
            int[] a = { 8, 11, 25, 12 };//給定陣列a，並串成字串後用訊息方塊顯示
            string StrAry = "{ 8, 11, 25, 12 }";
            string StrOut = "目前陣列a = " + StrAry;
            MessageBox.Show(StrOut);
            Array.Resize(ref a, 2);//經Resize後a為{8, 11}，串成字串後用訊息方塊顯示
            StrOut = StrAry + "經Array.Resize(ref a, 2)，目前陣列a = ";
            StrAry = "{ " + a[0];
            for (int i = 1; i < a.Length; i++) StrAry += ", " + a[i];
            StrAry += " }";
            MessageBox.Show(StrOut + StrAry);
            Array.Resize(ref a, 5);//再經Resize，此時a為{8, 11, 0, 0, 0}，串成字串後用訊息方塊顯示
            StrOut = StrAry + "經Array.Resize(ref a, 5)，目前陣列a = ";
            StrAry = "{ " + a[0];
            for (int i = 1; i < a.Length; i++) StrAry += ", " + a[i];
            StrAry += " }";
            MessageBox.Show(StrOut + StrAry);
        }

        private void BtnSplit_Click(object sender, EventArgs e)
        {//示範字串分割成陣列
            string Nam = "趙大,錢二,孫三";//給定字串存入變數
            string[] AryName = Nam.Split(',');//以逗號分割字串變數，存入陣列
            string StrAry = "{ " + AryName[0];//陣列元素串成字串後用訊息方塊顯示
            for (int i = 1; i < AryName.Length; i++) StrAry += ", " + AryName[i];
            StrAry += " }";
            MessageBox.Show("Nam = \"趙大,錢二,孫三\"經AryName = Nam.Split(',')得AryName = " + StrAry);

            AryName = "趙大,錢二,孫三".Split(',');//直接以字串（逗號後無空格），用逗號分割後存人陣列
            StrAry = "{ " + AryName[0];//陣列元素串成字串
            for (int i = 1; i < AryName.Length; i++) StrAry += ", " + AryName[i];
            StrAry += " }";
            string StrOut = "經AryName = \"趙大,錢二,孫三\".Split(',')得AryName = " + StrAry + "\n";
            AryName = "趙大, 錢二, 孫三".Split(',');//同上，但逗號後有空格
            StrAry = "{ " + AryName[0];//陣列元素串成字串
            for (int i = 1; i < AryName.Length; i++) StrAry += ", " + AryName[i];
            StrAry += " }";//因字串逗號後有空格，所以AryName[1]第一個字元是空格，AryName[2]亦然
            MessageBox.Show(StrOut + "經AryName = \"趙大, 錢二, 孫三\".Split(',')得AryName = " + StrAry);
            //用訊息方塊將上述二個結果輸出，以便比較差異

            AryName = "趙大 錢二 孫三".Split();//直接以字串（間隔一空格），用空格分割後存人陣列
            StrAry = "{ " + AryName[0];//陣列元素串成字串
            for (int i = 1; i < AryName.Length; i++) StrAry += ", " + AryName[i];
            StrAry += " }";
            StrOut = "經AryName = \"趙大 錢二 孫三\".Split()得AryName = " + StrAry + "\n";
            AryName = "趙大  錢二  孫三".Split();//直接以字串（間隔二空格），用空格分割後存人陣列
            StrAry = "{ " + AryName[0];//陣列元素串成字串
            for (int i = 1; i < AryName.Length; i++) StrAry += ", " + AryName[i];
            StrAry += " }";//因間隔二空格，所以AryName[1]是空的，AryName[3]亦然
            MessageBox.Show(StrOut + "經AryName = \"趙大  錢二  孫三\".Split()得AryName = " + StrAry);
            //用訊息方塊將上述二個結果輸出，以便比較差異
            MessageBox.Show("xxx" + AryName[1] + "yyy");//特別把AryName[1]前後分別放xxx及yyy以顯示真的沒東西
        }
    }
}
