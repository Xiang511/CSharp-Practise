﻿namespace _6_2SortSrch
{
    partial class FrmSortSrch
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.BtnSort = new System.Windows.Forms.Button();
            this.BtnRvs = new System.Windows.Forms.Button();
            this.BtnSrch = new System.Windows.Forms.Button();
            this.LblName = new System.Windows.Forms.Label();
            this.LblName0 = new System.Windows.Forms.Label();
            this.LblName1 = new System.Windows.Forms.Label();
            this.LblName2 = new System.Windows.Forms.Label();
            this.LblScore2 = new System.Windows.Forms.Label();
            this.LblScore1 = new System.Windows.Forms.Label();
            this.LblScore0 = new System.Windows.Forms.Label();
            this.LblScore = new System.Windows.Forms.Label();
            this.LblScoreS2 = new System.Windows.Forms.Label();
            this.LblScoreS1 = new System.Windows.Forms.Label();
            this.LblScoreS0 = new System.Windows.Forms.Label();
            this.LblScoreS = new System.Windows.Forms.Label();
            this.LblScoreS3 = new System.Windows.Forms.Label();
            this.BtnRnkLnth = new System.Windows.Forms.Button();
            this.BtnCpClr = new System.Windows.Forms.Button();
            this.BtnRsz = new System.Windows.Forms.Button();
            this.BtnSplit = new System.Windows.Forms.Button();
            this.LblSrc = new System.Windows.Forms.Label();
            this.LblTgt = new System.Windows.Forms.Label();
            this.LblSrc1 = new System.Windows.Forms.Label();
            this.LblSrc2 = new System.Windows.Forms.Label();
            this.LblSrc3 = new System.Windows.Forms.Label();
            this.LblSrc4 = new System.Windows.Forms.Label();
            this.LblSrc5 = new System.Windows.Forms.Label();
            this.LblSrc6 = new System.Windows.Forms.Label();
            this.LblSrc7 = new System.Windows.Forms.Label();
            this.LblTgt7 = new System.Windows.Forms.Label();
            this.LblTgt6 = new System.Windows.Forms.Label();
            this.LblTgt5 = new System.Windows.Forms.Label();
            this.LblTgt4 = new System.Windows.Forms.Label();
            this.LblTgt3 = new System.Windows.Forms.Label();
            this.LblTgt2 = new System.Windows.Forms.Label();
            this.LblTgt1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // BtnSort
            // 
            this.BtnSort.AutoSize = true;
            this.BtnSort.Location = new System.Drawing.Point(34, 31);
            this.BtnSort.Name = "BtnSort";
            this.BtnSort.Size = new System.Drawing.Size(75, 26);
            this.BtnSort.TabIndex = 0;
            this.BtnSort.Text = "排序";
            this.BtnSort.UseVisualStyleBackColor = true;
            this.BtnSort.Click += new System.EventHandler(this.BtnSort_Click);
            // 
            // BtnRvs
            // 
            this.BtnRvs.AutoSize = true;
            this.BtnRvs.Location = new System.Drawing.Point(34, 80);
            this.BtnRvs.Name = "BtnRvs";
            this.BtnRvs.Size = new System.Drawing.Size(75, 26);
            this.BtnRvs.TabIndex = 1;
            this.BtnRvs.Text = "反轉";
            this.BtnRvs.UseVisualStyleBackColor = true;
            this.BtnRvs.Click += new System.EventHandler(this.BtnRvs_Click);
            // 
            // BtnSrch
            // 
            this.BtnSrch.AutoSize = true;
            this.BtnSrch.Location = new System.Drawing.Point(34, 131);
            this.BtnSrch.Name = "BtnSrch";
            this.BtnSrch.Size = new System.Drawing.Size(75, 26);
            this.BtnSrch.TabIndex = 2;
            this.BtnSrch.Text = "搜尋";
            this.BtnSrch.UseVisualStyleBackColor = true;
            this.BtnSrch.Click += new System.EventHandler(this.BtnSrch_Click);
            // 
            // LblName
            // 
            this.LblName.AutoSize = true;
            this.LblName.Location = new System.Drawing.Point(115, 35);
            this.LblName.Name = "LblName";
            this.LblName.Size = new System.Drawing.Size(56, 16);
            this.LblName.TabIndex = 3;
            this.LblName.Text = "姓名：";
            // 
            // LblName0
            // 
            this.LblName0.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.LblName0.Location = new System.Drawing.Point(167, 34);
            this.LblName0.Name = "LblName0";
            this.LblName0.Size = new System.Drawing.Size(45, 20);
            this.LblName0.TabIndex = 4;
            this.LblName0.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // LblName1
            // 
            this.LblName1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.LblName1.Location = new System.Drawing.Point(213, 34);
            this.LblName1.Name = "LblName1";
            this.LblName1.Size = new System.Drawing.Size(45, 20);
            this.LblName1.TabIndex = 5;
            this.LblName1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // LblName2
            // 
            this.LblName2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.LblName2.Location = new System.Drawing.Point(259, 34);
            this.LblName2.Name = "LblName2";
            this.LblName2.Size = new System.Drawing.Size(45, 20);
            this.LblName2.TabIndex = 6;
            this.LblName2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // LblScore2
            // 
            this.LblScore2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.LblScore2.Location = new System.Drawing.Point(259, 68);
            this.LblScore2.Name = "LblScore2";
            this.LblScore2.Size = new System.Drawing.Size(45, 20);
            this.LblScore2.TabIndex = 10;
            this.LblScore2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // LblScore1
            // 
            this.LblScore1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.LblScore1.Location = new System.Drawing.Point(213, 68);
            this.LblScore1.Name = "LblScore1";
            this.LblScore1.Size = new System.Drawing.Size(45, 20);
            this.LblScore1.TabIndex = 9;
            this.LblScore1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // LblScore0
            // 
            this.LblScore0.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.LblScore0.Location = new System.Drawing.Point(167, 68);
            this.LblScore0.Name = "LblScore0";
            this.LblScore0.Size = new System.Drawing.Size(45, 20);
            this.LblScore0.TabIndex = 8;
            this.LblScore0.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // LblScore
            // 
            this.LblScore.AutoSize = true;
            this.LblScore.Location = new System.Drawing.Point(115, 69);
            this.LblScore.Name = "LblScore";
            this.LblScore.Size = new System.Drawing.Size(56, 16);
            this.LblScore.TabIndex = 7;
            this.LblScore.Text = "分數：";
            // 
            // LblScoreS2
            // 
            this.LblScoreS2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.LblScoreS2.Location = new System.Drawing.Point(259, 135);
            this.LblScoreS2.Name = "LblScoreS2";
            this.LblScoreS2.Size = new System.Drawing.Size(45, 20);
            this.LblScoreS2.TabIndex = 14;
            this.LblScoreS2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // LblScoreS1
            // 
            this.LblScoreS1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.LblScoreS1.Location = new System.Drawing.Point(213, 135);
            this.LblScoreS1.Name = "LblScoreS1";
            this.LblScoreS1.Size = new System.Drawing.Size(45, 20);
            this.LblScoreS1.TabIndex = 13;
            this.LblScoreS1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // LblScoreS0
            // 
            this.LblScoreS0.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.LblScoreS0.Location = new System.Drawing.Point(167, 135);
            this.LblScoreS0.Name = "LblScoreS0";
            this.LblScoreS0.Size = new System.Drawing.Size(45, 20);
            this.LblScoreS0.TabIndex = 12;
            this.LblScoreS0.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // LblScoreS
            // 
            this.LblScoreS.AutoSize = true;
            this.LblScoreS.Location = new System.Drawing.Point(115, 136);
            this.LblScoreS.Name = "LblScoreS";
            this.LblScoreS.Size = new System.Drawing.Size(56, 16);
            this.LblScoreS.TabIndex = 11;
            this.LblScoreS.Text = "分數：";
            // 
            // LblScoreS3
            // 
            this.LblScoreS3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.LblScoreS3.Location = new System.Drawing.Point(306, 135);
            this.LblScoreS3.Name = "LblScoreS3";
            this.LblScoreS3.Size = new System.Drawing.Size(45, 20);
            this.LblScoreS3.TabIndex = 15;
            this.LblScoreS3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // BtnRnkLnth
            // 
            this.BtnRnkLnth.AutoSize = true;
            this.BtnRnkLnth.Location = new System.Drawing.Point(34, 186);
            this.BtnRnkLnth.Name = "BtnRnkLnth";
            this.BtnRnkLnth.Size = new System.Drawing.Size(82, 26);
            this.BtnRnkLnth.TabIndex = 17;
            this.BtnRnkLnth.Text = "維度大小";
            this.BtnRnkLnth.UseVisualStyleBackColor = true;
            this.BtnRnkLnth.Click += new System.EventHandler(this.BtnRnkLnth_Click);
            // 
            // BtnCpClr
            // 
            this.BtnCpClr.AutoSize = true;
            this.BtnCpClr.Location = new System.Drawing.Point(391, 35);
            this.BtnCpClr.Name = "BtnCpClr";
            this.BtnCpClr.Size = new System.Drawing.Size(82, 26);
            this.BtnCpClr.TabIndex = 18;
            this.BtnCpClr.Text = "複製清除";
            this.BtnCpClr.UseVisualStyleBackColor = true;
            this.BtnCpClr.Click += new System.EventHandler(this.BtnCpClr_Click);
            // 
            // BtnRsz
            // 
            this.BtnRsz.AutoSize = true;
            this.BtnRsz.Location = new System.Drawing.Point(391, 132);
            this.BtnRsz.Name = "BtnRsz";
            this.BtnRsz.Size = new System.Drawing.Size(82, 26);
            this.BtnRsz.TabIndex = 19;
            this.BtnRsz.Text = "更動大小";
            this.BtnRsz.UseVisualStyleBackColor = true;
            this.BtnRsz.Click += new System.EventHandler(this.BtnRsz_Click);
            // 
            // BtnSplit
            // 
            this.BtnSplit.AutoSize = true;
            this.BtnSplit.Location = new System.Drawing.Point(391, 186);
            this.BtnSplit.Name = "BtnSplit";
            this.BtnSplit.Size = new System.Drawing.Size(82, 26);
            this.BtnSplit.TabIndex = 20;
            this.BtnSplit.Text = "切割字串";
            this.BtnSplit.UseVisualStyleBackColor = true;
            this.BtnSplit.Click += new System.EventHandler(this.BtnSplit_Click);
            // 
            // LblSrc
            // 
            this.LblSrc.AutoSize = true;
            this.LblSrc.Location = new System.Drawing.Point(487, 41);
            this.LblSrc.Name = "LblSrc";
            this.LblSrc.Size = new System.Drawing.Size(56, 16);
            this.LblSrc.TabIndex = 21;
            this.LblSrc.Text = "來源：";
            // 
            // LblTgt
            // 
            this.LblTgt.AutoSize = true;
            this.LblTgt.Location = new System.Drawing.Point(487, 72);
            this.LblTgt.Name = "LblTgt";
            this.LblTgt.Size = new System.Drawing.Size(56, 16);
            this.LblTgt.TabIndex = 22;
            this.LblTgt.Text = "目的：";
            // 
            // LblSrc1
            // 
            this.LblSrc1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.LblSrc1.Location = new System.Drawing.Point(539, 41);
            this.LblSrc1.Name = "LblSrc1";
            this.LblSrc1.Size = new System.Drawing.Size(30, 20);
            this.LblSrc1.TabIndex = 23;
            this.LblSrc1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // LblSrc2
            // 
            this.LblSrc2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.LblSrc2.Location = new System.Drawing.Point(566, 41);
            this.LblSrc2.Name = "LblSrc2";
            this.LblSrc2.Size = new System.Drawing.Size(30, 20);
            this.LblSrc2.TabIndex = 24;
            this.LblSrc2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // LblSrc3
            // 
            this.LblSrc3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.LblSrc3.Location = new System.Drawing.Point(592, 41);
            this.LblSrc3.Name = "LblSrc3";
            this.LblSrc3.Size = new System.Drawing.Size(30, 20);
            this.LblSrc3.TabIndex = 25;
            this.LblSrc3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // LblSrc4
            // 
            this.LblSrc4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.LblSrc4.Location = new System.Drawing.Point(619, 41);
            this.LblSrc4.Name = "LblSrc4";
            this.LblSrc4.Size = new System.Drawing.Size(30, 20);
            this.LblSrc4.TabIndex = 26;
            this.LblSrc4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // LblSrc5
            // 
            this.LblSrc5.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.LblSrc5.Location = new System.Drawing.Point(645, 41);
            this.LblSrc5.Name = "LblSrc5";
            this.LblSrc5.Size = new System.Drawing.Size(30, 20);
            this.LblSrc5.TabIndex = 27;
            this.LblSrc5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // LblSrc6
            // 
            this.LblSrc6.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.LblSrc6.Location = new System.Drawing.Point(671, 41);
            this.LblSrc6.Name = "LblSrc6";
            this.LblSrc6.Size = new System.Drawing.Size(30, 20);
            this.LblSrc6.TabIndex = 28;
            this.LblSrc6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // LblSrc7
            // 
            this.LblSrc7.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.LblSrc7.Location = new System.Drawing.Point(698, 41);
            this.LblSrc7.Name = "LblSrc7";
            this.LblSrc7.Size = new System.Drawing.Size(30, 20);
            this.LblSrc7.TabIndex = 29;
            this.LblSrc7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // LblTgt7
            // 
            this.LblTgt7.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.LblTgt7.Location = new System.Drawing.Point(698, 72);
            this.LblTgt7.Name = "LblTgt7";
            this.LblTgt7.Size = new System.Drawing.Size(30, 20);
            this.LblTgt7.TabIndex = 36;
            this.LblTgt7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // LblTgt6
            // 
            this.LblTgt6.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.LblTgt6.Location = new System.Drawing.Point(671, 72);
            this.LblTgt6.Name = "LblTgt6";
            this.LblTgt6.Size = new System.Drawing.Size(30, 20);
            this.LblTgt6.TabIndex = 35;
            this.LblTgt6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // LblTgt5
            // 
            this.LblTgt5.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.LblTgt5.Location = new System.Drawing.Point(645, 72);
            this.LblTgt5.Name = "LblTgt5";
            this.LblTgt5.Size = new System.Drawing.Size(30, 20);
            this.LblTgt5.TabIndex = 34;
            this.LblTgt5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // LblTgt4
            // 
            this.LblTgt4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.LblTgt4.Location = new System.Drawing.Point(619, 72);
            this.LblTgt4.Name = "LblTgt4";
            this.LblTgt4.Size = new System.Drawing.Size(30, 20);
            this.LblTgt4.TabIndex = 33;
            this.LblTgt4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // LblTgt3
            // 
            this.LblTgt3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.LblTgt3.Location = new System.Drawing.Point(592, 72);
            this.LblTgt3.Name = "LblTgt3";
            this.LblTgt3.Size = new System.Drawing.Size(30, 20);
            this.LblTgt3.TabIndex = 32;
            this.LblTgt3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // LblTgt2
            // 
            this.LblTgt2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.LblTgt2.Location = new System.Drawing.Point(566, 72);
            this.LblTgt2.Name = "LblTgt2";
            this.LblTgt2.Size = new System.Drawing.Size(30, 20);
            this.LblTgt2.TabIndex = 31;
            this.LblTgt2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // LblTgt1
            // 
            this.LblTgt1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.LblTgt1.Location = new System.Drawing.Point(539, 72);
            this.LblTgt1.Name = "LblTgt1";
            this.LblTgt1.Size = new System.Drawing.Size(30, 20);
            this.LblTgt1.TabIndex = 30;
            this.LblTgt1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // FrmSortSrch
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.ClientSize = new System.Drawing.Size(765, 254);
            this.Controls.Add(this.LblTgt7);
            this.Controls.Add(this.LblTgt6);
            this.Controls.Add(this.LblTgt5);
            this.Controls.Add(this.LblTgt4);
            this.Controls.Add(this.LblTgt3);
            this.Controls.Add(this.LblTgt2);
            this.Controls.Add(this.LblTgt1);
            this.Controls.Add(this.LblSrc7);
            this.Controls.Add(this.LblSrc6);
            this.Controls.Add(this.LblSrc5);
            this.Controls.Add(this.LblSrc4);
            this.Controls.Add(this.LblSrc3);
            this.Controls.Add(this.LblSrc2);
            this.Controls.Add(this.LblSrc1);
            this.Controls.Add(this.LblTgt);
            this.Controls.Add(this.LblSrc);
            this.Controls.Add(this.BtnSplit);
            this.Controls.Add(this.BtnRsz);
            this.Controls.Add(this.BtnCpClr);
            this.Controls.Add(this.BtnRnkLnth);
            this.Controls.Add(this.LblScoreS3);
            this.Controls.Add(this.LblScoreS2);
            this.Controls.Add(this.LblScoreS1);
            this.Controls.Add(this.LblScoreS0);
            this.Controls.Add(this.LblScoreS);
            this.Controls.Add(this.LblScore2);
            this.Controls.Add(this.LblScore1);
            this.Controls.Add(this.LblScore0);
            this.Controls.Add(this.LblScore);
            this.Controls.Add(this.LblName2);
            this.Controls.Add(this.LblName1);
            this.Controls.Add(this.LblName0);
            this.Controls.Add(this.LblName);
            this.Controls.Add(this.BtnSrch);
            this.Controls.Add(this.BtnRvs);
            this.Controls.Add(this.BtnSort);
            this.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "FrmSortSrch";
            this.Text = "陣列排序搜尋";
            this.Load += new System.EventHandler(this.FrmSortSrch_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button BtnSort;
        private System.Windows.Forms.Button BtnRvs;
        private System.Windows.Forms.Button BtnSrch;
        private System.Windows.Forms.Label LblName;
        private System.Windows.Forms.Label LblName0;
        private System.Windows.Forms.Label LblName1;
        private System.Windows.Forms.Label LblName2;
        private System.Windows.Forms.Label LblScore2;
        private System.Windows.Forms.Label LblScore1;
        private System.Windows.Forms.Label LblScore0;
        private System.Windows.Forms.Label LblScore;
        private System.Windows.Forms.Label LblScoreS2;
        private System.Windows.Forms.Label LblScoreS1;
        private System.Windows.Forms.Label LblScoreS0;
        private System.Windows.Forms.Label LblScoreS;
        private System.Windows.Forms.Label LblScoreS3;
        private System.Windows.Forms.Button BtnRnkLnth;
        private System.Windows.Forms.Button BtnCpClr;
        private System.Windows.Forms.Button BtnRsz;
        private System.Windows.Forms.Button BtnSplit;
        private System.Windows.Forms.Label LblSrc;
        private System.Windows.Forms.Label LblTgt;
        private System.Windows.Forms.Label LblSrc1;
        private System.Windows.Forms.Label LblSrc2;
        private System.Windows.Forms.Label LblSrc3;
        private System.Windows.Forms.Label LblSrc4;
        private System.Windows.Forms.Label LblSrc5;
        private System.Windows.Forms.Label LblSrc6;
        private System.Windows.Forms.Label LblSrc7;
        private System.Windows.Forms.Label LblTgt7;
        private System.Windows.Forms.Label LblTgt6;
        private System.Windows.Forms.Label LblTgt5;
        private System.Windows.Forms.Label LblTgt4;
        private System.Windows.Forms.Label LblTgt3;
        private System.Windows.Forms.Label LblTgt2;
        private System.Windows.Forms.Label LblTgt1;
    }
}

