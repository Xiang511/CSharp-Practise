﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _2_3Operator
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void BtnArthOp_Click(object sender, EventArgs e)
        {
            MessageBox.Show("5/2=" + (5 / 2).ToString());
            MessageBox.Show("10%3=" + (10 % 3).ToString());
        }

        private void BtnRelaOp_Click(object sender, EventArgs e)
        {
            string StrOut = "\'A\' < \'a\'是";
            MessageBox.Show(StrOut + ('A' < 'a').ToString());
            StrOut = "\'b\' < \'a\'是";
            MessageBox.Show(StrOut + ('b' < 'a').ToString());
            StrOut = "\'A\' > \'8\'是";
            MessageBox.Show(StrOut + ('A' > '8').ToString());
            StrOut = "\'A\' == \'8\'是";
            MessageBox.Show(StrOut + ('A' == '8').ToString());
            StrOut = "\'A\' != \'8\'是";
            MessageBox.Show(StrOut + ('A' != '8').ToString());
            StrOut = "\"Apple\" == \"apple\"是";
            MessageBox.Show(StrOut + ("Apple" == "apple").ToString());
            StrOut = "\"Apple\" != \"apple\"是";
            //MessageBox.Show(StrOut + ("Apple" != "apple").ToString());
            //MessageBox.Show(("Apple" > "apple").ToString());//字串不能比大小
            //MessageBox.Show(("Apple" < "apple").ToString());//字串不能比大小
            //MessageBox.Show(("Apple" >= "apple").ToString());//字串不能比大小
            //MessageBox.Show(("Apple" <= "apple").ToString());//字串不能比大小
        }

        private void BtnLgOp_Click(object sender, EventArgs e)
        {
            bool A, B;
            A = true; B = true; MessageBox.Show("A: " + A + "B: " + B + "\n" + "A && B是" + (A && B).ToString() + "\n" + "A || B是" + (A || B).ToString() + "\n" + "!A是" + (!A).ToString());
            A = true; B = false; MessageBox.Show("A: " + A + "B: " + B + "\n" + "A && B是" + (A && B).ToString() + "\n" + "A || B是" + (A || B).ToString() + "\n" + "!A是" + (!A).ToString());
            A = false; B = true; MessageBox.Show("A: " + A + "B: " + B + "\n" + "A && B是" + (A && B).ToString() + "\n" + "A || B是" + (A || B).ToString() + "\n" + "!A是" + (!A).ToString());
            A = false; B = false; MessageBox.Show("A: " + A + "B: " + B + "\n" + "A && B是" + (A && B).ToString() + "\n" + "A || B是" + (A || B).ToString() + "\n" + "!A是" + (!A).ToString());
            short score;
            do
            {
                string StrIn = Microsoft.VisualBasic.Interaction.InputBox("請輸入介於0~100的分數(正整數)", "輸入分數(邏輯運算簡例)");
                if (StrIn == "") { MessageBox.Show("輸入空字串或按取消表跳出此程序"); return; }
                try { score = Convert.ToInt16(StrIn); }
                catch { MessageBox.Show("輸入非整數或不在範圍"); continue; }
                if ((score < 0) || (score > 100)) { MessageBox.Show("輸入超出範圍"); continue; }
                if ((score >= 0) && (score < 60)) MessageBox.Show(score + "分，不及格");//在此(score >= 0)是多餘的，因為上面已有判斷介於0~100
                else MessageBox.Show(score + "分，及格");
            } while (true);
        }

        private void BtnBitOp_Click(object sender, EventArgs e)
        {
            MessageBox.Show("3&8=" + (3 & 8).ToString());//此例int前面位元皆是0，所以沒有影響
            MessageBox.Show("3|8=" + (3 | 8).ToString());//所以只看最後4位元0011及1000，and變0、or如同相加
            MessageBox.Show("3^8=" + (3 ^ 8).ToString());//XOR互斥結果同or
            MessageBox.Show("(~3).ToString()=" + (~3).ToString());//以有號數運算not~即取1的補數，所以2的補數得負數~3+1=-3，故~3=-4
            MessageBox.Show("(~((byte)3)).ToString()=" + (~((byte)3)).ToString());//3先轉成byte，但取not前又會轉型為int，所以仍為-4
            //MessageBox.Show("~3=" + ((byte)(~3)).ToString());//~3=-4不能轉為byte，編繹器建議用unchecked
            //MessageBox.Show("~3=" + unchecked(byte)(~3).ToString());//但用了仍不行，所以我試了宣告byte i = 3
            byte i = 3;
            MessageBox.Show("byte i = 3;(~i).ToString()=" + (~i).ToString());//但也不是直接取not就可以，要再強制轉byte，否則以整數計
            MessageBox.Show("byte i = 3;((byte)(~i)).ToString()=" + ((byte)(~i)).ToString());//byte為無號數，1的補數與原數相加為最大值，在此為255，所以~3=252
        }

        private void BtnShiftOp_Click(object sender, EventArgs e)
        {//此處以8位元為例，預設是32位元
            byte i = 127, j = 255;
            byte k = (byte)(i << 1);
            //byte k = (i << 1);//需強制轉型，因為(i << 1)變成int型別
            int m= (i << 1);//不用轉
            sbyte A = 127;
            sbyte B = (sbyte)(A << 1);
            //sbyte B = (A << 1);//需強制轉型，因為(A << 1)變成int型別
            MessageBox.Show("sbyte 127 (01111111)<<1 = " + B.ToString() + " (11111110)");
            MessageBox.Show("sbyte 127 (01111111)>>1 = " + ((sbyte)(A >> 1)).ToString() + " (00111111)");
            MessageBox.Show("byte 127 (01111111)<<1 = " + ((byte)(i << 1)).ToString() + " (11111110)");
            MessageBox.Show("byte 127 (01111111)>>1 = " + ((byte)(i >> 1)).ToString() + " (00111111)");
            MessageBox.Show("byte 255 (11111111)<<1 = " + ((byte)(j << 1)).ToString() + " (11111110)");
            MessageBox.Show("byte 255 (11111111)>>1 = " + ((byte)(j >> 1)).ToString() + " (01111111)");
            char x, y = '2';
            x = (char)(y << 1);//需強制轉型，因為(y << 1)變成int型別
            int z= y << 1;//不用轉型
            MessageBox.Show("\'2\' (50)<<1 = " + x.ToString() + "(字元)");
            MessageBox.Show("\'2\' (50)<<1 = " + z.ToString() + "(整數)");
        }

        private void BtnCbnAsgOp_Click(object sender, EventArgs e)
        {
            int i = 100;
            MessageBox.Show("i=" + i + "則i+=3結果i=" + (i += 3).ToString());
            MessageBox.Show("i=" + i + "則i-=3結果i=" + (i -= 3).ToString());
            MessageBox.Show("i=" + i + "則i*=3結果i=" + (i *= 3).ToString());
            MessageBox.Show("i=" + i + "則i/=3結果i=" + (i /= 3).ToString());
            MessageBox.Show("i=" + i + "則i%=3結果i=" + (i %= 3).ToString());
            i = 100;
            MessageBox.Show("i=" + i + "則i&=3 (0...11)結果i=" + (i &= 3).ToString());
            MessageBox.Show("i=" + i + "則i|=3 (0...11)結果i=" + (i |= 3).ToString());
            MessageBox.Show("i=" + i + "則i^=3 (0...11)結果i=" + (i ^= 3).ToString());
            i = 100;
            MessageBox.Show("i=" + i + "則i<<=3結果i=" + (i <<= 3).ToString());
            MessageBox.Show("i=" + i + "則i>>=3結果i=" + (i >>= 3).ToString());
        }

        private void BtnInDesOp_Click(object sender, EventArgs e)
        {
            int i,j;
            j = 1; i = j++;
            MessageBox.Show("i=j++;結果i=" + i + ", j=" + j);
            j = 1; i = ++j;
            MessageBox.Show("i=++j;結果i=" + i + ", j=" + j);
            j = 1; i = j++ * 2;
            MessageBox.Show("i=j++ * 2;結果i=" + i + ", j=" + j);
            j = 1; i = ++j * 2;
            MessageBox.Show("i=++j * 2;結果i=" + i + ", j=" + j);
            j = 1; i = j++ + (5 * j);
            MessageBox.Show("i=j++ + (5 * j);結果i=" + i + ", j=" + j);
        }
    }
}
