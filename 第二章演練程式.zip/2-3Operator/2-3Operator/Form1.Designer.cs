﻿namespace _2_3Operator
{
    partial class Form1
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.BtnArthOp = new System.Windows.Forms.Button();
            this.BtnRelaOp = new System.Windows.Forms.Button();
            this.BtnLgOp = new System.Windows.Forms.Button();
            this.BtnBitOp = new System.Windows.Forms.Button();
            this.BtnShiftOp = new System.Windows.Forms.Button();
            this.BtnCbnAsgOp = new System.Windows.Forms.Button();
            this.BtnInDesOp = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // BtnArthOp
            // 
            this.BtnArthOp.AutoSize = true;
            this.BtnArthOp.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.BtnArthOp.Location = new System.Drawing.Point(28, 26);
            this.BtnArthOp.Name = "BtnArthOp";
            this.BtnArthOp.Size = new System.Drawing.Size(98, 26);
            this.BtnArthOp.TabIndex = 0;
            this.BtnArthOp.Text = "算術運算子";
            this.BtnArthOp.UseVisualStyleBackColor = true;
            this.BtnArthOp.Click += new System.EventHandler(this.BtnArthOp_Click);
            // 
            // BtnRelaOp
            // 
            this.BtnRelaOp.AutoSize = true;
            this.BtnRelaOp.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.BtnRelaOp.Location = new System.Drawing.Point(165, 26);
            this.BtnRelaOp.Name = "BtnRelaOp";
            this.BtnRelaOp.Size = new System.Drawing.Size(98, 26);
            this.BtnRelaOp.TabIndex = 3;
            this.BtnRelaOp.Text = "關係運算子";
            this.BtnRelaOp.UseVisualStyleBackColor = true;
            this.BtnRelaOp.Click += new System.EventHandler(this.BtnRelaOp_Click);
            // 
            // BtnLgOp
            // 
            this.BtnLgOp.AutoSize = true;
            this.BtnLgOp.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.BtnLgOp.Location = new System.Drawing.Point(307, 26);
            this.BtnLgOp.Name = "BtnLgOp";
            this.BtnLgOp.Size = new System.Drawing.Size(98, 26);
            this.BtnLgOp.TabIndex = 4;
            this.BtnLgOp.Text = "邏輯運算子";
            this.BtnLgOp.UseVisualStyleBackColor = true;
            this.BtnLgOp.Click += new System.EventHandler(this.BtnLgOp_Click);
            // 
            // BtnBitOp
            // 
            this.BtnBitOp.AutoSize = true;
            this.BtnBitOp.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.BtnBitOp.Location = new System.Drawing.Point(28, 79);
            this.BtnBitOp.Name = "BtnBitOp";
            this.BtnBitOp.Size = new System.Drawing.Size(98, 26);
            this.BtnBitOp.TabIndex = 5;
            this.BtnBitOp.Text = "位元運算子";
            this.BtnBitOp.UseVisualStyleBackColor = true;
            this.BtnBitOp.Click += new System.EventHandler(this.BtnBitOp_Click);
            // 
            // BtnShiftOp
            // 
            this.BtnShiftOp.AutoSize = true;
            this.BtnShiftOp.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.BtnShiftOp.Location = new System.Drawing.Point(165, 79);
            this.BtnShiftOp.Name = "BtnShiftOp";
            this.BtnShiftOp.Size = new System.Drawing.Size(98, 26);
            this.BtnShiftOp.TabIndex = 6;
            this.BtnShiftOp.Text = "移位運算子";
            this.BtnShiftOp.UseVisualStyleBackColor = true;
            this.BtnShiftOp.Click += new System.EventHandler(this.BtnShiftOp_Click);
            // 
            // BtnCbnAsgOp
            // 
            this.BtnCbnAsgOp.AutoSize = true;
            this.BtnCbnAsgOp.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.BtnCbnAsgOp.Location = new System.Drawing.Point(28, 135);
            this.BtnCbnAsgOp.Name = "BtnCbnAsgOp";
            this.BtnCbnAsgOp.Size = new System.Drawing.Size(130, 26);
            this.BtnCbnAsgOp.TabIndex = 7;
            this.BtnCbnAsgOp.Text = "複合指定運算子";
            this.BtnCbnAsgOp.UseVisualStyleBackColor = true;
            this.BtnCbnAsgOp.Click += new System.EventHandler(this.BtnCbnAsgOp_Click);
            // 
            // BtnInDesOp
            // 
            this.BtnInDesOp.AutoSize = true;
            this.BtnInDesOp.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.BtnInDesOp.Location = new System.Drawing.Point(202, 135);
            this.BtnInDesOp.Name = "BtnInDesOp";
            this.BtnInDesOp.Size = new System.Drawing.Size(130, 26);
            this.BtnInDesOp.TabIndex = 8;
            this.BtnInDesOp.Text = "遞增遞減運算子";
            this.BtnInDesOp.UseVisualStyleBackColor = true;
            this.BtnInDesOp.Click += new System.EventHandler(this.BtnInDesOp_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(440, 201);
            this.Controls.Add(this.BtnInDesOp);
            this.Controls.Add(this.BtnCbnAsgOp);
            this.Controls.Add(this.BtnShiftOp);
            this.Controls.Add(this.BtnBitOp);
            this.Controls.Add(this.BtnLgOp);
            this.Controls.Add(this.BtnRelaOp);
            this.Controls.Add(this.BtnArthOp);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button BtnArthOp;
        private System.Windows.Forms.Button BtnRelaOp;
        private System.Windows.Forms.Button BtnLgOp;
        private System.Windows.Forms.Button BtnBitOp;
        private System.Windows.Forms.Button BtnShiftOp;
        private System.Windows.Forms.Button BtnCbnAsgOp;
        private System.Windows.Forms.Button BtnInDesOp;
    }
}

