﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _2_2VarConst
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {/*                                                  
            可
            以
            夾
            住
            多
            行
            註
            解
           */
            int A_Int; //宣告A_Int為整數型別，配置4 bytes空間
            A_Int = 20; //給初值20
            int IntB = 50;//宣告與給初值同時
            int i, j = 10, k;//多個同時宣告，也可以部分變數給初值
            char CharA1 = 'a';//最常用
            MessageBox.Show("'a'結果是：" + CharA1.ToString());
            char CharA2 = (char)97;//用強制轉型
            MessageBox.Show("(char)97結果是：" + CharA2.ToString());
            char CharA3 = '\u0061';//表示成Unicode，得用跳脫字元反斜線，再加特殊字元u
            MessageBox.Show("\'\\u0061\'結果是：" + CharA3.ToString());
            char CharA4 = '\x0061';//表示成ASCII，得用跳脫字元反斜線，再加特殊字元x
            MessageBox.Show("\'\\x0061\'結果是：" + CharA4.ToString());
            string StrA; StrA = "這是字串A";
            string StrB = "這是字串B";
            string StrC = StrA + StrB;
            MessageBox.Show("\"這是字串A\"+\"這是字串B\"結果是：" + StrC);

            Application.Exit();

            const double PI = 3.14;//
            const float FConst = 3.5f;
            //const float FConst1 = 3.5;//預設是double，需轉型
            const long LongConst1 = 4347483649;//課本說預設是int，其實不然，系統會自行判斷用32或64位元有無號
            const long LongConst2 = 50L;
            const long LongConst3 = 50;//不加後置字元也可以，因為int放置到long沒問題
            const short ShortgConst = 64;//int轉short也沒有問題，因為64在short的範圍內
            //const short ShortgConst1 = 32768;//int轉short有問題，因為32768在short的範圍內
            const ushort ShortgConst2 = 32768;//int轉ushort沒有問題，因為32768在ushort的範圍內
        }
    }
}
