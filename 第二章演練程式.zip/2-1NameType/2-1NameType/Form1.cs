﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _2_1NameType
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private void Demo2_1()
        {
            //命名規則
            int A, a, Name, StdtName;//合法命名
            /*int if;
            int for;
            int 4A;
            int A BC;//不合法命名 */
            double A4, a_4, @if, @for, 中文 ;//合法命名

            //常值
            //A = 3 + 0.0;//整數加或乘實數變成實數，不能直接存到整數
            //a = 3 * 0.0;
            A4 = 3 + 3.2E-5;
            a_4 = 3 * -1E0;

            //byte B = 256;//超過範圍
            byte B = 255;
            sbyte sB;
            short ST;
            ushort uST;
            int IT;
            uint uIT;
            long LN;
            ulong uLN;
            float FL = 1.2f;//f大小寫皆可，不加會錯，因為預設是double
            double DB = 1.3;//這是實數預設型別，不用加後置字元
            decimal DM = 1.4m;//m大小寫皆可，不加會錯
            bool BL=true, BLF= false;//要用小寫
            char C = 'A', C2 = '義';
            //char C = A, C2 = "義";//型別不符
            string Str = "A+a", Str2 = "123";
            //string Str3 = 'A';//型別不符
            object OB1 = "物件", OB2 = 3, OB3 = 7.7;
            //LN = 1 + 2UL;//轉成無號長整數，不能存到長整數
            uLN = 1 + 2UL;
            //uST = 2U;//U會轉成無號整數，32位元。整數值系統會視大小給予型別int或long
            uIT = 2U;
            DB = 6 + 0.0;//6+0.0自動轉成double
            //IT = 6 + 0.0;//不可存到整數
            //FL = 6 + 0.0;//不可存至float
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            float FL = 1234.9876f;
            MessageBox.Show("單精準浮點數float 1234.9876，因精準度只有7位，故只會秀出"+FL.ToString());//只會秀出1234.988
            MessageBox.Show("5 / 2整數相除，只會秀出" + (5 / 2).ToString()+"，小數部分無條件捨去");
            MessageBox.Show("5.0 / 2是浮點數除以整數，整數也會轉成浮點數，結果為：" + (5.0 / 2).ToString());
            //long LN = 9223372036854775808;//超過有號長整數最大值
            ulong uLN = 9223372036854775808;
            double x = 18446744073709551616d;
            //double x = 18446744073709551616;//超過無號長整數最大值，不能表成整數
            MessageBox.Show("18446744073709551616超過ulong的範圍(最大值)轉double，結果：" + x.ToString());//double的精準度只能15位
            decimal y = 18446744073709551616m;
            //decimal y = 18446744073709551616;//超過無號長整數最大值，不能表成整數
            MessageBox.Show("18446744073709551616在decimal的範圍轉decimal，結果：" + y.ToString());
            string Str = "" + 'a';
            //MessageBox.Show('a');//型別不符
            MessageBox.Show("使用\"\" + \'a\'把字元a轉成字串" + Str);
            MessageBox.Show("使用\'a\'.ToString()把字元a轉成字串" + 'a'.ToString());//兩個方式一樣
            Application.Exit();
        }
    }
}
