﻿namespace _2_3TypeConver
{
    partial class Form1
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.BtnGetType = new System.Windows.Forms.Button();
            this.BtnShtSB = new System.Windows.Forms.Button();
            this.Btn2Str = new System.Windows.Forms.Button();
            this.Dble2Int = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // BtnGetType
            // 
            this.BtnGetType.AutoSize = true;
            this.BtnGetType.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.BtnGetType.Location = new System.Drawing.Point(28, 25);
            this.BtnGetType.Name = "BtnGetType";
            this.BtnGetType.Size = new System.Drawing.Size(75, 26);
            this.BtnGetType.TabIndex = 0;
            this.BtnGetType.Text = "GetType";
            this.BtnGetType.UseVisualStyleBackColor = true;
            this.BtnGetType.Click += new System.EventHandler(this.BtnGetType_Click);
            // 
            // BtnShtSB
            // 
            this.BtnShtSB.AutoSize = true;
            this.BtnShtSB.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.BtnShtSB.Location = new System.Drawing.Point(137, 25);
            this.BtnShtSB.Name = "BtnShtSB";
            this.BtnShtSB.Size = new System.Drawing.Size(98, 26);
            this.BtnShtSB.TabIndex = 1;
            this.BtnShtSB.Text = "short轉sbyte";
            this.BtnShtSB.UseVisualStyleBackColor = true;
            this.BtnShtSB.Click += new System.EventHandler(this.BtnShtSB_Click);
            // 
            // Btn2Str
            // 
            this.Btn2Str.AutoSize = true;
            this.Btn2Str.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Btn2Str.Location = new System.Drawing.Point(137, 80);
            this.Btn2Str.Name = "Btn2Str";
            this.Btn2Str.Size = new System.Drawing.Size(98, 26);
            this.Btn2Str.TabIndex = 3;
            this.Btn2Str.Text = "轉換成字串";
            this.Btn2Str.UseVisualStyleBackColor = true;
            this.Btn2Str.Click += new System.EventHandler(this.Btn2Str_Click);
            // 
            // Dble2Int
            // 
            this.Dble2Int.AutoSize = true;
            this.Dble2Int.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Dble2Int.Location = new System.Drawing.Point(28, 80);
            this.Dble2Int.Name = "Dble2Int";
            this.Dble2Int.Size = new System.Drawing.Size(98, 26);
            this.Dble2Int.TabIndex = 2;
            this.Dble2Int.Text = "浮點整數轉";
            this.Dble2Int.UseVisualStyleBackColor = true;
            this.Dble2Int.Click += new System.EventHandler(this.Dble2Int_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(282, 136);
            this.Controls.Add(this.Dble2Int);
            this.Controls.Add(this.Btn2Str);
            this.Controls.Add(this.BtnShtSB);
            this.Controls.Add(this.BtnGetType);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button BtnGetType;
        private System.Windows.Forms.Button BtnShtSB;
        private System.Windows.Forms.Button Btn2Str;
        private System.Windows.Forms.Button Dble2Int;
    }
}

