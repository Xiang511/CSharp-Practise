﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _2_3TypeConver
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void BtnGetType_Click(object sender, EventArgs e)
        {
            MessageBox.Show("12.3的型別為" + (12.3).GetType());
        }

        private void BtnShtSB_Click(object sender, EventArgs e)
        {
            int i = 10; double x; x = i * 1.2; //可自動轉型
            //int j; double y = 1.6; j = y + 3; //編譯會有錯誤，須明確轉型
            short k = 128; sbyte m; m = (sbyte)k;//結果j=-128
            MessageBox.Show("short k=" + k + " (00000000 10000000), " + "sbyte m = (sbyte)k=" + m + " (10000000)");
            k = -129; m = (sbyte)k;//結果j=127
            MessageBox.Show("short k=" + k + " (11111111 01111111), " + "sbyte m = (sbyte)k=" + m + " (01111111)");
        }

        private void Dble2Int_Click(object sender, EventArgs e)
        {
            int i = 10;
            double x = i * 1.2; //可自動轉型
            MessageBox.Show("int i=10; double x = i * 1.2可自動轉型，結果x = " + x.ToString());
            //x = 1.6; i = x + 3; //編譯會有錯誤，須明確轉型
            x = 1.6; i = (int)x + 3;//強制轉型結果i=4，有誤差
            MessageBox.Show("x = 1.6; i = (int)x + 3，結果會有誤差，強制轉型小數無條件捨去i = " + i.ToString());
        }

        private void Btn2Str_Click(object sender, EventArgs e)
        {
            int i = 3; string a = "沒有"; string b = a + i;
            MessageBox.Show("int i = 3加string a = \"沒有\"，int i會自動轉為字串，結果為：" + b);
            string StrA = Convert.ToString(3.14);
            MessageBox.Show("用Convert.ToString(3.14)將數值3.14轉成字串3.14，結果為" + StrA);
            Double PI = 3.14; string StrB = PI.ToString();
            MessageBox.Show("用(變數).ToString()將數值3.14轉成字串3.14，結果為" + StrB);
            string StrC = (3.14).ToString();
            MessageBox.Show("用(常值).ToString()將數值3.14轉成字串3.14，結果為" + StrC);
        }

    }
}
