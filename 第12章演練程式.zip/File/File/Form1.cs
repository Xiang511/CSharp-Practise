﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace File
{
    public partial class FrmTxtFile : Form
    {
        public FrmTxtFile()
        {
            InitializeComponent();
        }

        private void BtnOneTch_Click(object sender, EventArgs e)
        {//將演練所有程序統整在此事件處理函式，雖然引數sender和e可能怪怪的
            BtnNewCrt_Click(sender, e);//產生目錄.\one\test
            BtnNewCrt_Click(sender, e);//目錄.\one\test已存在，故不會再產生
            BtnDelOne_Click(sender, e);//刪除目錄one (未給定引數或給false)，發生例外，因為有子目錄test
            BtnDelTest_Click(sender, e);//刪除目錄test
            BtnDelOne_Click(sender, e);//再刪除目錄one，則會成功
            BtnNewCrt_Click(sender, e);//再產生目錄.\one\test供刪除測試
            BtnDelOneT_Click(sender, e);//若設定引數true，則即使目錄未空，仍可將目錄內所有刪除
            BtnDelOne_Click(sender, e);//若目錄不存在，再刪除目錄one，會發生例外
            BtnDelOneT_Click(sender, e);//不管是否有加true，刪除不存在目錄者會發生例外
            BtnNewCrt_Click(sender, e);//再產生目錄.\one\test供搬移測試
            BtnMv2_Click(sender, e);//將目錄one全部搬移到目錄two
            BtnMv2_Click(sender, e);//來源目錄已不存在，再試搬移一次，看看會發生什麼
            BtnNewCrt_Click(sender, e);//再產生目錄.\one\test，供再搬移測試
            BtnMv2_Click(sender, e);//目的目錄已存在，再試搬移一次，看看會發生什麼
            BtnDelOneT_Click(sender, e);//若設定引數true，則即使目錄未空，仍可將目錄內所有刪除
            BtnFileCrt_Click(sender, e);//示範目錄不存在，若要產生檔案會發生例外
            BtnNewCrt_Click(sender, e);//產生目錄.\one\test以供產生檔案
            BtnFileCrt_Click(sender, e);//目錄存在，可正常產生檔案
            BtnFileCp_Click(sender, e);//複製檔案，覆蓋及未覆蓋方式
            BtnFileDelMv_Click(sender, e);//搬移檔案，若目的檔存在則先刪除
            BtnFilePpt_Click(sender, e);//檔案的各種屬性，檔案不存在因為Move，Length屬性讀不出發生例外
            BtnWLApp_Click(sender, e);//寫入一行，全新及附加二種方式
            BtnRd_Click(sender, e);//一字一字讀，直到檔案結束（Peek傳回-1）
            BtnRdLn_Click(sender, e);//由現在位置（第11個字），一行一行讀，直到檔案結束（讀到空行null）
            BtnRd2End_Click(sender, e);//由現在位置（第六個字），直接讀到檔案最後
        }

        //因為這些目錄在很多函式出現，所以用全域變數先宣告
        DirectoryInfo DirOne = new DirectoryInfo(@".\one");
        DirectoryInfo DirOneTest = new DirectoryInfo(@".\one\test");
        FileInfo FileOneH = new FileInfo(@".\one\hello.txt");
        FileInfo FileOneHi = new FileInfo(@".\one\hi.txt");

        private void FrmTxtFile_Load(object sender, EventArgs e)
        {//表單一載入，先將測試用的二個目錄one及two刪除，若存在的話，還原初始狀態
            if (DirOne.Exists) { DirOne.Delete(true); MessageBox.Show(@"刪除.\one底下所有"); }
            DirectoryInfo DirTwo = new DirectoryInfo(@".\two");
            if (DirTwo.Exists) { DirTwo.Delete(true); MessageBox.Show(@"刪除.\two底下所有"); }
        }

        private void BtnNewCrt_Click(object sender, EventArgs e)
        {//new建構後並不一定有該目錄，要Create後才有。經測試，即使目錄已存在，再new及Create也不會產生錯誤
            DirectoryInfo DirOneTest = new DirectoryInfo(@".\one\test");//有兩個名稱指向同一目錄，未發生問題
            if (DirOneTest.Exists) MessageBox.Show(@".\one\test已存在");
            else//若已有，則顯示已存在訊息。若非則產生並顯示產生訊息
            {
                DirOneTest.Create();
                MessageBox.Show(@"產生.\one\test");
            }
        }

        private void BtnDelOne_Click(object sender, EventArgs e)
        {//示範若已空則可刪，若非則例外。若先執行Del目錄Test，則可成功不加引數刪目錄One
            try
            {
                DirOne.Delete();//或DirOne.Delete(false)，未給引數或給引數false，必須目錄已空才行
                MessageBox.Show("刪除目錄one");
            }//若刪除成功則顯示刪除訊息，若非而是例外，則顯示例外訊息
            catch (Exception ex) { MessageBox.Show("刪除目錄one：" + ex.Message); }
        }

        private void BtnDelTest_Click(object sender, EventArgs e)
        {//示範若先執行Del目錄Test，才可成功不加引數刪目錄One
            try
            {
                DirOneTest.Delete();//或DirOneTest.Delete(false)，未給引數或給引數false，必須目錄已空才行
                MessageBox.Show("刪除目錄test");
            }//若刪除成功則顯示刪除訊息，若非而是例外，則顯示例外訊息
            catch (Exception ex) { MessageBox.Show("刪除目錄test：" + ex.Message); }
        }

        private void BtnDelOneT_Click(object sender, EventArgs e)
        {//示範加引數true，可成功刪目錄，不論空與否
            try
            {
                DirOne.Delete(true);//給引數true，即使目錄未空也會連目錄下所有檔案目錄全部刪除
                MessageBox.Show("設定引數true，刪除目錄one");
            }//若刪除成功則顯示刪除訊息，若非（例如目錄不存在，不能下刪除指令）而是例外，則顯示例外訊息
            catch (Exception ex) { MessageBox.Show("刪除目錄one：" + ex.Message); }
        }

        private void BtnMv2_Click(object sender, EventArgs e)
        {//重新建構目錄名稱，經測試，若使用全域名稱，因MoveTo會使得物件名稱代表新目錄而非舊目錄，以致一些操作會混淆

            DirectoryInfo DirInfo = new DirectoryInfo(@".\one");
            try
            {
                DirInfo.MoveTo(@".\two");//將目錄one全部搬移到目錄two，且DirInfo代表.\two，而不再是.\one
                MessageBox.Show("搬移目錄one到two");
            }//若搬移成功則顯示搬移訊息，若非而是例外，則顯示例外訊息
            catch (Exception ex) { MessageBox.Show("搬移目錄one到two" + ex.Message); }
        }

        private void BtnFileCrt_Click(object sender, EventArgs e)
        {//示範檔案(流)的產生及關閉，在此借用之前產生的目錄，有目錄才能產生檔案
            /*檔案未產生前取屬性，Length會產生例外。連帶讓後面判斷if (FileOneHi.Exists)誤判，
             * 且產生檔案後仍說檔案不存在，以致Length屬性仍例外
            string StrOut = "檔案尚未建立前屬性：\n";
            try { StrOut += "Length = " + FileOneH.Length + "\n"; }
            catch (Exception ex) { MessageBox.Show("取Length屬性，結果：" + ex.Message); }
            StrOut += "FullName = " + FileOneH.FullName + "\n";
            StrOut += "DirectoryName = " + FileOneH.DirectoryName + "\n";
            StrOut += "Name = " + FileOneH.Name + "\n";
            StrOut += "Extension = " + FileOneH.Extension + "\n";
            MessageBox.Show(StrOut);
            */
            try
            {//試產生檔案即產生FileStream，若檔案不存在會新建，若存在則只產生FileStream
                FileStream FSH = FileOneH.Create();//Create一定會產生FileStream，所以要宣告一個FileStream來承接
                MessageBox.Show(@"產生.\one\hello.txt");
                FSH.Close();//若後面還要對該檔案物件操作，要先把FileStream關閉，否則無法對指向該檔案物件操作
            }//若發生例外，例如目錄不存在，則秀出例外訊息
            catch (Exception ex) { MessageBox.Show(ex.Message); }
            /*目前實驗結果，只要在搬移前讓全域FileOneH判斷存在與否，就會記住是存在且記住屬性，搬移或刪除也不會忘記。即使不在這裡判斷，只要搬移前判斷即可，例如在搬移函式內
            if (FileOneH.Exists) { MessageBox.Show("beforemove:全域FileOneH存在："); }
            else MessageBox.Show("beforemove:全域FileOneH不存在");
            */
        }

        private void BtnFileCp_Click(object sender, EventArgs e)
        {//示範檔案的複製
            try
            {
                FileOneH.CopyTo(@".\one\hi.txt", true); //把FileOneH代表的檔案複製到.\one\hi.txt。true的引數表示若已存在，則覆寫。但若檔案被鎖住會發生例外
                MessageBox.Show(@"覆寫複製.\one\hello.txt到.\one\hi.txt");
                FileOneH.CopyTo(@".\one\hi.txt", false);//使用引數false表示不覆寫，用以示範若檔案存在，複製不覆寫會產生例外
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void BtnFileDelMv_Click(object sender, EventArgs e)
        {//示範檔案刪除及搬移。搬移時，若目的檔案已存在，會發生例外，所以此處先做判斷，若存在則刪除，以避免例外
            FileInfo MvFileOneH = new FileInfo(@".\one\hello.txt");
            FileInfo MvFileOneHi = new FileInfo(@".\one\hi.txt");
            /*目前實驗結果，只要在搬移前讓全域FileOneH判斷存在與否，就會記住是存在且記住屬性，搬移或刪除也不會忘記。即使不在這裡判斷，只要搬移前判斷即可，例如在產生後
            if (FileOneH.Exists) { MessageBox.Show("beforemove:全域FileOneH存在："); }
            else MessageBox.Show("beforemove:全域FileOneH不存在");
            try { MessageBox.Show("Length = " + FileOneH.Length); }
            catch (Exception ex) { MessageBox.Show("取Length屬性，結果：" + ex.Message); }
            */
            if (MvFileOneHi.Exists) { MvFileOneHi.Delete(); MessageBox.Show("檔案存在並刪除，以便示範搬移"); }
            //MvFileOneHi.Delete();//可以直接刪除，不做判斷，即使不存在也不會發生例外，上式只是為了示範Exists的屬性
            MvFileOneH.MoveTo(@".\one\hi.txt");//經測試，MoveTo不僅是檔案搬過去，連檔案物件也會指向新檔
            MessageBox.Show("區域名稱：MvFileOneH的檔名：" + MvFileOneH.Name + "。MvFileOneHi的檔名：" + MvFileOneHi.Name);
            MessageBox.Show("全域名稱：FileOneH的檔名：" + FileOneH.Name + "。FileOneHi的檔名：" + FileOneHi.Name);

            /*後面這部分都是在測試到底何時取Length不會發生例外，後來發現，全域變數需在搬移前讓它可以取一次屬性，例如做存在判斷，或直接取長度屬性
            if (FileOneH.Exists) { MessageBox.Show("aftermove:全域FileOneH存在：" + FileOneH.Name); }
            else MessageBox.Show("aftermove:全域FileOneH不存在");
            try { MessageBox.Show("Length = " + FileOneH.Length); }
            catch (Exception ex) { MessageBox.Show("取Length屬性，結果：" + ex.Message); }
            FileStream FSH = FileOneH.Create();
            if (FileOneH.Exists) { MessageBox.Show("afterCreate:全域FileOneH.Exists" + FileOneH.Name); }
            else MessageBox.Show("afterCreate:全域FileOneH不存在");
            try { MessageBox.Show("Length = " + FileOneH.Length); }
            catch (Exception ex) { MessageBox.Show("取Length屬性，結果：" + ex.Message); }
            FSH.Close();
            if (FileOneH.Exists) { MessageBox.Show("afterClose:全域FileOneH.Exists" + FileOneH.Name); }
            else MessageBox.Show("afterClose:全域FileOneH不存在");
            try { MessageBox.Show("Length = " + FileOneH.Length); }
            catch (Exception ex) { MessageBox.Show("取Length屬性，結果：" + ex.Message); }

            if (MvFileOneH.Exists) { MessageBox.Show("aftermove:區域MvFileOneH.Exists" + MvFileOneH.Name); }
            else MessageBox.Show("aftermove:區域MvFileOneH不存在");
            try { MessageBox.Show("Length = " + MvFileOneH.Length); }
            catch (Exception ex) { MessageBox.Show("取Length屬性，結果：" + ex.Message); }
            FileStream MvFSH = MvFileOneH.Create();
            if (MvFileOneH.Exists) { MessageBox.Show("afterCreate:區域MvFileOneH.Exists" + MvFileOneH.Name); }
            else MessageBox.Show("afterCreate:區域MvFileOneH不存在");
            try { MessageBox.Show("Length = " + MvFileOneH.Length); }
            catch (Exception ex) { MessageBox.Show("取Length屬性，結果：" + ex.Message); }
            MvFSH.Close();
            if (MvFileOneH.Exists) { MessageBox.Show("afterClose:區域MvFileOneH.Exists" + MvFileOneH.Name); }
            else MessageBox.Show("afterClose:區域MvFileOneH不存在");
            try { MessageBox.Show("Length = " + MvFileOneH.Length); }
            catch (Exception ex) { MessageBox.Show("取Length屬性，結果：" + ex.Message); }

            FileInfo MvFileOneH2 = new FileInfo(@".\one\hello.txt");
            if (MvFileOneH2.Exists) { MessageBox.Show("aftermove:新的MvFileOneH2.Exists" + MvFileOneH2.Name); }
            else MessageBox.Show("aftermove:新的MvFileOneH2不存在");
            try { MessageBox.Show("Length = " + MvFileOneH2.Length); }
            catch (Exception ex) { MessageBox.Show("取Length屬性，結果：" + ex.Message); }
            FileStream MvFSH2 = MvFileOneH2.Create();
            if (MvFileOneH2.Exists) { MessageBox.Show("afterCreate:新的MvFileOneH2.Exists" + MvFileOneH2.Name); }
            else MessageBox.Show("afterCreate:新的MvFileOneH2不存在");
            try { MessageBox.Show("Length = " + MvFileOneH2.Length); }
            catch (Exception ex) { MessageBox.Show("取Length屬性，結果：" + ex.Message); }
            MvFSH2.Close();
            if (MvFileOneH2.Exists) { MessageBox.Show("afterClose:新的MvFileOneH2.Exists" + MvFileOneH2.Name); }
            else MessageBox.Show("afterClose:新的MvFileOneH2不存在");
            try { MessageBox.Show("Length = " + MvFileOneH2.Length); }
            catch (Exception ex) { MessageBox.Show("取Length屬性，結果：" + ex.Message); }
            */
        }

        private void BtnFilePpt_Click(object sender, EventArgs e)
        {//示範檔案屬產：全名(含目錄名稱)、目錄名稱、檔案名稱、延伸檔名、長度。用字串串接，最後用訊息方塊顯示
         //即使檔案不存在，各種名稱的屬性仍可依建構時所給，但長度需真的有檔案才行，否則會發生例外
         //但仍有很多情況超乎想像，待釐清。如刪除該檔再取Length仍未例外。在檔未產生前取則發生例外，但影響後面檔案物件的正常判斷
            string StrOut = "";
            StrOut += "FullName = " + FileOneH.FullName + "\n";
            StrOut += "DirectoryName = " + FileOneH.DirectoryName + "\n";
            StrOut += "Name = " + FileOneH.Name + "\n";
            StrOut += "Extension = " + FileOneH.Extension + "\n";
            try { StrOut += "Length = " + FileOneH.Length + "\n"; }
            catch (Exception ex) { MessageBox.Show("取Length屬性，結果：" + ex.Message); }
            MessageBox.Show(StrOut);
            /*後面這部分都是在測試到底何時取Length不會發生例外，後來發現，全域變數需在搬移前讓它可以取一次屬性，例如做存在判斷，或直接取長度屬性
            try
            {//試產生檔案即產生FileStream，若檔案不存在會新建，若存在則只產生FileStream
                FileStream FSH = FileOneH.Create();//Create一定會產生FileStream，所以要宣告一個FileStream來承接
                MessageBox.Show(@"產生.\one\hello.txt");
                FSH.Close();//若後面還要對該檔案物件操作，要先把FileStream關閉，否則無法對指向該檔案物件操作
            }//若發生例外，例如目錄不存在，則秀出例外訊息
            catch (Exception ex) { MessageBox.Show(ex.Message); }
            StrOut = "檔案建立後屬性：\n";
            StrOut += "FullName = " + FileOneH.FullName + "\n";
            StrOut += "DirectoryName = " + FileOneH.DirectoryName + "\n";
            StrOut += "Name = " + FileOneH.Name + "\n";
            StrOut += "Extension = " + FileOneH.Extension + "\n";
            try { StrOut += "Length = " + FileOneH.Length + "\n"; }
            catch (Exception ex) { MessageBox.Show("取Length屬性，結果：" + ex.Message); }
            MessageBox.Show(StrOut);
            if (FileOneH.Exists) { FileOneH.Delete(); MessageBox.Show("刪除檔案"); }
            //檔案刪除，似乎Length屬性仍存在FileInfo FileOH
            StrOut = "刪除檔案後屬性：\n";
            StrOut += "FullName = " + FileOneH.FullName + "\n";
            StrOut += "DirectoryName = " + FileOneH.DirectoryName + "\n";
            StrOut += "Name = " + FileOneH.Name + "\n";
            StrOut += "Extension = " + FileOneH.Extension + "\n";
            try { StrOut += "Length = " + FileOneH.Length + "\n"; }
            catch (Exception ex) { MessageBox.Show("取Length屬性，結果：" + ex.Message); }
            MessageBox.Show(StrOut);

            FileInfo FileOH = new FileInfo(@".\one\hello.txt");
            try
            {//試產生檔案即產生FileStream，若檔案不存在會新建，若存在則只產生FileStream
                FileStream FSH = FileOH.Create();//Create一定會產生FileStream，所以要宣告一個FileStream來承接
                MessageBox.Show(@"產生.\one\hello.txt");
                FSH.Close();//若後面還要對該檔案物件操作，要先把FileStream關閉，否則無法對指向該檔案物件操作
            }//若發生例外，例如目錄不存在，則秀出例外訊息
            catch (Exception ex) { MessageBox.Show(ex.Message); }
            StrOut = "檔案建立後屬性：\n";
            StrOut += "FullName = " + FileOH.FullName + "\n";
            StrOut += "DirectoryName = " + FileOH.DirectoryName + "\n";
            StrOut += "Name = " + FileOH.Name + "\n";
            StrOut += "Extension = " + FileOH.Extension + "\n";
            try { StrOut += "Length = " + FileOH.Length + "\n"; }
            catch (Exception ex) { MessageBox.Show("取Length屬性，結果：" + ex.Message); }
            MessageBox.Show(StrOut);
            if (FileOneH.Exists) { FileOH.Delete(); MessageBox.Show("刪除檔案"); }
            //檔案刪除，似乎Length屬性仍存在FileInfo FileOH
            StrOut = "刪除檔案後屬性：\n";
            StrOut += "FullName = " + FileOH.FullName + "\n";
            StrOut += "DirectoryName = " + FileOH.DirectoryName + "\n";
            StrOut += "Name = " + FileOH.Name + "\n";
            StrOut += "Extension = " + FileOH.Extension + "\n";
            try { StrOut += "Length = " + FileOH.Length + "\n"; }
            catch (Exception ex) { MessageBox.Show("取Length屬性，結果：" + ex.Message); }
            MessageBox.Show(StrOut);
            */
        }

        private void BtnWLApp_Click(object sender, EventArgs e)
        {//示範兩種寫入，全新寫入及附加寫入
            StreamWriter SWHi = FileOneHi.CreateText();//開全新檔案，若已存在會清空該檔內容
            SWHi.WriteLine("Visual C#計程必修課");//寫入一行文字
            //SWHi.Flush();//Close前會先Flush，故可不用特別寫出
            SWHi.Close();//要關閉，否則資料不見得會寫入檔案，且檔案被鎖住，後面無法再對此檔案操作
            MessageBox.Show("Create寫入：Visual C#計程必修課");
            StreamWriter SWHiA = FileOneHi.AppendText();//開已存在檔案，以便附加內容接在該檔尾端
            SWHiA.WriteLine("黃蓮池老師嘔心瀝血教授");//寫入一行文字
            //SWHiA.Flush();//Close前會先Flush，故可不用特別寫出
            SWHiA.Close();//要關閉，否則資料不見得會寫入檔案，且檔案被鎖住，後面無法再對此檔案操作
            MessageBox.Show("Append寫入：黃蓮池老師嘔心瀝血教授");
        }

        private void BtnRd_Click(object sender, EventArgs e)
        {//示範一字一字讀取，先宣告及建構讀取串流指向某檔案
            StreamReader SRHi = new StreamReader(@".\one\hi.txt");
            string StrOut = "";//宣告輸出字串，初值為空集合
            while (!(SRHi.Peek() == -1)) StrOut += (char)SRHi.Read();
            //若非檔案最後（SRHi.Peek() == -1），將讀到的字串接到輸出
            /*另一種作法，利用Read傳回的是整數，而到檔尾傳回的是-1
            int IntR;//接讀到的結果（整數）
            do
            {//讀一個字元，傳回的整數存到IntR
                IntR = SRHi.Read();
                if (IntR == -1) break;//讀到檔案尾端會傳回-1，則跳出迴圈，不再讀取
                StrOut += (char)IntR;//將讀取到的結果（整數）轉成字元串接到輸出
            } while (true);
            */
            SRHi.Close();//若不關閉，檔案會鎖住。若不在同一函式，要再開一個串流才能使用，相同名稱亦可，如在BtnRdLn_Click
            //但若直接對檔案操作則不行，如BtnFileCp_Click中FileOneH.CopyTo(@".\one\hi.txt", true);會發生例外（檔案另一程式在使用）
            MessageBox.Show("Read:" + StrOut);//訊息方塊顯示輸出字串
        }

        private void BtnRdLn_Click(object sender, EventArgs e)
        {//示範一行一行讀取，先宣告及建構讀取串流指向某檔案
            StreamReader SRHi = new StreamReader(@".\one\hi.txt");
            string StrRL, StrOut = "";//宣告輸出字串，初值為空集合
            for (int i = 0; i < 5; i++) SRHi.Read();//經測試若1000字，會讀完，但不會有錯誤
            do
            {//先讀掉5個字以測試ReadLine仍是從現在指標位置開始讀起
                StrRL = SRHi.ReadLine();//從現在位置讀到行末，未含換行字元
                if (StrRL == null) break;//讀到檔案尾端會傳回null，則跳出迴圈，不再讀取
                StrOut += StrRL + "\n";//串接讀取資料及換行字元到輸出。課本是說用\r\n，但我認為\n即可，經測試，皆可，甚至\r亦可
            } while (true);
            SRHi.Close();//類似在BtnRd_Click的註解
            MessageBox.Show("ReadLine:" + StrOut);//訊息方塊顯示輸出字串
        }

        private void BtnRd2End_Click(object sender, EventArgs e)
        {//示範一次讀到最後，先宣告及建構讀取串流指向某檔案
            StreamReader SRHi = new StreamReader(@".\one\hi.txt");
            for (int i = 0; i < 10; i++) SRHi.Read();//經測試若1000字，會讀完，但不會有錯誤
            string StrOut = SRHi.ReadToEnd();//先讀掉10個字以測試ReadToEnd仍是從現在指標位置開始讀起
            SRHi.Close();//類似在BtnRd_Click的註解
            MessageBox.Show("ReadToEnd:" + StrOut);//訊息方塊顯示輸出字串
        }

        private void BtnStrmRW_Click(object sender, EventArgs e)
        {//寫入與讀出寫在一起，示範同函式仍可以對同一個檔宣告多串流，但必須宣告在上一個串流關閉之後，否則編譯雖通過，執行時上一個串流未關，檔案會鎖住，新串流宣告發生例外
            DirOne.Create();//產生目錄原加if判斷，但不知為何，常會誤判，於是直接產生，即使原就有也無所謂if (!DirOne.Exists) DirOne.Create();
            try//產生檔案，可以不用，因為寫入器指定時就會用檔案物件的方法產生檔案。但至少要宣告及建構檔案物件，此處借用全域名稱
            {//試產生檔案即產生FileStream，若檔案不存在會新建，若存在則只產生FileStream
                FileStream FSH = FileOneHi.Create();//Create一定會產生FileStream，所以要宣告一個FileStream來承接
                MessageBox.Show(@"產生.\one\hi.txt");
                FSH.Close();//若後面還要對該檔案物件操作，要先把FileStream關閉，否則無法對指向該檔案物件操作
            }//若發生例外，例如目錄不存在，則秀出例外訊息
            catch (Exception ex) { MessageBox.Show(ex.Message); }

            //示範兩種寫入，全新寫入及附加寫入
            MessageBox.Show(FileOneHi.Name + "寫入前長度：" + FileOneHi.Length);
            StreamWriter SWHi = FileOneHi.CreateText();//開全新檔案，若已存在會清空該檔內容
            //StreamWriter SWHi2 = FileOneHi.AppendText();//不可以再開串流對相同檔案，在上個串流未關閉前
            SWHi.WriteLine("Visual C#計程必修課");//寫入一行文字
            //SWHi.Flush();//Close前會先Flush，故可不用特別寫出
            SWHi.Close();//要關閉，否則資料不見得會寫入檔案，且檔案被鎖住，後面無法再對此檔案操作
            MessageBox.Show("Create寫入：Visual C#計程必修課");
            StreamWriter SWHiA = FileOneHi.AppendText();//開已存在檔案，以便附加內容接在該檔尾端。
            SWHiA.WriteLine("黃蓮池老師嘔心瀝血教授");//寫入一行文字
            //SWHiA.Flush();//Close前會先Flush，故可不用特別寫出
            SWHiA.Close();//要關閉，否則資料不見得會寫入檔案，且檔案被鎖住，後面無法再對此檔案操作
            MessageBox.Show("Append寫入：黃蓮池老師嘔心瀝血教授");
            MessageBox.Show(FileOneHi.Name + "寫入後長度：" + FileOneHi.Length);//結果仍是0，表示更新，只會記住第一次探測的結果。如何使之正確？待努力

            
            //示範一字一字讀取，先宣告及建構讀取串流指向某檔案
            string StrOut = "";//宣告輸出字串，初值為空集合

            StreamReader SRHi = new StreamReader(@".\one\hi.txt");
            while (!(SRHi.Peek() == -1)) StrOut += (char)SRHi.Read();
            //若非檔案最後（SRHi.Peek() == -1），將讀到的字串接到輸出
            /*另一種作法，利用Read傳回的是整數，而到檔尾傳回的是-1
            int IntR;//接讀到的結果（整數）
            do
            {//讀一個字元，傳回的整數存到IntR
                IntR = SRHi.Read();
                if (IntR == -1) break;//讀到檔案尾端會傳回-1，則跳出迴圈，不再讀取
                StrOut += (char)IntR;//將讀取到的結果（整數）轉成字元串接到輸出
            } while (true);
            */
            SRHi.Close();//課本未介紹Close方法，但仍建議不再使用時關閉，以免影響其他函式，例如其他函式對該檔要開串流，將發生例外
            MessageBox.Show("Read:" + StrOut);//訊息方塊顯示輸出字串

            //示範一行一行讀取，先宣告及建構讀取串流指向某檔案
            string StrRL;
            StrOut = "";//宣告輸出字串，初值為空集合
            StreamReader SRHiRL = new StreamReader(@".\one\hi.txt");
            for (int i = 0; i < 5; i++) SRHiRL.Read();//經測試若1000字，會讀完，但不會有錯誤
            do
            {//先讀掉5個字以測試ReadLine仍是從現在指標位置開始讀起
                StrRL = SRHiRL.ReadLine();//從現在位置讀到行末，未含換行字元
                if (StrRL == null) break;//讀到檔案尾端會傳回null，則跳出迴圈，不再讀取
                StrOut += StrRL + "\n";//串接讀取資料及換行字元到輸出。課本是說用\r\n，但我認為\n即可，經測試，皆可，甚至\r亦可
            } while (true);
            SRHiRL.Close();//課本未介紹Close方法，但仍建議不再使用時關閉，以免影響其他函式，例如其他函式對該檔要開串流，將發生例外
            MessageBox.Show("ReadLine:" + StrOut);//訊息方塊顯示輸出字串

            //示範一次讀到最後，先宣告及建構讀取串流指向某檔案
            StreamReader SRHiRE = new StreamReader(@".\one\hi.txt");
            for (int i = 0; i < 10; i++) SRHiRE.Read();//經測試若1000字，會讀完，但不會有錯誤
            StrOut = SRHiRE.ReadToEnd();//先讀掉10個字以測試ReadToEnd仍是從現在指標位置開始讀起
            SRHiRE.Close();//課本未介紹Close方法，但仍建議不再使用時關閉，以免影響其他函式，例如其他函式對該檔要開串流，將發生例外
            MessageBox.Show("ReadToEnd:" + StrOut);//訊息方塊顯示輸出字串

        }

        private void BtnPreFInfo_Click(object sender, EventArgs e)
        {//只要在搬移前觸動檔案物件讓它真的去檢查檔案（目前只知Exists及Length可真的觸動）
         //，它就會記住檔案資訊，也不會在搬移後找不到一些資訊，例如Length。雖然這樣似乎不合理
            if (FileOneH.Exists) { MessageBox.Show("beforemove:全域FileOneH存在："); }
            else MessageBox.Show("beforemove:全域FileOneH不存在");
        }

        private void BtnExtra_Click(object sender, EventArgs e)
        {
            BtnNewCrt_Click(sender, e);//產生目錄.\one\test
            BtnFileCrt_Click(sender, e);//產生檔案
            if (MessageBox.Show("是否預探檔案資訊", "請選擇", MessageBoxButtons.YesNo) == DialogResult.Yes) BtnPreFInfo_Click(sender, e);
            BtnFileDelMv_Click(sender, e);//搬移檔案，若目的檔存在則先刪除
            BtnFilePpt_Click(sender, e);//檔案的各種屬性，檔案不存在因為Move，Length屬性讀不出發生例外
        }
    }
}
