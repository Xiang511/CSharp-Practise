﻿namespace File
{
    partial class FrmTxtFile
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.BtnNewCrt = new System.Windows.Forms.Button();
            this.BtnDelOne = new System.Windows.Forms.Button();
            this.BtnDelTest = new System.Windows.Forms.Button();
            this.BtnDelOneT = new System.Windows.Forms.Button();
            this.BtnMv2 = new System.Windows.Forms.Button();
            this.BtnOneTch = new System.Windows.Forms.Button();
            this.BtnFileCrt = new System.Windows.Forms.Button();
            this.BtnFileCp = new System.Windows.Forms.Button();
            this.BtnFilePpt = new System.Windows.Forms.Button();
            this.BtnFileDelMv = new System.Windows.Forms.Button();
            this.BtnWLApp = new System.Windows.Forms.Button();
            this.BtnRd = new System.Windows.Forms.Button();
            this.BtnRdLn = new System.Windows.Forms.Button();
            this.BtnRd2End = new System.Windows.Forms.Button();
            this.BtnStrmRW = new System.Windows.Forms.Button();
            this.BtnPreFInfo = new System.Windows.Forms.Button();
            this.BtnExtra = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // BtnNewCrt
            // 
            this.BtnNewCrt.AutoSize = true;
            this.BtnNewCrt.Location = new System.Drawing.Point(189, 51);
            this.BtnNewCrt.Name = "BtnNewCrt";
            this.BtnNewCrt.Size = new System.Drawing.Size(130, 37);
            this.BtnNewCrt.TabIndex = 2;
            this.BtnNewCrt.Text = "目錄建構及產生";
            this.BtnNewCrt.UseVisualStyleBackColor = true;
            this.BtnNewCrt.Click += new System.EventHandler(this.BtnNewCrt_Click);
            // 
            // BtnDelOne
            // 
            this.BtnDelOne.AutoSize = true;
            this.BtnDelOne.Location = new System.Drawing.Point(345, 51);
            this.BtnDelOne.Name = "BtnDelOne";
            this.BtnDelOne.Size = new System.Drawing.Size(130, 37);
            this.BtnDelOne.TabIndex = 4;
            this.BtnDelOne.Text = "刪除目錄one";
            this.BtnDelOne.UseVisualStyleBackColor = true;
            this.BtnDelOne.Click += new System.EventHandler(this.BtnDelOne_Click);
            // 
            // BtnDelTest
            // 
            this.BtnDelTest.AutoSize = true;
            this.BtnDelTest.Location = new System.Drawing.Point(41, 111);
            this.BtnDelTest.Name = "BtnDelTest";
            this.BtnDelTest.Size = new System.Drawing.Size(130, 37);
            this.BtnDelTest.TabIndex = 5;
            this.BtnDelTest.Text = "刪除目錄test";
            this.BtnDelTest.UseVisualStyleBackColor = true;
            this.BtnDelTest.Click += new System.EventHandler(this.BtnDelTest_Click);
            // 
            // BtnDelOneT
            // 
            this.BtnDelOneT.AutoSize = true;
            this.BtnDelOneT.Location = new System.Drawing.Point(189, 111);
            this.BtnDelOneT.Name = "BtnDelOneT";
            this.BtnDelOneT.Size = new System.Drawing.Size(134, 37);
            this.BtnDelOneT.TabIndex = 7;
            this.BtnDelOneT.Text = "刪除目錄one-true";
            this.BtnDelOneT.UseVisualStyleBackColor = true;
            this.BtnDelOneT.Click += new System.EventHandler(this.BtnDelOneT_Click);
            // 
            // BtnMv2
            // 
            this.BtnMv2.AutoSize = true;
            this.BtnMv2.Location = new System.Drawing.Point(345, 111);
            this.BtnMv2.Name = "BtnMv2";
            this.BtnMv2.Size = new System.Drawing.Size(144, 37);
            this.BtnMv2.TabIndex = 8;
            this.BtnMv2.Text = "搬移目錄one到two";
            this.BtnMv2.UseVisualStyleBackColor = true;
            this.BtnMv2.Click += new System.EventHandler(this.BtnMv2_Click);
            // 
            // BtnOneTch
            // 
            this.BtnOneTch.AutoSize = true;
            this.BtnOneTch.Location = new System.Drawing.Point(41, 51);
            this.BtnOneTch.Name = "BtnOneTch";
            this.BtnOneTch.Size = new System.Drawing.Size(88, 37);
            this.BtnOneTch.TabIndex = 0;
            this.BtnOneTch.Text = "One Touch";
            this.BtnOneTch.UseVisualStyleBackColor = true;
            this.BtnOneTch.Click += new System.EventHandler(this.BtnOneTch_Click);
            // 
            // BtnFileCrt
            // 
            this.BtnFileCrt.AutoSize = true;
            this.BtnFileCrt.Location = new System.Drawing.Point(42, 180);
            this.BtnFileCrt.Name = "BtnFileCrt";
            this.BtnFileCrt.Size = new System.Drawing.Size(156, 37);
            this.BtnFileCrt.TabIndex = 10;
            this.BtnFileCrt.Text = "檔案產生(串流開關)";
            this.BtnFileCrt.UseVisualStyleBackColor = true;
            this.BtnFileCrt.Click += new System.EventHandler(this.BtnFileCrt_Click);
            // 
            // BtnFileCp
            // 
            this.BtnFileCp.AutoSize = true;
            this.BtnFileCp.Location = new System.Drawing.Point(214, 180);
            this.BtnFileCp.Name = "BtnFileCp";
            this.BtnFileCp.Size = new System.Drawing.Size(130, 37);
            this.BtnFileCp.TabIndex = 11;
            this.BtnFileCp.Text = "檔案複製";
            this.BtnFileCp.UseVisualStyleBackColor = true;
            this.BtnFileCp.Click += new System.EventHandler(this.BtnFileCp_Click);
            // 
            // BtnFilePpt
            // 
            this.BtnFilePpt.AutoSize = true;
            this.BtnFilePpt.Location = new System.Drawing.Point(41, 251);
            this.BtnFilePpt.Name = "BtnFilePpt";
            this.BtnFilePpt.Size = new System.Drawing.Size(130, 37);
            this.BtnFilePpt.TabIndex = 14;
            this.BtnFilePpt.Text = "檔案屬性";
            this.BtnFilePpt.UseVisualStyleBackColor = true;
            this.BtnFilePpt.Click += new System.EventHandler(this.BtnFilePpt_Click);
            // 
            // BtnFileDelMv
            // 
            this.BtnFileDelMv.AutoSize = true;
            this.BtnFileDelMv.Location = new System.Drawing.Point(359, 180);
            this.BtnFileDelMv.Name = "BtnFileDelMv";
            this.BtnFileDelMv.Size = new System.Drawing.Size(130, 37);
            this.BtnFileDelMv.TabIndex = 12;
            this.BtnFileDelMv.Text = "檔案刪除搬移";
            this.BtnFileDelMv.UseVisualStyleBackColor = true;
            this.BtnFileDelMv.Click += new System.EventHandler(this.BtnFileDelMv_Click);
            // 
            // BtnWLApp
            // 
            this.BtnWLApp.AutoSize = true;
            this.BtnWLApp.Location = new System.Drawing.Point(193, 251);
            this.BtnWLApp.Name = "BtnWLApp";
            this.BtnWLApp.Size = new System.Drawing.Size(130, 37);
            this.BtnWLApp.TabIndex = 15;
            this.BtnWLApp.Text = "寫入與附加";
            this.BtnWLApp.UseVisualStyleBackColor = true;
            this.BtnWLApp.Click += new System.EventHandler(this.BtnWLApp_Click);
            // 
            // BtnRd
            // 
            this.BtnRd.AutoSize = true;
            this.BtnRd.Location = new System.Drawing.Point(345, 251);
            this.BtnRd.Name = "BtnRd";
            this.BtnRd.Size = new System.Drawing.Size(130, 37);
            this.BtnRd.TabIndex = 16;
            this.BtnRd.Text = "Read";
            this.BtnRd.UseVisualStyleBackColor = true;
            this.BtnRd.Click += new System.EventHandler(this.BtnRd_Click);
            // 
            // BtnRdLn
            // 
            this.BtnRdLn.AutoSize = true;
            this.BtnRdLn.Location = new System.Drawing.Point(41, 317);
            this.BtnRdLn.Name = "BtnRdLn";
            this.BtnRdLn.Size = new System.Drawing.Size(130, 37);
            this.BtnRdLn.TabIndex = 17;
            this.BtnRdLn.Text = "ReadLine";
            this.BtnRdLn.UseVisualStyleBackColor = true;
            this.BtnRdLn.Click += new System.EventHandler(this.BtnRdLn_Click);
            // 
            // BtnRd2End
            // 
            this.BtnRd2End.AutoSize = true;
            this.BtnRd2End.Location = new System.Drawing.Point(193, 317);
            this.BtnRd2End.Name = "BtnRd2End";
            this.BtnRd2End.Size = new System.Drawing.Size(130, 37);
            this.BtnRd2End.TabIndex = 18;
            this.BtnRd2End.Text = "ReadToEnd";
            this.BtnRd2End.UseVisualStyleBackColor = true;
            this.BtnRd2End.Click += new System.EventHandler(this.BtnRd2End_Click);
            // 
            // BtnStrmRW
            // 
            this.BtnStrmRW.AutoSize = true;
            this.BtnStrmRW.Location = new System.Drawing.Point(345, 317);
            this.BtnStrmRW.Name = "BtnStrmRW";
            this.BtnStrmRW.Size = new System.Drawing.Size(130, 37);
            this.BtnStrmRW.TabIndex = 19;
            this.BtnStrmRW.Text = "串流寫入讀取";
            this.BtnStrmRW.UseVisualStyleBackColor = true;
            this.BtnStrmRW.Click += new System.EventHandler(this.BtnStrmRW_Click);
            // 
            // BtnPreFInfo
            // 
            this.BtnPreFInfo.AutoSize = true;
            this.BtnPreFInfo.Location = new System.Drawing.Point(42, 380);
            this.BtnPreFInfo.Name = "BtnPreFInfo";
            this.BtnPreFInfo.Size = new System.Drawing.Size(130, 37);
            this.BtnPreFInfo.TabIndex = 20;
            this.BtnPreFInfo.Text = "預讀檔案資訊";
            this.BtnPreFInfo.UseVisualStyleBackColor = true;
            this.BtnPreFInfo.Click += new System.EventHandler(this.BtnPreFInfo_Click);
            // 
            // BtnExtra
            // 
            this.BtnExtra.AutoSize = true;
            this.BtnExtra.Location = new System.Drawing.Point(193, 380);
            this.BtnExtra.Name = "BtnExtra";
            this.BtnExtra.Size = new System.Drawing.Size(130, 37);
            this.BtnExtra.TabIndex = 21;
            this.BtnExtra.Text = "額外補充示範";
            this.BtnExtra.UseVisualStyleBackColor = true;
            this.BtnExtra.Click += new System.EventHandler(this.BtnExtra_Click);
            // 
            // FrmTxtFile
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(524, 472);
            this.Controls.Add(this.BtnExtra);
            this.Controls.Add(this.BtnPreFInfo);
            this.Controls.Add(this.BtnStrmRW);
            this.Controls.Add(this.BtnRd2End);
            this.Controls.Add(this.BtnRdLn);
            this.Controls.Add(this.BtnRd);
            this.Controls.Add(this.BtnWLApp);
            this.Controls.Add(this.BtnFileDelMv);
            this.Controls.Add(this.BtnFilePpt);
            this.Controls.Add(this.BtnFileCp);
            this.Controls.Add(this.BtnFileCrt);
            this.Controls.Add(this.BtnOneTch);
            this.Controls.Add(this.BtnMv2);
            this.Controls.Add(this.BtnDelOneT);
            this.Controls.Add(this.BtnDelTest);
            this.Controls.Add(this.BtnDelOne);
            this.Controls.Add(this.BtnNewCrt);
            this.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "FrmTxtFile";
            this.Text = "文字檔";
            this.Load += new System.EventHandler(this.FrmTxtFile_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button BtnNewCrt;
        private System.Windows.Forms.Button BtnDelOne;
        private System.Windows.Forms.Button BtnDelTest;
        private System.Windows.Forms.Button BtnDelOneT;
        private System.Windows.Forms.Button BtnMv2;
        private System.Windows.Forms.Button BtnOneTch;
        private System.Windows.Forms.Button BtnFileCrt;
        private System.Windows.Forms.Button BtnFileCp;
        private System.Windows.Forms.Button BtnFilePpt;
        private System.Windows.Forms.Button BtnFileDelMv;
        private System.Windows.Forms.Button BtnWLApp;
        private System.Windows.Forms.Button BtnRd;
        private System.Windows.Forms.Button BtnRdLn;
        private System.Windows.Forms.Button BtnRd2End;
        private System.Windows.Forms.Button BtnStrmRW;
        private System.Windows.Forms.Button BtnPreFInfo;
        private System.Windows.Forms.Button BtnExtra;
    }
}

