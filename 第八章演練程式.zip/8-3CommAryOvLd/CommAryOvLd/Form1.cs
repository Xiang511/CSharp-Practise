﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CommAryOvLd
{
    public partial class FrmCommAryOvLd : Form
    {
        public FrmCommAryOvLd()
        {
            InitializeComponent();
        }
        private void Btn1_Click(object sender, EventArgs e)
        {//若要使用sender對應的物件(控制項)，需將sender強制轉型才能使用
            //Button BtnClk = (Button)sender;//可以宣告一個變數來承接，或直接使用
            LblWhichBtn.Text += "按了" + ((Button)sender).Text + "\n";
        }

        private void Btn3_Leave(object sender, EventArgs e)
        {//用來判斷哪個來源控制項，再視需要執行一些指令
            if (sender == Btn1) LblWhichBtn.Text += "離開" + Btn1.Text;
            else if (sender == Btn2) LblWhichBtn.Text += "離開" + Btn2.Text;
            else LblWhichBtn.Text += "離開" + Btn3.Text;
        }

        private void FrmCommAryOvLd_Load(object sender, EventArgs e)
        {
            Btn1.Leave += Btn3_Leave;//直接讓Btn1共用Btn3之Leave事件處理函式
            Btn2.Leave += new EventHandler(Btn3_Leave);//新事件處理器的方法來使Btn2共用Btn3之Leave事件處理函式
            LblWhichBtn.Text += "\n";//讓事件處理函式秀出來的字從第二行開始
        }

        private void Btn2_Leave(object sender, EventArgs e)
        {//若有其他共用事件，此事件處理函式仍會先執行
            MessageBox.Show("這是Btn2_Leave");
        }//訊息方塊會干擾Click事件，所以未觸動下一個按鈕的Click。除非再Click觸動一次

        void PassArrayR(ref int[] Ary)
        {//自訂方法，有使用ref關鍵字，所以名稱多加個R做區分
            string StrOut = "{ " + Ary[0];
            for (int i = 1; i < Ary.Length; i++) StrOut += ", " + Ary[i];
            MessageBox.Show("有用關鍵字Ref：" + StrOut + "}");
        }

        void PassArray(int[] Ary)
        {//自訂方法，未使用ref關鍵字，所以名稱未加R做區分
            string StrOut = "{ " + Ary[0];
            for (int i = 1; i < Ary.Length; i++) StrOut += ", " + Ary[i];
            MessageBox.Show("沒用關鍵字Ref：" + StrOut + "}");
        }

        private void BtnPsAry_Click(object sender, EventArgs e)
        {//使用二個陣列，名稱分別有R及沒R，用以使用在有用及沒用ref關鍵字的自訂方法
            int[] MyArrayR = { 1, 2, 3, 4, 5 };
            int[] MyArray = { 5, 4, 3, 2, 1 };
            PassArrayR(ref MyArrayR);
            //PassArrayR(MyArrayR);//自訂函數定義參數時有使用ref關鍵字，所以引數前也要加ref才可以
            //PassArray(ref MyArray);//自訂函數定義參數時未有使用ref關鍵字，所以引數前也不可以加ref才可以
            PassArray(MyArray);
        }
    }
}
