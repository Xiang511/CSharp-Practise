﻿namespace CommAryOvLd
{
    partial class FrmCommAryOvLd
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.Btn1 = new System.Windows.Forms.Button();
            this.Btn2 = new System.Windows.Forms.Button();
            this.Btn3 = new System.Windows.Forms.Button();
            this.LblWhichBtn = new System.Windows.Forms.Label();
            this.BtnPsAry = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // Btn1
            // 
            this.Btn1.AutoSize = true;
            this.Btn1.Location = new System.Drawing.Point(34, 12);
            this.Btn1.Name = "Btn1";
            this.Btn1.Size = new System.Drawing.Size(75, 26);
            this.Btn1.TabIndex = 0;
            this.Btn1.Text = "Btn1";
            this.Btn1.UseVisualStyleBackColor = true;
            this.Btn1.Click += new System.EventHandler(this.Btn1_Click);
            // 
            // Btn2
            // 
            this.Btn2.AutoSize = true;
            this.Btn2.Location = new System.Drawing.Point(34, 44);
            this.Btn2.Name = "Btn2";
            this.Btn2.Size = new System.Drawing.Size(75, 26);
            this.Btn2.TabIndex = 1;
            this.Btn2.Text = "Btn2";
            this.Btn2.UseVisualStyleBackColor = true;
            this.Btn2.Click += new System.EventHandler(this.Btn1_Click);
            this.Btn2.Leave += new System.EventHandler(this.Btn2_Leave);
            // 
            // Btn3
            // 
            this.Btn3.AutoSize = true;
            this.Btn3.Location = new System.Drawing.Point(34, 76);
            this.Btn3.Name = "Btn3";
            this.Btn3.Size = new System.Drawing.Size(75, 26);
            this.Btn3.TabIndex = 2;
            this.Btn3.Text = "Btn3";
            this.Btn3.UseVisualStyleBackColor = true;
            this.Btn3.Click += new System.EventHandler(this.Btn1_Click);
            this.Btn3.Leave += new System.EventHandler(this.Btn3_Leave);
            // 
            // LblWhichBtn
            // 
            this.LblWhichBtn.AutoSize = true;
            this.LblWhichBtn.Location = new System.Drawing.Point(129, 17);
            this.LblWhichBtn.Name = "LblWhichBtn";
            this.LblWhichBtn.Size = new System.Drawing.Size(104, 16);
            this.LblWhichBtn.TabIndex = 3;
            this.LblWhichBtn.Text = "按了哪個按鈕";
            // 
            // BtnPsAry
            // 
            this.BtnPsAry.AutoSize = true;
            this.BtnPsAry.Location = new System.Drawing.Point(34, 121);
            this.BtnPsAry.Name = "BtnPsAry";
            this.BtnPsAry.Size = new System.Drawing.Size(77, 28);
            this.BtnPsAry.TabIndex = 4;
            this.BtnPsAry.Text = "傳陣列";
            this.BtnPsAry.UseVisualStyleBackColor = true;
            this.BtnPsAry.Click += new System.EventHandler(this.BtnPsAry_Click);
            // 
            // FrmCommAryOvLd
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(319, 161);
            this.Controls.Add(this.BtnPsAry);
            this.Controls.Add(this.LblWhichBtn);
            this.Controls.Add(this.Btn3);
            this.Controls.Add(this.Btn2);
            this.Controls.Add(this.Btn1);
            this.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "FrmCommAryOvLd";
            this.Text = "共用事件、陣列、多載";
            this.Load += new System.EventHandler(this.FrmCommAryOvLd_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Btn1;
        private System.Windows.Forms.Button Btn2;
        private System.Windows.Forms.Button Btn3;
        private System.Windows.Forms.Label LblWhichBtn;
        private System.Windows.Forms.Button BtnPsAry;
    }
}

