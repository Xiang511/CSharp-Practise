﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MthdAdd
{
    public partial class FrmMthd : Form
    {
        public FrmMthd()
        {
            InitializeComponent();
        }

        void ParaTst(int a, int b = 2, int c = 10, int d = 100)
        {//自訂方法，試選擇性參數及具名參數
            MessageBox.Show("a + b + c + d = " + a + " + " + b + " + " + c + " + " + d + " = " + (a + b + c + d));
        }

        private void BtnPara_Click(object sender, EventArgs e)
        {
            MessageBox.Show("只給第1個引數");
            ParaTst(5);
            MessageBox.Show("給第1, 2個引數");
            ParaTst(5, 4);
            //ParaTst(5, 4, ,200);//要省略得後面全部省略，否則要用具名參數
            MessageBox.Show("給第1, 2, 4個引數，第4個要用具名");
            ParaTst(5, 4, d: 200);
            MessageBox.Show("給第1, 2, 4個引數，第2,4個要用具名，可不用管順序，結果一樣");
            ParaTst(5, d: 200, b: 4);
        }

        int RtnTst(int a, int b)
        {
            if (a == 1)
            {
                MessageBox.Show("a=1回傳a + b = " + a + " + " + b + " = " + (a + b));
                return a + b;
                MessageBox.Show("a = 1");//寫在return，不會執行到
            }
            else if (a == 2)
            {
                MessageBox.Show("a=2回傳b = " + b);
                return b;
            }
            else
            {
                MessageBox.Show("a=3回傳300");
                //return "300";//型別不符
                return 300;

            }

        }

        private void BtnRtn_Click(object sender, EventArgs e)
        {
            LblRtnRslt.Text = "return結果：" +  RtnTst(1, 10);//回傳值直接置於運算位置
            int a = RtnTst(2, 10);//回傳值用變數承接再給後續的運算
            LblRtnRslt.Text = "return結果：" + a;//雖a在方法中已使用，但那是區域變數，不影響這裡的宣告及使用
            RtnTst(3, 10);//沒有利用回傳值在本程序中，可執行，雖有些不合邏輯，應改用void
        }

        int AddRtn(int a, int b)
        {
            int c = a + b;
            return c;//將兩數相加回傳給呼叫端處理
        }

        void AddMsg(int a, int b)
        {
            MessageBox.Show((a + b).ToString());//直接用訊息方塊將兩數相加結果秀出
        }

        private void Btn2Add_Click(object sender, EventArgs e)
        {
            int x = 10;
            MessageBox.Show("這是有return的作法");
            int sum = AddRtn(x + 1, 20);//呼叫有回傳值的方法AddRtn
            LblRtnRslt.Text = "return結果：" + sum;//將回傳結果用標籤秀出
            MessageBox.Show("這是沒有return的作法，直接在方法中用訊息方塊秀結果");
            AddMsg(x + 1, 20);//呼叫沒有回傳值的方法AddMsg
        }
    }
}
