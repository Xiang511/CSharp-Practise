﻿namespace MthdAdd
{
    partial class FrmMthd
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.BtnPara = new System.Windows.Forms.Button();
            this.BtnRtn = new System.Windows.Forms.Button();
            this.LblRtnRslt = new System.Windows.Forms.Label();
            this.Btn2Add = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // BtnPara
            // 
            this.BtnPara.AutoSize = true;
            this.BtnPara.Location = new System.Drawing.Point(45, 38);
            this.BtnPara.Name = "BtnPara";
            this.BtnPara.Size = new System.Drawing.Size(98, 26);
            this.BtnPara.TabIndex = 0;
            this.BtnPara.Text = "選擇性參數";
            this.BtnPara.UseVisualStyleBackColor = true;
            this.BtnPara.Click += new System.EventHandler(this.BtnPara_Click);
            // 
            // BtnRtn
            // 
            this.BtnRtn.AutoSize = true;
            this.BtnRtn.Location = new System.Drawing.Point(183, 38);
            this.BtnRtn.Name = "BtnRtn";
            this.BtnRtn.Size = new System.Drawing.Size(98, 26);
            this.BtnRtn.TabIndex = 1;
            this.BtnRtn.Text = "return測試";
            this.BtnRtn.UseVisualStyleBackColor = true;
            this.BtnRtn.Click += new System.EventHandler(this.BtnRtn_Click);
            // 
            // LblRtnRslt
            // 
            this.LblRtnRslt.AutoSize = true;
            this.LblRtnRslt.Location = new System.Drawing.Point(158, 94);
            this.LblRtnRslt.Name = "LblRtnRslt";
            this.LblRtnRslt.Size = new System.Drawing.Size(93, 16);
            this.LblRtnRslt.TabIndex = 2;
            this.LblRtnRslt.Text = "return結果：";
            // 
            // Btn2Add
            // 
            this.Btn2Add.AutoSize = true;
            this.Btn2Add.Location = new System.Drawing.Point(45, 89);
            this.Btn2Add.Name = "Btn2Add";
            this.Btn2Add.Size = new System.Drawing.Size(98, 26);
            this.Btn2Add.TabIndex = 3;
            this.Btn2Add.Text = "兩種加法";
            this.Btn2Add.UseVisualStyleBackColor = true;
            this.Btn2Add.Click += new System.EventHandler(this.Btn2Add_Click);
            // 
            // FrmMthd
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(344, 164);
            this.Controls.Add(this.Btn2Add);
            this.Controls.Add(this.LblRtnRslt);
            this.Controls.Add(this.BtnRtn);
            this.Controls.Add(this.BtnPara);
            this.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "FrmMthd";
            this.Text = "自訂方法";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button BtnPara;
        private System.Windows.Forms.Button BtnRtn;
        private System.Windows.Forms.Label LblRtnRslt;
        private System.Windows.Forms.Button Btn2Add;
    }
}

