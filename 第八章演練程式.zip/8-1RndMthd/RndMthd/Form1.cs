﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RndMthd
{
    public partial class RndMthd : Form
    {
        public RndMthd()
        {
            InitializeComponent();
        }

        private void BtnRnd5_Click(object sender, EventArgs e)
        {
            Random Rnd = new Random();//建構一個隨機物件，命名為Rnd
            string StrOut="";//宣告輸出字串，初值為空字串，因為要累串上去
            for (int i = 1; i < 6; i++)
            {//產生5個亂數，迴圈計數用做輸出計數，所以從1開始
                StrOut += "第" + i + "個亂數：" + Rnd.Next(3, 15) + "\n";//串接每次的亂數。因為串接字串，所以數值不用像課本還要ToString
            }//Rnd.Next(3, 15)隨機取[3, 14]間整數
            MessageBox.Show(StrOut);//最後用訊息方塊輸出
        }

        private void BtnRndDiff5_Click(object sender, EventArgs e)
        {
            Random Rnd = new Random();//建構一個隨機物件，命名為Rnd
            string StrOut = "";//宣告輸出字串，初值為空字串，因為要累串上去
            int[] RndNum = new int[5];//因為要求不可以重複，所以符合的亂數先存起來，以便給後面產生的做比對
            for (int i = 0; i < 5; i++)
            {//產生5個亂數，迴圈計數用做陣列索引，所以從0開始，因此輸出計數要加1
                int RndTmp = Rnd.Next(49) + 1;//要求[1, 49]的亂數，所以用Rnd.Next(49)產生[0, 48]再加1，也可以直接用Rnd.Next(1, 50)
                bool FindFlag = false;//因要比較是否重複，宣告布林變數來表示，預設未發現重複
                for (int j = 0; j < i; j++)
                {//比對之前即陣列索引0到i-1，無需像課本用foreach比對全部
                    if (RndTmp == RndNum[j]) { FindFlag = true; break; }
                }//若比對相同，即重複，設定發現旗標為true，並跳出比對迴圈
                if (FindFlag) i--;//若有重複，且此亂數不存，且要重新產生，故i--讓產生新亂數的迴圈可以產生相同i再產生一個亂數。因此敘述為迴圈最後，所以不用加continue
                else//若未重複則存入陣列，並串接輸出字串。注意輸出字串的計數用i+1，因為此次i從0開始
                {
                    RndNum[i] = RndTmp;
                    StrOut += "第" + (i + 1) + "個亂數：" + RndTmp + "\n";//串接每次的亂數。因為串接字串，所以數值不用像課本還要ToString
                }
            }
            MessageBox.Show(StrOut);//最後用訊息方塊輸出
        }

        private void BtnRndDbl_Click(object sender, EventArgs e)
        {
            Random Rnd = new Random();//建構一個隨機物件，命名為Rnd
            MessageBox.Show("得到[0.0, 1.0)間亂數為" + Rnd.NextDouble());
        }//Rnd.NextDouble()產生[0.0, 1.0)間亂數

        private void BtnRndDbl2_Click(object sender, EventArgs e)
        {
            Random Rnd = new Random();//建構一個隨機物件，命名為Rnd
            MessageBox.Show("得到[3.2, 5.8)間亂數為" + (Rnd.NextDouble() * (5.8 - 3.2) + 3.2));
        }//Rnd.NextDouble()產生[0.0, 1.0)間亂數，乘(5.8 - 3.2)，變成[0.0, (5.8 - 3.2))間，再加3.2變成[3.2, 5.8)間
    }
}
