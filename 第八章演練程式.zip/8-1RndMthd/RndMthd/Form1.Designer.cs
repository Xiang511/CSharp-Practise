﻿namespace RndMthd
{
    partial class RndMthd
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.BtnRnd5 = new System.Windows.Forms.Button();
            this.BtnRndDiff5 = new System.Windows.Forms.Button();
            this.BtnRndDbl = new System.Windows.Forms.Button();
            this.BtnRndDbl2 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // BtnRnd5
            // 
            this.BtnRnd5.AutoSize = true;
            this.BtnRnd5.Location = new System.Drawing.Point(36, 45);
            this.BtnRnd5.Name = "BtnRnd5";
            this.BtnRnd5.Size = new System.Drawing.Size(103, 46);
            this.BtnRnd5.TabIndex = 0;
            this.BtnRnd5.Text = "5個亂數";
            this.BtnRnd5.UseVisualStyleBackColor = true;
            this.BtnRnd5.Click += new System.EventHandler(this.BtnRnd5_Click);
            // 
            // BtnRndDiff5
            // 
            this.BtnRndDiff5.AutoSize = true;
            this.BtnRndDiff5.Location = new System.Drawing.Point(36, 124);
            this.BtnRndDiff5.Name = "BtnRndDiff5";
            this.BtnRndDiff5.Size = new System.Drawing.Size(106, 46);
            this.BtnRndDiff5.TabIndex = 1;
            this.BtnRndDiff5.Text = "5個不同亂數";
            this.BtnRndDiff5.UseVisualStyleBackColor = true;
            this.BtnRndDiff5.Click += new System.EventHandler(this.BtnRndDiff5_Click);
            // 
            // BtnRndDbl
            // 
            this.BtnRndDbl.AutoSize = true;
            this.BtnRndDbl.Location = new System.Drawing.Point(175, 45);
            this.BtnRndDbl.Name = "BtnRndDbl";
            this.BtnRndDbl.Size = new System.Drawing.Size(140, 46);
            this.BtnRndDbl.TabIndex = 2;
            this.BtnRndDbl.Text = "[0.0, 1.0)間之亂數";
            this.BtnRndDbl.UseVisualStyleBackColor = true;
            this.BtnRndDbl.Click += new System.EventHandler(this.BtnRndDbl_Click);
            // 
            // BtnRndDbl2
            // 
            this.BtnRndDbl2.AutoSize = true;
            this.BtnRndDbl2.Location = new System.Drawing.Point(175, 124);
            this.BtnRndDbl2.Name = "BtnRndDbl2";
            this.BtnRndDbl2.Size = new System.Drawing.Size(140, 46);
            this.BtnRndDbl2.TabIndex = 3;
            this.BtnRndDbl2.Text = "[3.2, 5.8)間之亂數";
            this.BtnRndDbl2.UseVisualStyleBackColor = true;
            this.BtnRndDbl2.Click += new System.EventHandler(this.BtnRndDbl2_Click);
            // 
            // RndMthd
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(361, 227);
            this.Controls.Add(this.BtnRndDbl2);
            this.Controls.Add(this.BtnRndDbl);
            this.Controls.Add(this.BtnRndDiff5);
            this.Controls.Add(this.BtnRnd5);
            this.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "RndMthd";
            this.Text = "亂數";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button BtnRnd5;
        private System.Windows.Forms.Button BtnRndDiff5;
        private System.Windows.Forms.Button BtnRndDbl;
        private System.Windows.Forms.Button BtnRndDbl2;
    }
}

