﻿namespace RdbChk
{
    partial class FrmRdbChk
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.Rdb1 = new System.Windows.Forms.RadioButton();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.Rdb3 = new System.Windows.Forms.RadioButton();
            this.Rdb2 = new System.Windows.Forms.RadioButton();
            this.BtnChkd = new System.Windows.Forms.Button();
            this.BtnApp = new System.Windows.Forms.Button();
            this.BtnAlg = new System.Windows.Forms.Button();
            this.BtnText = new System.Windows.Forms.Button();
            this.BtnEnab = new System.Windows.Forms.Button();
            this.BtnAutoChk = new System.Windows.Forms.Button();
            this.LblAutoChk = new System.Windows.Forms.Label();
            this.Grp2 = new System.Windows.Forms.GroupBox();
            this.radioButton9 = new System.Windows.Forms.RadioButton();
            this.radioButton8 = new System.Windows.Forms.RadioButton();
            this.radioButton7 = new System.Windows.Forms.RadioButton();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.radioButton3 = new System.Windows.Forms.RadioButton();
            this.radioButton4 = new System.Windows.Forms.RadioButton();
            this.radioButton5 = new System.Windows.Forms.RadioButton();
            this.radioButton6 = new System.Windows.Forms.RadioButton();
            this.Pan = new System.Windows.Forms.Panel();
            this.radioButton12 = new System.Windows.Forms.RadioButton();
            this.radioButton11 = new System.Windows.Forms.RadioButton();
            this.radioButton10 = new System.Windows.Forms.RadioButton();
            this.BtnGrpTxt = new System.Windows.Forms.Button();
            this.BtnPnl = new System.Windows.Forms.Button();
            this.BtnChkSt = new System.Windows.Forms.Button();
            this.Btn3St = new System.Windows.Forms.Button();
            this.Chk = new System.Windows.Forms.CheckBox();
            this.Lbl3St = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.Grp2.SuspendLayout();
            this.Pan.SuspendLayout();
            this.SuspendLayout();
            // 
            // Rdb1
            // 
            this.Rdb1.Location = new System.Drawing.Point(37, 57);
            this.Rdb1.Margin = new System.Windows.Forms.Padding(4);
            this.Rdb1.Name = "Rdb1";
            this.Rdb1.Size = new System.Drawing.Size(244, 65);
            this.Rdb1.TabIndex = 0;
            this.Rdb1.TabStop = true;
            this.Rdb1.Text = "&radioButton1";
            this.Rdb1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.Rdb1.UseVisualStyleBackColor = true;
            this.Rdb1.CheckedChanged += new System.EventHandler(this.Rdb1_CheckedChanged);
            this.Rdb1.Click += new System.EventHandler(this.Rdb1_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.Rdb3);
            this.groupBox1.Controls.Add(this.Rdb2);
            this.groupBox1.Controls.Add(this.Rdb1);
            this.groupBox1.Location = new System.Drawing.Point(23, 13);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox1.Size = new System.Drawing.Size(289, 231);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "選項按鈕";
            // 
            // Rdb3
            // 
            this.Rdb3.AutoSize = true;
            this.Rdb3.Location = new System.Drawing.Point(37, 181);
            this.Rdb3.Margin = new System.Windows.Forms.Padding(4);
            this.Rdb3.Name = "Rdb3";
            this.Rdb3.Size = new System.Drawing.Size(108, 20);
            this.Rdb3.TabIndex = 2;
            this.Rdb3.TabStop = true;
            this.Rdb3.Text = "radioButton&3";
            this.Rdb3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.Rdb3.UseVisualStyleBackColor = true;
            // 
            // Rdb2
            // 
            this.Rdb2.AutoSize = true;
            this.Rdb2.Location = new System.Drawing.Point(37, 130);
            this.Rdb2.Margin = new System.Windows.Forms.Padding(4);
            this.Rdb2.Name = "Rdb2";
            this.Rdb2.Size = new System.Drawing.Size(108, 20);
            this.Rdb2.TabIndex = 1;
            this.Rdb2.TabStop = true;
            this.Rdb2.Text = "radio&Button2";
            this.Rdb2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.Rdb2.UseVisualStyleBackColor = true;
            this.Rdb2.CheckedChanged += new System.EventHandler(this.Rdb2_CheckedChanged);
            this.Rdb2.Click += new System.EventHandler(this.Rdb2_Click);
            // 
            // BtnChkd
            // 
            this.BtnChkd.AutoSize = true;
            this.BtnChkd.Location = new System.Drawing.Point(337, 25);
            this.BtnChkd.Name = "BtnChkd";
            this.BtnChkd.Size = new System.Drawing.Size(87, 34);
            this.BtnChkd.TabIndex = 3;
            this.BtnChkd.Text = "核取";
            this.BtnChkd.UseVisualStyleBackColor = true;
            this.BtnChkd.Click += new System.EventHandler(this.BtnChkd_Click);
            // 
            // BtnApp
            // 
            this.BtnApp.AutoSize = true;
            this.BtnApp.Location = new System.Drawing.Point(337, 83);
            this.BtnApp.Name = "BtnApp";
            this.BtnApp.Size = new System.Drawing.Size(87, 34);
            this.BtnApp.TabIndex = 4;
            this.BtnApp.Text = "外觀";
            this.BtnApp.UseVisualStyleBackColor = true;
            this.BtnApp.Click += new System.EventHandler(this.BtnApp_Click);
            // 
            // BtnAlg
            // 
            this.BtnAlg.AutoSize = true;
            this.BtnAlg.Location = new System.Drawing.Point(337, 143);
            this.BtnAlg.Name = "BtnAlg";
            this.BtnAlg.Size = new System.Drawing.Size(87, 34);
            this.BtnAlg.TabIndex = 5;
            this.BtnAlg.Text = "對齊";
            this.BtnAlg.UseVisualStyleBackColor = true;
            this.BtnAlg.Click += new System.EventHandler(this.BtnAlg_Click);
            // 
            // BtnText
            // 
            this.BtnText.AutoSize = true;
            this.BtnText.Location = new System.Drawing.Point(337, 199);
            this.BtnText.Name = "BtnText";
            this.BtnText.Size = new System.Drawing.Size(87, 34);
            this.BtnText.TabIndex = 6;
            this.BtnText.Text = "標題";
            this.BtnText.UseVisualStyleBackColor = true;
            this.BtnText.Click += new System.EventHandler(this.BtnText_Click);
            // 
            // BtnEnab
            // 
            this.BtnEnab.AutoSize = true;
            this.BtnEnab.Location = new System.Drawing.Point(337, 258);
            this.BtnEnab.Name = "BtnEnab";
            this.BtnEnab.Size = new System.Drawing.Size(87, 34);
            this.BtnEnab.TabIndex = 7;
            this.BtnEnab.Text = "致動";
            this.BtnEnab.UseVisualStyleBackColor = true;
            this.BtnEnab.Click += new System.EventHandler(this.BtnEnab_Click);
            // 
            // BtnAutoChk
            // 
            this.BtnAutoChk.AutoSize = true;
            this.BtnAutoChk.Location = new System.Drawing.Point(447, 25);
            this.BtnAutoChk.Name = "BtnAutoChk";
            this.BtnAutoChk.Size = new System.Drawing.Size(87, 34);
            this.BtnAutoChk.TabIndex = 8;
            this.BtnAutoChk.Text = "自動檢核";
            this.BtnAutoChk.UseVisualStyleBackColor = true;
            this.BtnAutoChk.Click += new System.EventHandler(this.BtnAutoChk_Click);
            // 
            // LblAutoChk
            // 
            this.LblAutoChk.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.LblAutoChk.Location = new System.Drawing.Point(458, 62);
            this.LblAutoChk.Name = "LblAutoChk";
            this.LblAutoChk.Size = new System.Drawing.Size(58, 26);
            this.LblAutoChk.TabIndex = 9;
            this.LblAutoChk.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Grp2
            // 
            this.Grp2.Controls.Add(this.radioButton9);
            this.Grp2.Controls.Add(this.radioButton8);
            this.Grp2.Controls.Add(this.radioButton7);
            this.Grp2.Location = new System.Drawing.Point(33, 269);
            this.Grp2.Name = "Grp2";
            this.Grp2.Size = new System.Drawing.Size(154, 155);
            this.Grp2.TabIndex = 10;
            this.Grp2.TabStop = false;
            this.Grp2.Text = "groupBox2";
            // 
            // radioButton9
            // 
            this.radioButton9.AutoSize = true;
            this.radioButton9.Location = new System.Drawing.Point(23, 117);
            this.radioButton9.Name = "radioButton9";
            this.radioButton9.Size = new System.Drawing.Size(108, 20);
            this.radioButton9.TabIndex = 2;
            this.radioButton9.TabStop = true;
            this.radioButton9.Text = "radioButton9";
            this.radioButton9.UseVisualStyleBackColor = true;
            // 
            // radioButton8
            // 
            this.radioButton8.AutoSize = true;
            this.radioButton8.Location = new System.Drawing.Point(23, 82);
            this.radioButton8.Name = "radioButton8";
            this.radioButton8.Size = new System.Drawing.Size(108, 20);
            this.radioButton8.TabIndex = 1;
            this.radioButton8.TabStop = true;
            this.radioButton8.Text = "radioButton8";
            this.radioButton8.UseVisualStyleBackColor = true;
            // 
            // radioButton7
            // 
            this.radioButton7.AutoSize = true;
            this.radioButton7.Location = new System.Drawing.Point(23, 45);
            this.radioButton7.Name = "radioButton7";
            this.radioButton7.Size = new System.Drawing.Size(108, 20);
            this.radioButton7.TabIndex = 0;
            this.radioButton7.TabStop = true;
            this.radioButton7.Text = "radioButton7";
            this.radioButton7.UseVisualStyleBackColor = true;
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.Location = new System.Drawing.Point(201, 312);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(108, 20);
            this.radioButton1.TabIndex = 0;
            this.radioButton1.TabStop = true;
            this.radioButton1.Text = "radioButton1";
            this.radioButton1.UseVisualStyleBackColor = true;
            // 
            // radioButton2
            // 
            this.radioButton2.AutoSize = true;
            this.radioButton2.Location = new System.Drawing.Point(201, 348);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(108, 20);
            this.radioButton2.TabIndex = 1;
            this.radioButton2.TabStop = true;
            this.radioButton2.Text = "radioButton2";
            this.radioButton2.UseVisualStyleBackColor = true;
            // 
            // radioButton3
            // 
            this.radioButton3.AutoSize = true;
            this.radioButton3.Location = new System.Drawing.Point(201, 386);
            this.radioButton3.Name = "radioButton3";
            this.radioButton3.Size = new System.Drawing.Size(108, 20);
            this.radioButton3.TabIndex = 2;
            this.radioButton3.TabStop = true;
            this.radioButton3.Text = "radioButton3";
            this.radioButton3.UseVisualStyleBackColor = true;
            // 
            // radioButton4
            // 
            this.radioButton4.AutoSize = true;
            this.radioButton4.Location = new System.Drawing.Point(326, 312);
            this.radioButton4.Name = "radioButton4";
            this.radioButton4.Size = new System.Drawing.Size(108, 20);
            this.radioButton4.TabIndex = 11;
            this.radioButton4.TabStop = true;
            this.radioButton4.Text = "radioButton4";
            this.radioButton4.UseVisualStyleBackColor = true;
            // 
            // radioButton5
            // 
            this.radioButton5.AutoSize = true;
            this.radioButton5.Location = new System.Drawing.Point(326, 348);
            this.radioButton5.Name = "radioButton5";
            this.radioButton5.Size = new System.Drawing.Size(108, 20);
            this.radioButton5.TabIndex = 12;
            this.radioButton5.TabStop = true;
            this.radioButton5.Text = "radioButton5";
            this.radioButton5.UseVisualStyleBackColor = true;
            // 
            // radioButton6
            // 
            this.radioButton6.AutoSize = true;
            this.radioButton6.Location = new System.Drawing.Point(326, 386);
            this.radioButton6.Name = "radioButton6";
            this.radioButton6.Size = new System.Drawing.Size(108, 20);
            this.radioButton6.TabIndex = 13;
            this.radioButton6.TabStop = true;
            this.radioButton6.Text = "radioButton6";
            this.radioButton6.UseVisualStyleBackColor = true;
            // 
            // Pan
            // 
            this.Pan.AutoScroll = true;
            this.Pan.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Pan.Controls.Add(this.radioButton12);
            this.Pan.Controls.Add(this.radioButton11);
            this.Pan.Controls.Add(this.radioButton10);
            this.Pan.Location = new System.Drawing.Point(458, 325);
            this.Pan.Name = "Pan";
            this.Pan.Size = new System.Drawing.Size(125, 81);
            this.Pan.TabIndex = 14;
            // 
            // radioButton12
            // 
            this.radioButton12.AutoSize = true;
            this.radioButton12.Location = new System.Drawing.Point(29, 72);
            this.radioButton12.Name = "radioButton12";
            this.radioButton12.Size = new System.Drawing.Size(108, 20);
            this.radioButton12.TabIndex = 2;
            this.radioButton12.TabStop = true;
            this.radioButton12.Text = "radioButton9";
            this.radioButton12.UseVisualStyleBackColor = true;
            // 
            // radioButton11
            // 
            this.radioButton11.AutoSize = true;
            this.radioButton11.Location = new System.Drawing.Point(29, 47);
            this.radioButton11.Name = "radioButton11";
            this.radioButton11.Size = new System.Drawing.Size(108, 20);
            this.radioButton11.TabIndex = 1;
            this.radioButton11.TabStop = true;
            this.radioButton11.Text = "radioButton8";
            this.radioButton11.UseVisualStyleBackColor = true;
            // 
            // radioButton10
            // 
            this.radioButton10.AutoSize = true;
            this.radioButton10.Location = new System.Drawing.Point(29, 21);
            this.radioButton10.Name = "radioButton10";
            this.radioButton10.Size = new System.Drawing.Size(108, 20);
            this.radioButton10.TabIndex = 0;
            this.radioButton10.TabStop = true;
            this.radioButton10.Text = "radioButton7";
            this.radioButton10.UseVisualStyleBackColor = true;
            // 
            // BtnGrpTxt
            // 
            this.BtnGrpTxt.AutoSize = true;
            this.BtnGrpTxt.Location = new System.Drawing.Point(447, 91);
            this.BtnGrpTxt.Name = "BtnGrpTxt";
            this.BtnGrpTxt.Size = new System.Drawing.Size(87, 34);
            this.BtnGrpTxt.TabIndex = 15;
            this.BtnGrpTxt.Text = "群組標籤";
            this.BtnGrpTxt.UseVisualStyleBackColor = true;
            this.BtnGrpTxt.Click += new System.EventHandler(this.BtnGrpTxt_Click);
            // 
            // BtnPnl
            // 
            this.BtnPnl.AutoSize = true;
            this.BtnPnl.Location = new System.Drawing.Point(448, 144);
            this.BtnPnl.Name = "BtnPnl";
            this.BtnPnl.Size = new System.Drawing.Size(87, 34);
            this.BtnPnl.TabIndex = 16;
            this.BtnPnl.Text = "面板";
            this.BtnPnl.UseVisualStyleBackColor = true;
            this.BtnPnl.Click += new System.EventHandler(this.BtnPnl_Click);
            // 
            // BtnChkSt
            // 
            this.BtnChkSt.AutoSize = true;
            this.BtnChkSt.Location = new System.Drawing.Point(448, 196);
            this.BtnChkSt.Name = "BtnChkSt";
            this.BtnChkSt.Size = new System.Drawing.Size(88, 34);
            this.BtnChkSt.TabIndex = 17;
            this.BtnChkSt.Text = "CheckState";
            this.BtnChkSt.UseVisualStyleBackColor = true;
            this.BtnChkSt.Click += new System.EventHandler(this.BtnChkSt_Click);
            // 
            // Btn3St
            // 
            this.Btn3St.AutoSize = true;
            this.Btn3St.Location = new System.Drawing.Point(447, 260);
            this.Btn3St.Name = "Btn3St";
            this.Btn3St.Size = new System.Drawing.Size(88, 34);
            this.Btn3St.TabIndex = 18;
            this.Btn3St.Text = "三態";
            this.Btn3St.UseVisualStyleBackColor = true;
            this.Btn3St.Click += new System.EventHandler(this.Btn3St_Click);
            // 
            // Chk
            // 
            this.Chk.AutoSize = true;
            this.Chk.Location = new System.Drawing.Point(448, 298);
            this.Chk.Name = "Chk";
            this.Chk.Size = new System.Drawing.Size(98, 20);
            this.Chk.TabIndex = 3;
            this.Chk.Text = "&checkBox1";
            this.Chk.UseVisualStyleBackColor = true;
            this.Chk.CheckedChanged += new System.EventHandler(this.Chk_CheckedChanged);
            this.Chk.CheckStateChanged += new System.EventHandler(this.Chk_CheckStateChanged);
            this.Chk.Click += new System.EventHandler(this.Chk_Click);
            // 
            // Lbl3St
            // 
            this.Lbl3St.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Lbl3St.Location = new System.Drawing.Point(458, 231);
            this.Lbl3St.Name = "Lbl3St";
            this.Lbl3St.Size = new System.Drawing.Size(58, 26);
            this.Lbl3St.TabIndex = 19;
            this.Lbl3St.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // FrmRdbChk
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(629, 441);
            this.Controls.Add(this.Lbl3St);
            this.Controls.Add(this.Chk);
            this.Controls.Add(this.Btn3St);
            this.Controls.Add(this.BtnChkSt);
            this.Controls.Add(this.BtnPnl);
            this.Controls.Add(this.BtnGrpTxt);
            this.Controls.Add(this.Pan);
            this.Controls.Add(this.radioButton6);
            this.Controls.Add(this.radioButton5);
            this.Controls.Add(this.radioButton4);
            this.Controls.Add(this.radioButton3);
            this.Controls.Add(this.radioButton2);
            this.Controls.Add(this.Grp2);
            this.Controls.Add(this.radioButton1);
            this.Controls.Add(this.LblAutoChk);
            this.Controls.Add(this.BtnAutoChk);
            this.Controls.Add(this.BtnEnab);
            this.Controls.Add(this.BtnText);
            this.Controls.Add(this.BtnAlg);
            this.Controls.Add(this.BtnApp);
            this.Controls.Add(this.BtnChkd);
            this.Controls.Add(this.groupBox1);
            this.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "FrmRdbChk";
            this.Text = "選項按鈕與核取方塊";
            this.Load += new System.EventHandler(this.FrmRdbChk_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.Grp2.ResumeLayout(false);
            this.Grp2.PerformLayout();
            this.Pan.ResumeLayout(false);
            this.Pan.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RadioButton Rdb1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton Rdb3;
        private System.Windows.Forms.RadioButton Rdb2;
        private System.Windows.Forms.Button BtnChkd;
        private System.Windows.Forms.Button BtnApp;
        private System.Windows.Forms.Button BtnAlg;
        private System.Windows.Forms.Button BtnText;
        private System.Windows.Forms.Button BtnEnab;
        private System.Windows.Forms.Button BtnAutoChk;
        private System.Windows.Forms.Label LblAutoChk;
        private System.Windows.Forms.GroupBox Grp2;
        private System.Windows.Forms.RadioButton radioButton9;
        private System.Windows.Forms.RadioButton radioButton8;
        private System.Windows.Forms.RadioButton radioButton7;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.RadioButton radioButton2;
        private System.Windows.Forms.RadioButton radioButton3;
        private System.Windows.Forms.RadioButton radioButton4;
        private System.Windows.Forms.RadioButton radioButton5;
        private System.Windows.Forms.RadioButton radioButton6;
        private System.Windows.Forms.Panel Pan;
        private System.Windows.Forms.RadioButton radioButton12;
        private System.Windows.Forms.RadioButton radioButton11;
        private System.Windows.Forms.RadioButton radioButton10;
        private System.Windows.Forms.Button BtnGrpTxt;
        private System.Windows.Forms.Button BtnPnl;
        private System.Windows.Forms.Button BtnChkSt;
        private System.Windows.Forms.Button Btn3St;
        private System.Windows.Forms.CheckBox Chk;
        private System.Windows.Forms.Label Lbl3St;
    }
}

