﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RdbChk
{
    public partial class FrmRdbChk : Form
    {
        public FrmRdbChk()
        {
            InitializeComponent();
        }

        private void FrmRdbChk_Load(object sender, EventArgs e)
        {
            Lbl3St.Text = (Chk.ThreeState).ToString();
            LblAutoChk.Text = (radioButton7.AutoCheck).ToString();
        }

        private void BtnChkd_Click(object sender, EventArgs e)
        {//採用on off的方式
            radioButton7.Checked = !radioButton7.Checked;
        }

        bool AppFlag = true;
        private void BtnApp_Click(object sender, EventArgs e)
        {//一般及按鈕兩種外觀間切換，所以設定一個全域變數之旗標AppFlag
            if (AppFlag) { Rdb2.Appearance = Appearance.Button; AppFlag =!AppFlag; }
            else {Rdb2.Appearance = Appearance.Normal; AppFlag = !AppFlag; }
    }

        private void BtnAlg_Click(object sender, EventArgs e)
        {//設定選項鈕分別在九個位置，再設定文字也分別在九個位置
            Rdb1.CheckAlign = ContentAlignment.TopLeft;
            MessageBox.Show("TopLeft");
            Rdb1.CheckAlign = ContentAlignment.TopCenter;
            MessageBox.Show("TopCenter");
            Rdb1.CheckAlign = ContentAlignment.TopRight;
            MessageBox.Show("TopRight");
            Rdb1.CheckAlign = ContentAlignment.MiddleLeft;
            MessageBox.Show("MiddleLeft");
            Rdb1.CheckAlign = ContentAlignment.MiddleCenter;
            MessageBox.Show("MiddleCenter");
            Rdb1.CheckAlign = ContentAlignment.MiddleRight;
            MessageBox.Show("MiddleRight");
            Rdb1.CheckAlign = ContentAlignment.BottomLeft;
            MessageBox.Show("BottomLeft");
            Rdb1.CheckAlign = ContentAlignment.BottomCenter;
            MessageBox.Show("BottomCenter");
            Rdb1.CheckAlign = ContentAlignment.BottomRight;
            MessageBox.Show("BottomRight");
            Rdb1.TextAlign = ContentAlignment.TopLeft;
            MessageBox.Show("TopLeft");
            Rdb1.TextAlign = ContentAlignment.TopCenter;
            MessageBox.Show("TopCenter");
            Rdb1.TextAlign = ContentAlignment.TopRight;
            MessageBox.Show("TopRight");
            Rdb1.TextAlign = ContentAlignment.MiddleLeft;
            MessageBox.Show("MiddleLeft");
            Rdb1.TextAlign = ContentAlignment.MiddleCenter;
            MessageBox.Show("MiddleCenter");
            Rdb1.TextAlign = ContentAlignment.MiddleRight;
            MessageBox.Show("MiddleRight");
            Rdb1.TextAlign = ContentAlignment.BottomLeft;
            MessageBox.Show("BottomLeft");
            Rdb1.TextAlign = ContentAlignment.BottomCenter;
            MessageBox.Show("BottomCenter");
            Rdb1.TextAlign = ContentAlignment.BottomRight;
            MessageBox.Show("BottomRight");
            Rdb1.TextAlign = ContentAlignment.MiddleCenter;///還原
            Rdb1.CheckAlign = ContentAlignment.MiddleLeft;
        }

        private void BtnText_Click(object sender, EventArgs e)
        {//改變選項按鈕的標題
            MessageBox.Show("radioButton3-->選項3");
            Rdb3.Text = "選項3";
        }

        private void BtnEnab_Click(object sender, EventArgs e)
        {//選項按鈕作動與不作動
            Rdb2.Enabled = !Rdb2.Enabled;//採on-off作法
        }

         private void BtnAutoChk_Click(object sender, EventArgs e)
        {//選項按鈕是否自動檢核，若非則無法點擊改變核選與否，但仍可用程式改變
            radioButton7.AutoCheck = !radioButton7.AutoCheck;//採on-off作法
            LblAutoChk.Text = (radioButton7.AutoCheck).ToString();//秀出目前AutoCheck是真或假
        }

       private void Rdb1_CheckedChanged(object sender, EventArgs e)
        {//演練選項按鈕事件觸發順序
            MessageBox.Show("第一個CheckedChanged");
        }

        private void Rdb1_Click(object sender, EventArgs e)
        {//演練選項按鈕事件觸發順序
            MessageBox.Show("第一個Click");
        }

        private void Rdb2_CheckedChanged(object sender, EventArgs e)
        {//演練選項按鈕事件觸發順序
            MessageBox.Show("第二個CheckedChanged");
        }

        private void Rdb2_Click(object sender, EventArgs e)
        {//演練選項按鈕事件觸發順序
            MessageBox.Show("第二個Click");
        }

        private void BtnGrpTxt_Click(object sender, EventArgs e)
        {//演練群組方塊標題改變
            Grp2.Text = "群組2";
        }

        private void BtnPnl_Click(object sender, EventArgs e)
        {//演練面板的自動捲軸
            Pan.AutoScroll = !Pan.AutoScroll;
        }

        private void BtnChkSt_Click(object sender, EventArgs e)
        {//演練核取與三態設定及其觸動事件
            MessageBox.Show("將反轉Checked");
            Chk.Checked = !Chk.Checked;
            MessageBox.Show("將把Checked轉回");
            Chk.Checked = !Chk.Checked;
            MessageBox.Show("將設定CheckState為Indeterminate");
            Chk.CheckState = CheckState.Indeterminate;
            MessageBox.Show("將設定CheckState為Checked");
            Chk.CheckState = CheckState.Checked;//不會觸動CheckedChanged，因為CheckState為Indeterminate及Checked時，Checked都是true
            MessageBox.Show("將設定CheckState為Unchecked");
            Chk.CheckState = CheckState.Unchecked;
        }

        private void Chk_CheckedChanged(object sender, EventArgs e)
        {//演練核取方塊事件觸發順序
            MessageBox.Show("觸發CheckedChanged事件且" + "Checked=" + Chk.Checked + "; CheckState=" + Chk.CheckState);
        }

        private void Chk_CheckStateChanged(object sender, EventArgs e)
        {//演練核取方塊事件觸發順序
            MessageBox.Show("觸發CheckStateChanged事件且" + "Checked=" + Chk.Checked + "; CheckState=" + Chk.CheckState);
        }

        private void Chk_Click(object sender, EventArgs e)
        {//演練核取方塊事件觸發順序
            MessageBox.Show("觸發Click事件且" + "Checked=" + Chk.Checked + "; CheckState=" + Chk.CheckState);
        }

        private void Btn3St_Click(object sender, EventArgs e)
        {//設定核取方塊的三態，採on-off方式
            Chk.ThreeState = !Chk.ThreeState;
            Lbl3St.Text = (Chk.ThreeState).ToString();//在標籤秀出目前的三態設定
        }
    }
}
