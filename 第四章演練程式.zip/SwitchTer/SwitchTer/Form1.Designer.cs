﻿namespace SwitchTer
{
    partial class SwitchTer
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.BtnSW = new System.Windows.Forms.Button();
            this.BtnSW2 = new System.Windows.Forms.Button();
            this.BtnMax = new System.Windows.Forms.Button();
            this.BtnNestMax = new System.Windows.Forms.Button();
            this.BtnNestPrice = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // BtnSW
            // 
            this.BtnSW.AutoSize = true;
            this.BtnSW.Location = new System.Drawing.Point(70, 51);
            this.BtnSW.Name = "BtnSW";
            this.BtnSW.Size = new System.Drawing.Size(130, 34);
            this.BtnSW.TabIndex = 0;
            this.BtnSW.Text = "Switch數值";
            this.BtnSW.UseVisualStyleBackColor = true;
            this.BtnSW.Click += new System.EventHandler(this.BtnSW_Click);
            // 
            // BtnSW2
            // 
            this.BtnSW2.AutoSize = true;
            this.BtnSW2.Location = new System.Drawing.Point(248, 51);
            this.BtnSW2.Name = "BtnSW2";
            this.BtnSW2.Size = new System.Drawing.Size(130, 34);
            this.BtnSW2.TabIndex = 1;
            this.BtnSW2.Text = "Switch字串";
            this.BtnSW2.UseVisualStyleBackColor = true;
            this.BtnSW2.Click += new System.EventHandler(this.BtnSW2_Click);
            // 
            // BtnMax
            // 
            this.BtnMax.AutoSize = true;
            this.BtnMax.Location = new System.Drawing.Point(433, 51);
            this.BtnMax.Name = "BtnMax";
            this.BtnMax.Size = new System.Drawing.Size(140, 34);
            this.BtnMax.TabIndex = 2;
            this.BtnMax.Text = "三元運算子";
            this.BtnMax.UseVisualStyleBackColor = true;
            this.BtnMax.Click += new System.EventHandler(this.BtnMax_Click);
            // 
            // BtnNestMax
            // 
            this.BtnNestMax.AutoSize = true;
            this.BtnNestMax.Location = new System.Drawing.Point(120, 120);
            this.BtnNestMax.Name = "BtnNestMax";
            this.BtnNestMax.Size = new System.Drawing.Size(157, 34);
            this.BtnNestMax.TabIndex = 3;
            this.BtnNestMax.Text = "巢式三元Max";
            this.BtnNestMax.UseVisualStyleBackColor = true;
            this.BtnNestMax.Click += new System.EventHandler(this.BtnNestMax_Click);
            // 
            // BtnNestPrice
            // 
            this.BtnNestPrice.AutoSize = true;
            this.BtnNestPrice.Location = new System.Drawing.Point(369, 120);
            this.BtnNestPrice.Name = "BtnNestPrice";
            this.BtnNestPrice.Size = new System.Drawing.Size(163, 34);
            this.BtnNestPrice.TabIndex = 4;
            this.BtnNestPrice.Text = "巢式三元Price";
            this.BtnNestPrice.UseVisualStyleBackColor = true;
            this.BtnNestPrice.Click += new System.EventHandler(this.BtnNestPrice_Click);
            // 
            // SwitchTer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(13F, 24F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(642, 213);
            this.Controls.Add(this.BtnNestPrice);
            this.Controls.Add(this.BtnNestMax);
            this.Controls.Add(this.BtnMax);
            this.Controls.Add(this.BtnSW2);
            this.Controls.Add(this.BtnSW);
            this.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "SwitchTer";
            this.Text = "SwitchTer";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button BtnSW;
        private System.Windows.Forms.Button BtnSW2;
        private System.Windows.Forms.Button BtnMax;
        private System.Windows.Forms.Button BtnNestMax;
        private System.Windows.Forms.Button BtnNestPrice;
    }
}

