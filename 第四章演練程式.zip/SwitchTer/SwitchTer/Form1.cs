﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SwitchTer
{
    public partial class SwitchTer : Form
    {
        public SwitchTer()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            int IntVar=7, Int1, Int2;
            switch (IntVar)
            {
                //case 1.2: break;//型別不匹配
                case 2: break;
                //case 4: MessageBox.Show("2");//有敘述一定要有break;
                //case (Int1+Int2): break;//比較值不可以是變數或另一個運算式
                //case Int2: break;//比較值不可以是變數或另一個運算式
                default:
                    break;
            }
        }

        private void BtnSW_Click(object sender, EventArgs e)
        {
            int Point;
            do
            {//SOP:輸入空字串或取消則結束，否則取值含例外處理。未例外也要判斷範圍再執行要求的處理
                string StrIn = Microsoft.VisualBasic.Interaction.InputBox("請輸入0-10正整數積點");
                if (StrIn == "")
                {//看輸入是否空字串或取消，是則結束，返回表單
                    MessageBox.Show("輸入空字串或按取消，故結束此程序");
                    return;
                }
                else
                {//否則取出整數含例外處理（警示並進行下一輪迴圈）
                    try { Point = Convert.ToInt32(StrIn); }
                    catch { MessageBox.Show("錯誤：輸入非數值"); continue; }
                }
                //確定整數則判斷是否超出範圍，是則警示（並進行下一輪迴圈，不用continue，因為後面無敘述）
                if (Point < 0 || Point > 10) MessageBox.Show("錯誤：請輸入0-10正整數");
                else break;//若不跳出，迴圈外敘述永遠做不到
            } while (true);
            //以下敘述寫在上面可產生執行多次的效果，寫在迴圈外，只會執行一次
            string Level;
            switch (Point)
            {
                case 10://沒有寫敘述，會直接做下個case的敘述
                case 9: Level = "優"; break;
                case 8:
                case 7: Level = "佳"; break;
                case 6:
                case 5: Level = "可"; break;
                default: Level = "差"; break;
            }
            MessageBox.Show(Point + "點的水平是" + Level);
        }

        private void BtnSW2_Click(object sender, EventArgs e)
        {
            string Class = Microsoft.VisualBasic.Interaction.InputBox("請輸入A-C的等級");
            int Num = 0;
            switch (Class)
            {
                case "A": Num += 3; break;
                case "B": Num += 2; break;
                case "C": Num += 1; break;
                default: MessageBox.Show("輸入錯誤"); break;
            }
            MessageBox.Show("輸入之等級為：" + Class + "可以加" + Num + "分");
        }

        private void BtnMax_Click(object sender, EventArgs e)
        {
            double a, b;
            do
            {
                string StrIn = Microsoft.VisualBasic.Interaction.InputBox("請輸入第一個數");
                try { a = Convert.ToDouble(StrIn); break; }
                catch { MessageBox.Show("輸入非數值，請重新輸入"); }
            } while (true);

            do
            {
                string StrIn = Microsoft.VisualBasic.Interaction.InputBox("請輸入第二個數");
                try { b = Convert.ToDouble(StrIn); break; }
                catch { MessageBox.Show("輸入非數值，請重新輸入"); }
            } while (true);
            double max = a > b ? a : b;//三元運算子求二數最大值
            MessageBox.Show(a + "與" + b + "的最大值為：" + max);
        }

        private void BtnNestMax_Click(object sender, EventArgs e)
        {
            double a, b, c;
            do
            {
                string StrIn = Microsoft.VisualBasic.Interaction.InputBox("請輸入第一個數");
                try { a = Convert.ToDouble(StrIn); break; }
                catch { MessageBox.Show("輸入非數值，請重新輸入"); }
            } while (true);

            do
            {
                string StrIn = Microsoft.VisualBasic.Interaction.InputBox("請輸入第二個數");
                try { b = Convert.ToDouble(StrIn); break; }
                catch { MessageBox.Show("輸入非數值，請重新輸入"); }
            } while (true);

            do
            {
                string StrIn = Microsoft.VisualBasic.Interaction.InputBox("請輸入第三個數");
                try { c = Convert.ToDouble(StrIn); break; }
                catch { MessageBox.Show("輸入非數值，請重新輸入"); }
            } while (true);
            double max = a > b ? (a > c ? a : c) : (b > c ? b : c);//三元運算子求二數最大值
            MessageBox.Show(a + "、" + b + "、" + c + "的最大值為：" + max);
        }

        private void BtnNestPrice_Click(object sender, EventArgs e)
        {
            int age, price;
            do
            {
                string StrIn = Microsoft.VisualBasic.Interaction.InputBox("請輸入年紀（正整數）");
                if (StrIn == "")
                {//看輸入是否空字串或取消，是則結束，返回表單
                    MessageBox.Show("輸入空字串或按取消，故結束此程序");
                    return;
                }
                else
                {
                    try { age = Convert.ToInt32(StrIn); }
                    catch { MessageBox.Show("輸入非數值，請重新輸入"); continue; }
                }
                //確定整數則判斷是否超出範圍，是則警示（並進行下一輪迴圈，不用continue，因為後面無敘述）
                if (age < 0) { MessageBox.Show("輸入負值，請重新輸入"); }
                else break;//若不跳出，迴圈外敘述永遠做不到
            } while (true);
            //以下敘述寫在上面可產生執行多次的效果，寫在迴圈外，只會執行一次
            //小於等於10歲不用錢，10歲以上60歲以下100元，60歲以上50元
            price = age <= 10 ? 0 : (age < 60 ? 100 : 50);//三元運算子用年紀求票價
            MessageBox.Show("年紀" + age + "，票價" + price + "元");
        }
    }
}
