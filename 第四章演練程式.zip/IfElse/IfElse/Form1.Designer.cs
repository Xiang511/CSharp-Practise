﻿namespace IfElse
{
    partial class IfElse
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.BtnDblSlct = new System.Windows.Forms.Button();
            this.BtnSngSlct = new System.Windows.Forms.Button();
            this.BtnMulSlct = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // BtnDblSlct
            // 
            this.BtnDblSlct.AutoSize = true;
            this.BtnDblSlct.Location = new System.Drawing.Point(37, 33);
            this.BtnDblSlct.Name = "BtnDblSlct";
            this.BtnDblSlct.Size = new System.Drawing.Size(116, 34);
            this.BtnDblSlct.TabIndex = 0;
            this.BtnDblSlct.Text = "雙重選擇";
            this.BtnDblSlct.UseVisualStyleBackColor = true;
            this.BtnDblSlct.Click += new System.EventHandler(this.BtnDblSlct_Click);
            // 
            // BtnSngSlct
            // 
            this.BtnSngSlct.AutoSize = true;
            this.BtnSngSlct.Location = new System.Drawing.Point(180, 33);
            this.BtnSngSlct.Name = "BtnSngSlct";
            this.BtnSngSlct.Size = new System.Drawing.Size(116, 34);
            this.BtnSngSlct.TabIndex = 1;
            this.BtnSngSlct.Text = "單一選擇";
            this.BtnSngSlct.UseVisualStyleBackColor = true;
            this.BtnSngSlct.Click += new System.EventHandler(this.BtnSngSlct_Click);
            // 
            // BtnMulSlct
            // 
            this.BtnMulSlct.AutoSize = true;
            this.BtnMulSlct.Location = new System.Drawing.Point(323, 33);
            this.BtnMulSlct.Name = "BtnMulSlct";
            this.BtnMulSlct.Size = new System.Drawing.Size(116, 34);
            this.BtnMulSlct.TabIndex = 2;
            this.BtnMulSlct.Text = "多重選擇";
            this.BtnMulSlct.UseVisualStyleBackColor = true;
            this.BtnMulSlct.Click += new System.EventHandler(this.BtnMulSlct_Click);
            // 
            // IfElse
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(13F, 24F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(490, 100);
            this.Controls.Add(this.BtnMulSlct);
            this.Controls.Add(this.BtnSngSlct);
            this.Controls.Add(this.BtnDblSlct);
            this.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "IfElse";
            this.Text = "IfElse";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button BtnDblSlct;
        private System.Windows.Forms.Button BtnSngSlct;
        private System.Windows.Forms.Button BtnMulSlct;
    }
}

