﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IfElse
{
    public partial class IfElse : Form
    {
        public IfElse()
        {
            InitializeComponent();
        }

        private void BtnDblSlct_Click(object sender, EventArgs e)
        {
            int age;
            do
            {//SOP:輸入空字串或取消則結束，否則取值含例外處理。未例外也要判斷範圍再執行要求的處理
                string StrIn = Microsoft.VisualBasic.Interaction.InputBox("請輸入年紀（正整數）");
                if (StrIn == "")
                {//看輸入是否空字串或取消，是則結束，返回表單
                    MessageBox.Show("輸入空字串或按取消，故結束此程序");
                    return;
                }
                else
                {//否則取出整數含例外處理（警示並進行下一輪迴圈）
                    try { age = Convert.ToInt32(StrIn); }
                    catch { MessageBox.Show("錯誤：輸入非數值"); continue; }
                }
                //確定整數則判斷是否為負，是則警示（並進行下一輪迴圈，不用continue，因為後面無敘述）
                if (age < 0) MessageBox.Show("錯誤：輸入非正值");
                else break;//若不跳出，迴圈外敘述永遠做不到
                //else if ((age >= 18)) MessageBox.Show("成年");
                //else MessageBox.Show("未成年");
            } while (true);
            //以下雙重選擇寫在上面可產生執行多次的效果，寫在迴圈外，只會執行一次
            if ((age >= 18)) MessageBox.Show("成年");
            else MessageBox.Show("未成年");
        }

        private void BtnSngSlct_Click(object sender, EventArgs e)
        {
            double Num;
            do
            {//SOP:輸入空字串或取消則結束，否則取值含例外處理。（未例外也要判斷範圍再執行要求的處理）
                string StrIn = Microsoft.VisualBasic.Interaction.InputBox("請輸入數字");
                if (StrIn == "")
                {//看輸入是否空字串或取消，是則結束，返回表單
                    MessageBox.Show("輸入空字串或按取消，故結束此程序");
                    return;
                }
                else
                {//否則取出數值含例外處理（警示並進行下一輪迴圈）
                    try { Num = Convert.ToDouble(StrIn); break; }//若無範圍問題則直接跳出迴圈，但...
                    catch { MessageBox.Show("錯誤：輸入非數值"); continue; }
                }
                //若以下這些敘述是寫在迴圈內，則上面不可用break
                //string StrOut = Num + "的絕對值為：";
                //if ((Num < 0)) Num = -Num;
                //MessageBox.Show(StrOut + Num);
            } while (true);
            //以下敘述寫在上面可產生執行多次的效果，寫在迴圈外，只會執行一次
            string StrOut = Num + "的絕對值為：";
            if ((Num < 0)) Num = -Num;
            MessageBox.Show(StrOut + Num);
            //上面的敘述，也可以寫成
            //if ((Num < 0)) MessageBox.Show(Num + "的絕對值為：" + -Num);
            //else MessageBox.Show(Num + "的絕對值為：" + Num);
        }

        private void BtnMulSlct_Click(object sender, EventArgs e)
        {
            int Score;
            do
            {//SOP:輸入空字串或取消則結束，否則取值含例外處理。未例外也要判斷範圍再執行要求的處理
                string StrIn = Microsoft.VisualBasic.Interaction.InputBox("請輸入0-100正整數分數");
                if (StrIn == "")
                {//看輸入是否空字串或取消，是則結束，返回表單
                    MessageBox.Show("輸入空字串或按取消，故結束此程序");
                    return;
                }
                else
                {//否則取出整數含例外處理（警示並進行下一輪迴圈）
                    try { Score = Convert.ToInt32(StrIn); }
                    catch { MessageBox.Show("錯誤：輸入非數值"); continue; }
                }
                //確定整數則判斷是否超出範圍，是則警示（並進行下一輪迴圈，不用continue，因為後面無敘述）
                if (Score < 0 || Score >100) MessageBox.Show("錯誤：請輸入0-100正整數");
                else break;//若不跳出，迴圈外敘述永遠做不到
            } while (true);
            //以下敘述寫在上面可產生執行多次的效果，寫在迴圈外，只會執行一次
            string Asm;
            if (Score >= 90) { Asm = "甲等"; }
            else if (Score >= 80) { Asm = "乙等"; }
            else if (Score >= 70) { Asm = "丙等"; }
            else { Asm = "丁等"; }
            MessageBox.Show(Score + "分的等級是" + Asm);
        }
    }
}
