﻿namespace _3_2LblBtn
{
    partial class Form1
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.LblAutoSize = new System.Windows.Forms.Label();
            this.LblBderStyle = new System.Windows.Forms.Label();
            this.LblFont = new System.Windows.Forms.Label();
            this.LblFBColor = new System.Windows.Forms.Label();
            this.LblImage = new System.Windows.Forms.Label();
            this.BtnTarget = new System.Windows.Forms.Button();
            this.BtnEnable = new System.Windows.Forms.Button();
            this.BtnTabStop = new System.Windows.Forms.Button();
            this.BtnVisible = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // LblAutoSize
            // 
            this.LblAutoSize.AutoSize = true;
            this.LblAutoSize.Location = new System.Drawing.Point(42, 39);
            this.LblAutoSize.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.LblAutoSize.Name = "LblAutoSize";
            this.LblAutoSize.Size = new System.Drawing.Size(104, 16);
            this.LblAutoSize.TabIndex = 0;
            this.LblAutoSize.Text = "自動調整大小";
            this.LblAutoSize.Click += new System.EventHandler(this.LblAutoSize_Click);
            // 
            // LblBderStyle
            // 
            this.LblBderStyle.AutoSize = true;
            this.LblBderStyle.Location = new System.Drawing.Point(42, 79);
            this.LblBderStyle.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.LblBderStyle.Name = "LblBderStyle";
            this.LblBderStyle.Size = new System.Drawing.Size(72, 16);
            this.LblBderStyle.TabIndex = 1;
            this.LblBderStyle.Text = "邊框樣式";
            this.LblBderStyle.Click += new System.EventHandler(this.LblBderStyle_Click);
            // 
            // LblFont
            // 
            this.LblFont.AutoSize = true;
            this.LblFont.Location = new System.Drawing.Point(42, 121);
            this.LblFont.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.LblFont.Name = "LblFont";
            this.LblFont.Size = new System.Drawing.Size(72, 16);
            this.LblFont.TabIndex = 2;
            this.LblFont.Text = "字體樣式";
            this.LblFont.Click += new System.EventHandler(this.LblFont_Click);
            // 
            // LblFBColor
            // 
            this.LblFBColor.AutoSize = true;
            this.LblFBColor.Location = new System.Drawing.Point(42, 165);
            this.LblFBColor.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.LblFBColor.Name = "LblFBColor";
            this.LblFBColor.Size = new System.Drawing.Size(104, 16);
            this.LblFBColor.TabIndex = 4;
            this.LblFBColor.Text = "前景背景顏色";
            this.LblFBColor.Click += new System.EventHandler(this.LblFBColor_Click);
            // 
            // LblImage
            // 
            this.LblImage.AutoSize = true;
            this.LblImage.Location = new System.Drawing.Point(42, 210);
            this.LblImage.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.LblImage.Name = "LblImage";
            this.LblImage.Size = new System.Drawing.Size(72, 16);
            this.LblImage.TabIndex = 5;
            this.LblImage.Text = "標籤影像";
            this.LblImage.Click += new System.EventHandler(this.LblImage_Click);
            // 
            // BtnTarget
            // 
            this.BtnTarget.AutoSize = true;
            this.BtnTarget.Location = new System.Drawing.Point(216, 36);
            this.BtnTarget.Name = "BtnTarget";
            this.BtnTarget.Size = new System.Drawing.Size(82, 26);
            this.BtnTarget.TabIndex = 6;
            this.BtnTarget.Text = "標的按鈕";
            this.BtnTarget.UseVisualStyleBackColor = true;
            this.BtnTarget.Click += new System.EventHandler(this.BtnTarget_Click);
            // 
            // BtnEnable
            // 
            this.BtnEnable.AutoSize = true;
            this.BtnEnable.Location = new System.Drawing.Point(216, 79);
            this.BtnEnable.Name = "BtnEnable";
            this.BtnEnable.Size = new System.Drawing.Size(82, 26);
            this.BtnEnable.TabIndex = 7;
            this.BtnEnable.Text = "按鈕致動";
            this.BtnEnable.UseVisualStyleBackColor = true;
            this.BtnEnable.Click += new System.EventHandler(this.BtnEnable_Click);
            // 
            // BtnTabStop
            // 
            this.BtnTabStop.AutoSize = true;
            this.BtnTabStop.Location = new System.Drawing.Point(216, 121);
            this.BtnTabStop.Name = "BtnTabStop";
            this.BtnTabStop.Size = new System.Drawing.Size(82, 26);
            this.BtnTabStop.TabIndex = 8;
            this.BtnTabStop.Text = "按鈕停駐";
            this.BtnTabStop.UseVisualStyleBackColor = true;
            this.BtnTabStop.Click += new System.EventHandler(this.BtnTabStop_Click);
            // 
            // BtnVisible
            // 
            this.BtnVisible.AutoSize = true;
            this.BtnVisible.Location = new System.Drawing.Point(216, 164);
            this.BtnVisible.Name = "BtnVisible";
            this.BtnVisible.Size = new System.Drawing.Size(82, 26);
            this.BtnVisible.TabIndex = 9;
            this.BtnVisible.Text = "按鈕可見";
            this.BtnVisible.UseVisualStyleBackColor = true;
            this.BtnVisible.Click += new System.EventHandler(this.BtnVisible_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(366, 379);
            this.Controls.Add(this.BtnVisible);
            this.Controls.Add(this.BtnTabStop);
            this.Controls.Add(this.BtnEnable);
            this.Controls.Add(this.BtnTarget);
            this.Controls.Add(this.LblImage);
            this.Controls.Add(this.LblFBColor);
            this.Controls.Add(this.LblFont);
            this.Controls.Add(this.LblBderStyle);
            this.Controls.Add(this.LblAutoSize);
            this.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Form1";
            this.Text = "籤標與按鈕";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label LblAutoSize;
        private System.Windows.Forms.Label LblBderStyle;
        private System.Windows.Forms.Label LblFont;
        private System.Windows.Forms.Label LblFBColor;
        private System.Windows.Forms.Label LblImage;
        private System.Windows.Forms.Button BtnTarget;
        private System.Windows.Forms.Button BtnEnable;
        private System.Windows.Forms.Button BtnTabStop;
        private System.Windows.Forms.Button BtnVisible;
    }
}

