﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _3_2LblBtn
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void LblAutoSize_Click(object sender, EventArgs e)
        {//Size都是設定(50,10)，但有否自動調整大小，結果不同
            LblAutoSize.Size = new Size(50, 10);
            LblAutoSize.AutoSize = !LblAutoSize.AutoSize;
        }//採on-off的方式，按一次自動，再按一次變非自動

        private void LblBderStyle_Click(object sender, EventArgs e)
        {//設定標籤邊框
            LblBderStyle.BorderStyle = BorderStyle.FixedSingle;
            MessageBox.Show("單線固定");
            LblBderStyle.BorderStyle = BorderStyle.Fixed3D;
            MessageBox.Show("立體固定");
            LblBderStyle.BorderStyle = BorderStyle.None;
            MessageBox.Show("恢復預設-無");
        }

        private void LblFont_Click(object sender, EventArgs e)
        {
            //Regular, Bold, Italic, Underline, Strikeout分別由低到高設定1個位元為1，所以可以用或「|」加以組合 
            LblFont.Font = new Font("標楷體", 14, FontStyle.Italic | FontStyle.Bold | FontStyle.Strikeout);
            MessageBox.Show("標楷體14點斜體加粗體加刪除線");
            LblFont.Font = new Font("新細明體", 12);//還原
        }

        private void LblFBColor_Click(object sender, EventArgs e)
        {
            LblFBColor.ForeColor = Color.Red;//設定顏色最常用的方法是用Color，使用常用色
            MessageBox.Show("用Color.Red把前景設為紅色");
            LblFBColor.BackColor = Color.FromKnownColor(KnownColor.Blue);//這種方式選項似乎較多
            MessageBox.Show("用Color.FromKnownColor(KnownColor.Blue把背景設為藍色");
            LblFBColor.ForeColor = Color.FromArgb(3, 252, 36);//用RGB三色去調，每色0~255
            MessageBox.Show("用Color.FromArgb(3, 252, 36)把前景變為某種綠色");
            LblFBColor.ForeColor = SystemColors.ControlText;//還原
            LblFBColor.BackColor = SystemColors.Control;//還原
        }

        private void LblImage_Click(object sender, EventArgs e)
        {//載入圖片，改變圖片及文字位置
            LblImage.BorderStyle = BorderStyle.FixedSingle;//加邊框方便辨識圖片位置
            LblImage.Size = new Size(150, 150);//設定新大小以容下圖片
            LblImage.AutoSize = false;//不自動調整大小才能有新的大小
            LblImage.Image = Image.FromFile(".\\ISUs.jpg");//反斜線\是特殊符號(跳脫字元)，所以路徑中的反斜線也「跳脫」
            MessageBox.Show("這是用Image.FromFile()");//兩種載圖方式一樣
            LblImage.Image = new Bitmap(".\\EEs.jpg");
            MessageBox.Show("這是用new Bitmap()");
            LblImage.ImageAlign = ContentAlignment.TopRight;
            MessageBox.Show("圖片對齊右上");
            LblImage.TextAlign = ContentAlignment.MiddleCenter;
            MessageBox.Show("文字上下左右對中");
            LblImage.Image = null;//設定成沒有背景圖，即預設
            LblImage.BorderStyle = BorderStyle.None;//還原邊框
            LblImage.AutoSize = true;//還原自動調整大小
            LblImage.ImageAlign = ContentAlignment.MiddleCenter;//還原圖形置中
            LblImage.TextAlign = ContentAlignment.TopLeft;//還原文字對左上
        }

        private void BtnTarget_Click(object sender, EventArgs e)
        {
            MessageBox.Show("我是標的按鈕");
        }

        private void BtnEnable_Click(object sender, EventArgs e)
        {//設定標的按鈕可否致動，採on-off設計，按一次變不能致動，再按一次變可以
            BtnTarget.Enabled = !BtnTarget.Enabled;
            MessageBox.Show("標的按鈕致動為" + BtnTarget.Enabled);
        }//需可見才能致動

        private void BtnTabStop_Click(object sender, EventArgs e)
        {//設定標的按鈕可否停駐，採on-off設計，按一次變不能停駐，再按一次變可以
            BtnTarget.TabStop = !BtnTarget.TabStop;
            MessageBox.Show("標的按鈕停駐為" + BtnTarget.TabStop);
        }//按鈕需致動且可見，才能停駐。不能停駐仍可使用滑鼠點擊觸動處理程序

        private void BtnVisible_Click(object sender, EventArgs e)
        {//設定標的按鈕是否可見，採on-off設計，按一次變不見，再按一次變可見
            BtnTarget.Visible = !BtnTarget.Visible;
            MessageBox.Show("標的按鈕可見為" + BtnTarget.Visible);
        }//不可見當然不能致動，也不能停駐
    }
}
