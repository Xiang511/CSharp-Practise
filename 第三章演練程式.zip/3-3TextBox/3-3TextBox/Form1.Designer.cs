﻿namespace _3_3TextBox
{
    partial class Form1
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.GrpMaxLen = new System.Windows.Forms.GroupBox();
            this.Rdb15 = new System.Windows.Forms.RadioButton();
            this.Rdb10 = new System.Windows.Forms.RadioButton();
            this.Rdb5 = new System.Windows.Forms.RadioButton();
            this.ChkPsw = new System.Windows.Forms.CheckBox();
            this.ChkReadOnly = new System.Windows.Forms.CheckBox();
            this.Txt1 = new System.Windows.Forms.TextBox();
            this.ChkWdWrap = new System.Windows.Forms.CheckBox();
            this.ChkMLine = new System.Windows.Forms.CheckBox();
            this.GrpSclBar = new System.Windows.Forms.GroupBox();
            this.RdbBoth = new System.Windows.Forms.RadioButton();
            this.RdbV = new System.Windows.Forms.RadioButton();
            this.RdbH = new System.Windows.Forms.RadioButton();
            this.RdbNone = new System.Windows.Forms.RadioButton();
            this.Txt2 = new System.Windows.Forms.TextBox();
            this.ChkTxtW = new System.Windows.Forms.CheckBox();
            this.ChkTxtH = new System.Windows.Forms.CheckBox();
            this.Btn2Str = new System.Windows.Forms.Button();
            this.Btn2Num = new System.Windows.Forms.Button();
            this.BtnFocus = new System.Windows.Forms.Button();
            this.BtnClear = new System.Windows.Forms.Button();
            this.GrpMaxLen.SuspendLayout();
            this.GrpSclBar.SuspendLayout();
            this.SuspendLayout();
            // 
            // GrpMaxLen
            // 
            this.GrpMaxLen.Controls.Add(this.Rdb15);
            this.GrpMaxLen.Controls.Add(this.Rdb10);
            this.GrpMaxLen.Controls.Add(this.Rdb5);
            this.GrpMaxLen.Location = new System.Drawing.Point(22, 23);
            this.GrpMaxLen.Margin = new System.Windows.Forms.Padding(4);
            this.GrpMaxLen.Name = "GrpMaxLen";
            this.GrpMaxLen.Padding = new System.Windows.Forms.Padding(4);
            this.GrpMaxLen.Size = new System.Drawing.Size(182, 76);
            this.GrpMaxLen.TabIndex = 0;
            this.GrpMaxLen.TabStop = false;
            this.GrpMaxLen.Text = "最多字元數";
            // 
            // Rdb15
            // 
            this.Rdb15.AutoSize = true;
            this.Rdb15.Location = new System.Drawing.Point(131, 38);
            this.Rdb15.Name = "Rdb15";
            this.Rdb15.Size = new System.Drawing.Size(42, 20);
            this.Rdb15.TabIndex = 2;
            this.Rdb15.Text = "15";
            this.Rdb15.UseVisualStyleBackColor = true;
            this.Rdb15.CheckedChanged += new System.EventHandler(this.Rdb15_CheckedChanged);
            // 
            // Rdb10
            // 
            this.Rdb10.AutoSize = true;
            this.Rdb10.Location = new System.Drawing.Point(68, 38);
            this.Rdb10.Name = "Rdb10";
            this.Rdb10.Size = new System.Drawing.Size(42, 20);
            this.Rdb10.TabIndex = 1;
            this.Rdb10.Text = "10";
            this.Rdb10.UseVisualStyleBackColor = true;
            this.Rdb10.CheckedChanged += new System.EventHandler(this.Rdb10_CheckedChanged);
            // 
            // Rdb5
            // 
            this.Rdb5.AutoSize = true;
            this.Rdb5.Location = new System.Drawing.Point(16, 38);
            this.Rdb5.Name = "Rdb5";
            this.Rdb5.Size = new System.Drawing.Size(34, 20);
            this.Rdb5.TabIndex = 0;
            this.Rdb5.Text = "5";
            this.Rdb5.UseVisualStyleBackColor = true;
            this.Rdb5.CheckedChanged += new System.EventHandler(this.Rdb5_CheckedChanged);
            // 
            // ChkPsw
            // 
            this.ChkPsw.AutoSize = true;
            this.ChkPsw.Location = new System.Drawing.Point(22, 124);
            this.ChkPsw.Name = "ChkPsw";
            this.ChkPsw.Size = new System.Drawing.Size(75, 20);
            this.ChkPsw.TabIndex = 3;
            this.ChkPsw.Text = "密碼字";
            this.ChkPsw.UseVisualStyleBackColor = true;
            this.ChkPsw.CheckedChanged += new System.EventHandler(this.ChkPsw_CheckedChanged);
            // 
            // ChkReadOnly
            // 
            this.ChkReadOnly.AutoSize = true;
            this.ChkReadOnly.Location = new System.Drawing.Point(129, 124);
            this.ChkReadOnly.Name = "ChkReadOnly";
            this.ChkReadOnly.Size = new System.Drawing.Size(59, 20);
            this.ChkReadOnly.TabIndex = 4;
            this.ChkReadOnly.Text = "唯讀";
            this.ChkReadOnly.UseVisualStyleBackColor = true;
            this.ChkReadOnly.CheckedChanged += new System.EventHandler(this.ChkReadOnly_CheckedChanged);
            // 
            // Txt1
            // 
            this.Txt1.Location = new System.Drawing.Point(22, 167);
            this.Txt1.Name = "Txt1";
            this.Txt1.Size = new System.Drawing.Size(182, 27);
            this.Txt1.TabIndex = 5;
            // 
            // ChkWdWrap
            // 
            this.ChkWdWrap.AutoSize = true;
            this.ChkWdWrap.Checked = true;
            this.ChkWdWrap.CheckState = System.Windows.Forms.CheckState.Checked;
            this.ChkWdWrap.Location = new System.Drawing.Point(339, 23);
            this.ChkWdWrap.Name = "ChkWdWrap";
            this.ChkWdWrap.Size = new System.Drawing.Size(59, 20);
            this.ChkWdWrap.TabIndex = 7;
            this.ChkWdWrap.Text = "換行";
            this.ChkWdWrap.UseVisualStyleBackColor = true;
            this.ChkWdWrap.CheckedChanged += new System.EventHandler(this.ChkWdWrap_CheckedChanged);
            // 
            // ChkMLine
            // 
            this.ChkMLine.AutoSize = true;
            this.ChkMLine.Location = new System.Drawing.Point(260, 23);
            this.ChkMLine.Name = "ChkMLine";
            this.ChkMLine.Size = new System.Drawing.Size(59, 20);
            this.ChkMLine.TabIndex = 6;
            this.ChkMLine.Text = "多行";
            this.ChkMLine.UseVisualStyleBackColor = true;
            this.ChkMLine.CheckedChanged += new System.EventHandler(this.ChkMLine_CheckedChanged);
            // 
            // GrpSclBar
            // 
            this.GrpSclBar.Controls.Add(this.RdbBoth);
            this.GrpSclBar.Controls.Add(this.RdbV);
            this.GrpSclBar.Controls.Add(this.RdbH);
            this.GrpSclBar.Controls.Add(this.RdbNone);
            this.GrpSclBar.Location = new System.Drawing.Point(244, 85);
            this.GrpSclBar.Margin = new System.Windows.Forms.Padding(4);
            this.GrpSclBar.Name = "GrpSclBar";
            this.GrpSclBar.Padding = new System.Windows.Forms.Padding(4);
            this.GrpSclBar.Size = new System.Drawing.Size(167, 111);
            this.GrpSclBar.TabIndex = 8;
            this.GrpSclBar.TabStop = false;
            this.GrpSclBar.Text = "捲軸";
            // 
            // RdbBoth
            // 
            this.RdbBoth.AutoSize = true;
            this.RdbBoth.Location = new System.Drawing.Point(95, 74);
            this.RdbBoth.Name = "RdbBoth";
            this.RdbBoth.Size = new System.Drawing.Size(58, 20);
            this.RdbBoth.TabIndex = 3;
            this.RdbBoth.Text = "兩者";
            this.RdbBoth.UseVisualStyleBackColor = true;
            this.RdbBoth.CheckedChanged += new System.EventHandler(this.RdbBoth_CheckedChanged);
            // 
            // RdbV
            // 
            this.RdbV.AutoSize = true;
            this.RdbV.Location = new System.Drawing.Point(16, 74);
            this.RdbV.Name = "RdbV";
            this.RdbV.Size = new System.Drawing.Size(58, 20);
            this.RdbV.TabIndex = 2;
            this.RdbV.Text = "垂直";
            this.RdbV.UseVisualStyleBackColor = true;
            this.RdbV.CheckedChanged += new System.EventHandler(this.RdbV_CheckedChanged);
            // 
            // RdbH
            // 
            this.RdbH.AutoSize = true;
            this.RdbH.Location = new System.Drawing.Point(95, 38);
            this.RdbH.Name = "RdbH";
            this.RdbH.Size = new System.Drawing.Size(58, 20);
            this.RdbH.TabIndex = 1;
            this.RdbH.Text = "水平";
            this.RdbH.UseVisualStyleBackColor = true;
            this.RdbH.CheckedChanged += new System.EventHandler(this.RdbH_CheckedChanged);
            // 
            // RdbNone
            // 
            this.RdbNone.AutoSize = true;
            this.RdbNone.Checked = true;
            this.RdbNone.Location = new System.Drawing.Point(16, 38);
            this.RdbNone.Name = "RdbNone";
            this.RdbNone.Size = new System.Drawing.Size(42, 20);
            this.RdbNone.TabIndex = 0;
            this.RdbNone.TabStop = true;
            this.RdbNone.Text = "無";
            this.RdbNone.UseVisualStyleBackColor = true;
            this.RdbNone.CheckedChanged += new System.EventHandler(this.RdbNone_CheckedChanged);
            // 
            // Txt2
            // 
            this.Txt2.Location = new System.Drawing.Point(452, 23);
            this.Txt2.Name = "Txt2";
            this.Txt2.Size = new System.Drawing.Size(182, 27);
            this.Txt2.TabIndex = 9;
            this.Txt2.Text = "精確來說Multiline是設定文字方塊高度是否可以變更，不論是設計或執行階段。一般寬度都可以改；但設定true高度才能改";
            // 
            // ChkTxtW
            // 
            this.ChkTxtW.AutoSize = true;
            this.ChkTxtW.Location = new System.Drawing.Point(339, 55);
            this.ChkTxtW.Name = "ChkTxtW";
            this.ChkTxtW.Size = new System.Drawing.Size(59, 20);
            this.ChkTxtW.TabIndex = 11;
            this.ChkTxtW.Text = "較寬";
            this.ChkTxtW.UseVisualStyleBackColor = true;
            this.ChkTxtW.CheckedChanged += new System.EventHandler(this.ChkTxtW_CheckedChanged);
            // 
            // ChkTxtH
            // 
            this.ChkTxtH.AutoSize = true;
            this.ChkTxtH.Location = new System.Drawing.Point(260, 55);
            this.ChkTxtH.Name = "ChkTxtH";
            this.ChkTxtH.Size = new System.Drawing.Size(59, 20);
            this.ChkTxtH.TabIndex = 10;
            this.ChkTxtH.Text = "較高";
            this.ChkTxtH.UseVisualStyleBackColor = true;
            this.ChkTxtH.CheckedChanged += new System.EventHandler(this.ChkTxtH_CheckedChanged);
            // 
            // Btn2Str
            // 
            this.Btn2Str.AutoSize = true;
            this.Btn2Str.Location = new System.Drawing.Point(22, 216);
            this.Btn2Str.Name = "Btn2Str";
            this.Btn2Str.Size = new System.Drawing.Size(75, 26);
            this.Btn2Str.TabIndex = 12;
            this.Btn2Str.Text = "數轉字";
            this.Btn2Str.UseVisualStyleBackColor = true;
            this.Btn2Str.Click += new System.EventHandler(this.Btn2Str_Click);
            // 
            // Btn2Num
            // 
            this.Btn2Num.AutoSize = true;
            this.Btn2Num.Location = new System.Drawing.Point(129, 216);
            this.Btn2Num.Name = "Btn2Num";
            this.Btn2Num.Size = new System.Drawing.Size(75, 26);
            this.Btn2Num.TabIndex = 13;
            this.Btn2Num.Text = "字轉數";
            this.Btn2Num.UseVisualStyleBackColor = true;
            this.Btn2Num.Click += new System.EventHandler(this.Btn2Num_Click);
            // 
            // BtnFocus
            // 
            this.BtnFocus.AutoSize = true;
            this.BtnFocus.Location = new System.Drawing.Point(343, 216);
            this.BtnFocus.Name = "BtnFocus";
            this.BtnFocus.Size = new System.Drawing.Size(54, 26);
            this.BtnFocus.TabIndex = 15;
            this.BtnFocus.Text = "聚焦";
            this.BtnFocus.UseVisualStyleBackColor = true;
            this.BtnFocus.Click += new System.EventHandler(this.BtnFocus_Click);
            // 
            // BtnClear
            // 
            this.BtnClear.AutoSize = true;
            this.BtnClear.Location = new System.Drawing.Point(252, 216);
            this.BtnClear.Name = "BtnClear";
            this.BtnClear.Size = new System.Drawing.Size(50, 26);
            this.BtnClear.TabIndex = 14;
            this.BtnClear.Text = "清空";
            this.BtnClear.UseVisualStyleBackColor = true;
            this.BtnClear.Click += new System.EventHandler(this.BtnClear_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(659, 274);
            this.Controls.Add(this.BtnFocus);
            this.Controls.Add(this.BtnClear);
            this.Controls.Add(this.Btn2Num);
            this.Controls.Add(this.Btn2Str);
            this.Controls.Add(this.ChkTxtW);
            this.Controls.Add(this.ChkTxtH);
            this.Controls.Add(this.Txt2);
            this.Controls.Add(this.GrpSclBar);
            this.Controls.Add(this.ChkWdWrap);
            this.Controls.Add(this.ChkMLine);
            this.Controls.Add(this.Txt1);
            this.Controls.Add(this.ChkReadOnly);
            this.Controls.Add(this.ChkPsw);
            this.Controls.Add(this.GrpMaxLen);
            this.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "文字方塊";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.GrpMaxLen.ResumeLayout(false);
            this.GrpMaxLen.PerformLayout();
            this.GrpSclBar.ResumeLayout(false);
            this.GrpSclBar.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox GrpMaxLen;
        private System.Windows.Forms.RadioButton Rdb15;
        private System.Windows.Forms.RadioButton Rdb10;
        private System.Windows.Forms.RadioButton Rdb5;
        private System.Windows.Forms.CheckBox ChkPsw;
        private System.Windows.Forms.CheckBox ChkReadOnly;
        private System.Windows.Forms.TextBox Txt1;
        private System.Windows.Forms.CheckBox ChkWdWrap;
        private System.Windows.Forms.CheckBox ChkMLine;
        private System.Windows.Forms.GroupBox GrpSclBar;
        private System.Windows.Forms.RadioButton RdbBoth;
        private System.Windows.Forms.RadioButton RdbV;
        private System.Windows.Forms.RadioButton RdbH;
        private System.Windows.Forms.RadioButton RdbNone;
        private System.Windows.Forms.TextBox Txt2;
        private System.Windows.Forms.CheckBox ChkTxtW;
        private System.Windows.Forms.CheckBox ChkTxtH;
        private System.Windows.Forms.Button Btn2Str;
        private System.Windows.Forms.Button Btn2Num;
        private System.Windows.Forms.Button BtnFocus;
        private System.Windows.Forms.Button BtnClear;
    }
}

