﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _3_3TextBox
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Rdb5_CheckedChanged(object sender, EventArgs e)
        {
            if (Rdb5.Checked) Txt1.MaxLength = 5;//設定文字方塊能填入的字元數
        }

        private void Rdb10_CheckedChanged(object sender, EventArgs e)
        {
            if (Rdb10.Checked) Txt1.MaxLength = 10;
        }

        private void Rdb15_CheckedChanged(object sender, EventArgs e)
        {
            if (Rdb15.Checked) Txt1.MaxLength = 15;
        }

        private void ChkPsw_CheckedChanged(object sender, EventArgs e)
        {
            if (ChkPsw.Checked) Txt1.PasswordChar = '$';//若有勾選，則顯示$，否則直接顯示
            else Txt1.PasswordChar = (char)0;//空字元的幾種寫法：(char)0, Convert.ToChar(0), '\0', char.MinValue
        }

        private void ChkReadOnly_CheckedChanged(object sender, EventArgs e)
        {
            Txt1.ReadOnly = ChkReadOnly.Checked;//文字方塊1是否唯讀，由核取方塊決定
        }

        private void Form1_Load(object sender, EventArgs e)
        {//設定文字方塊2的預設大小，以及預設的內容
            Txt2.Width = 180;
            Txt2.Height = 80;
            Txt2.Text = "***精確來說Multiline是設定文字方塊高度是否可以變更，不論是設計或執行階段。一般寬度都可以改；但設定true高度才能改";
            Txt2.Text += Environment.NewLine + "***若true則會自動換行，但不一定看得見，得視文字方塊高度而定(與Multiline有關)。若false不換行，能否看見則視寬度而定";
            Txt2.Text += Environment.NewLine + "***一定要Multiline為true才會顯示，也要視文字方塊的高度或寬度，決定垂直或水平捲軸是否有作用(有否拉桿)";
            Txt2.Text += Environment.NewLine + "***若true則會自動換行，但不一定看得見，得視文字方塊高度而定(與Multiline有關)。若false不換行，能否看見則視寬度而定";
            Txt2.Text += Environment.NewLine + "***一定要Multiline為true才會顯示，也要視文字方塊的高度或寬度，決定垂直或水平捲軸是否有作用(有否拉桿)";
        }

        private void ChkMLine_CheckedChanged(object sender, EventArgs e)
        {
            Txt2.Multiline = ChkMLine.Checked;//文字方塊2是否多行，由核取方塊決定
        }

        private void ChkWdWrap_CheckedChanged(object sender, EventArgs e)
        {
            Txt2.WordWrap = ChkWdWrap.Checked;//文字方塊2是否能換行，由核取方塊決定
        }

         private void ChkTxtH_CheckedChanged(object sender, EventArgs e)
        {
            if (ChkTxtH.Checked) Txt2.Height = 170;//有勾選較高，則調高度到170
            else Txt2.Height = 80;//未勾選較高，則高度為原來的80
        }

        private void ChkTxtW_CheckedChanged(object sender, EventArgs e)
        {
            if (ChkTxtW.Checked)//有勾選較寬，則調寬度到250，表單寬度也加60，以免遮到文字方塊
            {
                Txt2.Width = 250;
                Width += 60;
            }
            else//未勾選較寬，則寬度調回原來180，表單寬度也減60，恢復原來
            {
                Txt2.Width = 180;
                Width -= 60;
            }
        }

       private void RdbNone_CheckedChanged(object sender, EventArgs e)
        {
            if (RdbNone.Checked) Txt2.ScrollBars = ScrollBars.None;//用選項按鈕設定文字方塊2無捲軸
        }

        private void RdbH_CheckedChanged(object sender, EventArgs e)
        {
            if (RdbH.Checked) Txt2.ScrollBars = ScrollBars.Horizontal;//用選項按鈕設定文字方塊2有水平捲軸
        }

        private void RdbV_CheckedChanged(object sender, EventArgs e)
        {
            if (RdbV.Checked) Txt2.ScrollBars = ScrollBars.Vertical;//用選項按鈕設定文字方塊2有垂直捲軸
        }

        private void RdbBoth_CheckedChanged(object sender, EventArgs e)
        {
            if (RdbBoth.Checked) Txt2.ScrollBars = ScrollBars.Both;
        }

        private void Btn2Str_Click(object sender, EventArgs e)
        {//演練示範數值轉字串
            Txt1.Text = Convert.ToString(12345);
            MessageBox.Show("這是用Convert.ToString(12345)將數值轉為字串");
            Txt1.Text = 67890.ToString();
            MessageBox.Show("這是用67890.ToString()將數值轉為字串");
            Txt1.Text = (1357.462).ToString("G");
            MessageBox.Show("這是用(1357.462).ToString(\"G\")將數值轉為一般字串");
            Txt1.Text = 890.ToString("D5");
            MessageBox.Show("這是用890.ToString(\"D5\")將數值轉為5位數字串");
            Txt1.Text = 890.ToString("D2");
            MessageBox.Show("這是用890.ToString(\"D2\")將數值轉為2位數字串，但原就有3位，所以仍會保留3位，不會刪減");
            try { Txt1.Text = (1357.462).ToString("D5"); }
            catch(Exception ex) { MessageBox.Show("(1357.462).ToString(\"D5\")發生例外：" + ex.Message); }
            Txt1.Text = (1357.462).ToString("C1");
            MessageBox.Show("這是用(1357.462).ToString(\"C1\")將數值轉為小數1位的貨幣表示的字串");
            Txt1.Text = (1357.462).ToString("F4");
            MessageBox.Show("這是用(1357.462).ToString(\"F4\")將數值轉為小數4位浮點表示的字串");
            Txt1.Text = (1357.462).ToString("N");
            MessageBox.Show("這是用(1357.462).ToString(\"N\")將數值轉為千號表示(小數自動2位)的字串");
            Txt1.Text = (1357.4).ToString("N");
            MessageBox.Show("這是用(1357.462).ToString(\"N\")將數值轉為千號表示(小數自動2位，不足為補0)的字串");
        }

        private void Btn2Num_Click(object sender, EventArgs e)
        {//演練示範字串轉數值
            MessageBox.Show("字串\"40000\"用ToInt64轉成" + Convert.ToInt64("40000"));
            MessageBox.Show("字串\"40000\"用ToInt32轉成" + Convert.ToInt32("40000"));
            MessageBox.Show("字串\"40000\"用ToUInt16轉成" + Convert.ToUInt16("40000"));
            try { short tst = Convert.ToInt16("40000"); }//四萬的值超出了16位元整數即有號的short之範圍
            catch (Exception ex) { MessageBox.Show("字串40000用ToInt16轉換產生例外：" + ex.Message); }

            //Convert.ToBoolean()字串只能轉true及false，字母不分大小寫。數值皆可，0轉為False，其他(即使超過布林1個bytes)轉為True
            MessageBox.Show("字串\"TrUe\"用ToBoolean轉成" + Convert.ToBoolean("TrUe"));
            MessageBox.Show("數值1用ToBoolean轉成" + Convert.ToBoolean(1));
            MessageBox.Show("數值256用ToBoolean轉成" + Convert.ToBoolean(256));
            MessageBox.Show("數值12.35用ToBoolean轉成" + Convert.ToBoolean(12.34));
            MessageBox.Show("字串\"FaLSe\"用ToBoolean轉成" + Convert.ToBoolean("FaLSe"));
            MessageBox.Show("數值0用ToBoolean轉成" + Convert.ToBoolean(0));
            try { bool tst = Convert.ToBoolean("0"); }//數值0可以轉布林，但字串0不行
            catch (Exception ex) { MessageBox.Show("字串\"0\"用ToBoolean轉換產生例外：" + ex.Message); }

            try { bool tst = Convert.ToBoolean("1"); }//數值1可以轉布林，但字串1不行
            catch (Exception ex) { MessageBox.Show("字串\"1\"用ToBoolean轉換產生例外：" + ex.Message); }

            try { bool tst = Convert.ToBoolean("T"); }//字串除了true跟false不分大小寫外，其餘皆不行
            catch (Exception ex) { MessageBox.Show("字串\"T\"用ToBoolean轉換產生例外：" + ex.Message); }
        }

        private void BtnClear_Click(object sender, EventArgs e)
        {//文字方塊清空，等同於設定屬性為""
            string Txt2Txt = Txt2.Text;
            Txt2.Clear();
            MessageBox.Show("文字方塊2清空");
            Txt2.Text = Txt2Txt;
            MessageBox.Show("復原");
        }

        bool Txt1Focus = true;
        private void BtnFocus_Click(object sender, EventArgs e)
        {//採文字方塊1跟2兩者之間輪流聚焦，所以設定一個布林變數Txt1Focus來切換
            if (Txt1Focus)
            {
                Txt1.Focus();
                Txt1Focus = !Txt1Focus;
            }
            else
            {
                Txt2.Focus();
                Txt1Focus = !Txt1Focus;
            }
        }
    }
}
