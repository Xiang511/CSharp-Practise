﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace F2C
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            TxtF.MaxLength = 3;//輸入最長限制
            TxtF.TabIndex=0;//輸入取得焦點，用Focus()也可以
            TxtC.ReadOnly = true;//輸出設定唯讀
        }

        private void BtnF2C_Click(object sender, EventArgs e)
        {
            try//只有第一敘述可能會出問題，但2,3敘述會影響輸出之清空，所以不可以擺catch後面
            {   int f = Convert.ToInt16(TxtF.Text);//輸入轉換成整數數值
                float c = (float)(f - 32) * 5 / 9;//轉換公式，注意整數與浮點數轉換
                TxtC.Text = c.ToString("f2")+"度";//攝氏轉成字串顯示在輸出
            }
            catch//輸入有誤則顯示提示，並清空輸入的文字方塊
            {   TxtC.Text = "請輸入整數";
                TxtF.Clear();
            }
            TxtF.Focus();//輸入取得焦點
        }

        private void TxtF_TextChanged(object sender, EventArgs e)
        {
            try//只有第一敘述可能會出問題，但2,3敘述會影響輸出之清空，所以不可以擺catch後面
            {
                int f = Convert.ToInt16(TxtF.Text);//輸入轉換成整數數值
                float c = (float)(f - 32) * 5 / 9;//轉換公式，注意整數與浮點數轉換
                TxtC.Text = c.ToString("f2") + "度";//攝氏轉成字串顯示在輸出
            }
            catch//輸入有誤則顯示提示，並清空輸入的文字方塊
            {
                TxtC.Text = "請輸入整數";
                TxtF.Clear();
            }
            TxtF.Focus();//輸入取得焦點
        }

        private void TxtF_Enter(object sender, EventArgs e)
        {
            TxtF.Text = "100";
        }
    }
}
