﻿namespace F2C
{
    partial class Form1
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.LblF = new System.Windows.Forms.Label();
            this.LblC = new System.Windows.Forms.Label();
            this.TxtF = new System.Windows.Forms.TextBox();
            this.TxtC = new System.Windows.Forms.TextBox();
            this.BtnF2C = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // LblF
            // 
            this.LblF.AutoSize = true;
            this.LblF.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.LblF.Location = new System.Drawing.Point(27, 26);
            this.LblF.Name = "LblF";
            this.LblF.Size = new System.Drawing.Size(208, 16);
            this.LblF.TabIndex = 0;
            this.LblF.Text = "請輸入華氏溫度整數最多3位";
            // 
            // LblC
            // 
            this.LblC.AutoSize = true;
            this.LblC.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.LblC.Location = new System.Drawing.Point(157, 65);
            this.LblC.Name = "LblC";
            this.LblC.Size = new System.Drawing.Size(72, 16);
            this.LblC.TabIndex = 1;
            this.LblC.Text = "攝氏溫度";
            // 
            // TxtF
            // 
            this.TxtF.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.TxtF.Location = new System.Drawing.Point(235, 15);
            this.TxtF.Name = "TxtF";
            this.TxtF.Size = new System.Drawing.Size(100, 27);
            this.TxtF.TabIndex = 2;
            this.TxtF.TextChanged += new System.EventHandler(this.TxtF_TextChanged);
            this.TxtF.Enter += new System.EventHandler(this.TxtF_Enter);
            // 
            // TxtC
            // 
            this.TxtC.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.TxtC.Location = new System.Drawing.Point(235, 57);
            this.TxtC.Name = "TxtC";
            this.TxtC.Size = new System.Drawing.Size(100, 27);
            this.TxtC.TabIndex = 3;
            // 
            // BtnF2C
            // 
            this.BtnF2C.AutoSize = true;
            this.BtnF2C.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.BtnF2C.Location = new System.Drawing.Point(30, 57);
            this.BtnF2C.Name = "BtnF2C";
            this.BtnF2C.Size = new System.Drawing.Size(98, 32);
            this.BtnF2C.TabIndex = 4;
            this.BtnF2C.Text = "轉換成攝氏";
            this.BtnF2C.UseVisualStyleBackColor = true;
            this.BtnF2C.Click += new System.EventHandler(this.BtnF2C_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(378, 115);
            this.Controls.Add(this.BtnF2C);
            this.Controls.Add(this.TxtC);
            this.Controls.Add(this.TxtF);
            this.Controls.Add(this.LblC);
            this.Controls.Add(this.LblF);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label LblF;
        private System.Windows.Forms.Label LblC;
        private System.Windows.Forms.TextBox TxtF;
        private System.Windows.Forms.TextBox TxtC;
        private System.Windows.Forms.Button BtnF2C;
    }
}

