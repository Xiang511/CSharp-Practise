﻿namespace _3_4IMBox
{
    partial class Form1
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.BtnInBox = new System.Windows.Forms.Button();
            this.BtnMsgBox = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // BtnInBox
            // 
            this.BtnInBox.AutoSize = true;
            this.BtnInBox.Location = new System.Drawing.Point(31, 28);
            this.BtnInBox.Name = "BtnInBox";
            this.BtnInBox.Size = new System.Drawing.Size(82, 26);
            this.BtnInBox.TabIndex = 0;
            this.BtnInBox.Text = "輸入方塊";
            this.BtnInBox.UseVisualStyleBackColor = true;
            this.BtnInBox.Click += new System.EventHandler(this.BtnInBox_Click);
            // 
            // BtnMsgBox
            // 
            this.BtnMsgBox.AutoSize = true;
            this.BtnMsgBox.Location = new System.Drawing.Point(143, 28);
            this.BtnMsgBox.Name = "BtnMsgBox";
            this.BtnMsgBox.Size = new System.Drawing.Size(82, 26);
            this.BtnMsgBox.TabIndex = 1;
            this.BtnMsgBox.Text = "訊息方塊";
            this.BtnMsgBox.UseVisualStyleBackColor = true;
            this.BtnMsgBox.Click += new System.EventHandler(this.BtnMsgBox_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(278, 87);
            this.Controls.Add(this.BtnMsgBox);
            this.Controls.Add(this.BtnInBox);
            this.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button BtnInBox;
        private System.Windows.Forms.Button BtnMsgBox;
    }
}

