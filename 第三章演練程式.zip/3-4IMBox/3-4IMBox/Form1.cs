﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _3_4IMBox
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
        }

        private void BtnInBox_Click(object sender, EventArgs e)
        {//要先到 專案 >> 加入參考 >> 組件 >> Microsoft.VisualBasic 進行核取
            string InScore = Microsoft.VisualBasic.Interaction.InputBox("請輸入分數", "分數", "100", 500, 300);//參數：(提示訊息, 標籤, 預設值, 座標X, 座標Y)
            int Score;
            try//例外處理，通常用在輸入字串(輸入方塊或文字方塊)轉成數值
            {//try內寫可能會異常的敘述。其他敘述亦可以寫在這裡，或寫在try...catch外面，要注意邏輯及返回表單
                Score = Convert.ToInt32(InScore);
            }
            catch (Exception ex)
            {//警訊、回到表單要做的事。若非程式最後，需使用return;回到表單
                MessageBox.Show("發生例外：" + ex.Message);//警訊
                return;//此例只有返回表單，未有做任何事。一般常會做的事是輸入的文字方塊清空並聚焦
            }

            if (Score >= 0 && Score <= 100)//即使轉換未有例外，仍未再加上範圍判斷，若正確才執行該有的敘述。否則同例外警訊及回表單要做的事，此例無
            {
                MessageBox.Show("輸入成績：" + Score.ToString(), "成績", MessageBoxButtons.OK, MessageBoxIcon.Information);//訊息方塊見下例
            }
        }

        private void BtnMsgBox_Click(object sender, EventArgs e)
        {//語法[DialogResult ReturnResult=] MessageBox.Show([物件,] 訊息, 標題, 按鈕, 圖示, 預設按鈕, 選項);//最少要有訊息，其他可空白或略
            MessageBox.Show("按鈕：中止、重試、略過；圖示：X；預設：第1個；選項：無", "訊息方塊", MessageBoxButtons.AbortRetryIgnore, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1);
            MessageBox.Show("按鈕：確定；圖示：i；預設：第1個；選項：顯示在預設桌面", "訊息方塊", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1, MessageBoxOptions.DefaultDesktopOnly);
            MessageBox.Show("按鈕：確定、取消；圖示：?；預設：第2個；選項：內容由右向左讀取", "訊息方塊", MessageBoxButtons.OKCancel, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2, MessageBoxOptions.RtlReading);
            MessageBox.Show("按鈕：確定、取消；圖示：?；預設：第2個；選項：無", "訊息方塊", MessageBoxButtons.OKCancel, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2);
            MessageBox.Show("按鈕：重試、取消；圖示：!；預設：第1個；選項：標題文字靠右對齊", "訊息方塊", MessageBoxButtons.RetryCancel, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button1, MessageBoxOptions.RightAlign);
            MessageBox.Show("按鈕：重試、取消；圖示：!；預設：第1個；選項：無", "訊息方塊", MessageBoxButtons.RetryCancel, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button1);
            MessageBox.Show("按鈕：是、否；圖示：?；預設：第2個；選項：顯示在使用中桌面", "訊息方塊", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2, MessageBoxOptions.ServiceNotification);
            MessageBox.Show("按鈕：是、否、取消；圖示：?；預設：第3個；選項：內容由右向左讀取", "訊息方塊", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question, MessageBoxDefaultButton.Button3, MessageBoxOptions.RtlReading);
            MessageBox.Show("按鈕：是、否、取消；圖示：?；預設：第3個；選項：無", "訊息方塊", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question, MessageBoxDefaultButton.Button3);

            for (int i = 0; i < 3; i++)//分別試按鈕回傳值及處理
            {
                DialogResult RR = MessageBox.Show("分別點按鈕是、否、取消試回傳值", "訊息方塊", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question, MessageBoxDefaultButton.Button3);
                if (RR == DialogResult.Yes) MessageBox.Show("你按的按鈕是「是」");
                else if (RR == DialogResult.No) MessageBox.Show("你按的按鈕是「否」");
                else if (RR == DialogResult.Cancel) MessageBox.Show("你按的按鈕是「取消」");
                else MessageBox.Show("不應該出現這種情形");
            }

        }
    }
}
