﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _3_1Form
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        bool CursorFlag=true;//設定游標圖示時因使用切換方式，所以設此旗標，true則秀手指圖，false則秀預設圖

        private void BtnBColor_Click(object sender, EventArgs e)
        {//設定物件屬性一般需要前面加上物件名稱及「.」點，但表單不用，或使用this，使用名稱(Form1)反而不行
            BackColor = Color.Yellow;
            MessageBox.Show("設背景為黃色");
            BackColor = SystemColors.Control;//恢復預設值
        }

        private void BtnCursor_Click(object sender, EventArgs e)
        {//設定指標圖示，採切換手指圖跟預設圖，使用一個布林旗標變數CursorFlag及CursorFlag = !CursorFlag;
            if (CursorFlag)
            {
                Cursor = Cursors.Hand;
                MessageBox.Show("設定指標為手指圖");
                CursorFlag = !CursorFlag;//這樣就可以在true及false之間切換，也使得結果在手指圖及預設圖間切換
            }
            else
            {
                Cursor = Cursors.Default;//恢復預設值
                MessageBox.Show("還原成預設指標");
                CursorFlag = !CursorFlag;
            }
        }

        private void BtnBGImage_Click(object sender, EventArgs e)
        {//這裡用點「.」表示現在目錄，所以要跟exe檔在相同目標，若未異動是在專案資料夾下bin\Debug內
            BackgroundImage = Image.FromFile(".\\ISU.jpg");//反斜線\是特殊符號(跳脫字元)，所以路徑中的反斜線也「跳脫」
            MessageBox.Show("這是用Image.FromFile()");
            BackgroundImage = new Bitmap(".\\EE.jpg");
            MessageBox.Show("這是用new Bitmap()");
            BackgroundImage = null;//設定成沒有背景圖，即預設
        }

        private void BtnFont_Click(object sender, EventArgs e)
        {//設定字型
            Font = new Font("標楷體", 12, FontStyle.Bold);
            MessageBox.Show("設定成標楷體12點粗體");
            Font = new Font("新細明體", 12);
            MessageBox.Show("恢復預設值");
        }

        private void BtnBorder_Click(object sender, EventArgs e)
        {//設定表單邊界
            FormBorderStyle = FormBorderStyle.None;
            MessageBox.Show("沒有框線");
            FormBorderStyle = FormBorderStyle.FixedSingle;
            MessageBox.Show("單線固定");
            FormBorderStyle = FormBorderStyle.Fixed3D;
            MessageBox.Show("立體固定");
            FormBorderStyle = FormBorderStyle.FixedDialog;
            MessageBox.Show("雙線固定對話方塊");
            FormBorderStyle = FormBorderStyle.FixedToolWindow;
            MessageBox.Show("單線固定工具視窗");
            FormBorderStyle = FormBorderStyle.SizableToolWindow;
            MessageBox.Show("可調整工具視窗");
            FormBorderStyle = FormBorderStyle.Sizable;
            MessageBox.Show("大小可調整(預設)");
        }

        private void BtnBorder2_Click(object sender, EventArgs e)
        {//設定表單邊界為所謂固定雙線，主要方便比較邊界差異
            FormBorderStyle = FormBorderStyle.FixedDialog;
        }

        private void BtnBorder3_Click(object sender, EventArgs e)
        {//設定表單邊界為所謂固定立體，主要方便比較邊界差異
            FormBorderStyle = FormBorderStyle.Fixed3D;
        }

        private void BtnText_Click(object sender, EventArgs e)
        {//設定表單標題
            Text = "只是試試";
        }

        private void Button1_Click(object sender, EventArgs e)
        {
        }

        private void BtnCtrlBox_Click(object sender, EventArgs e)
        {//設定控制盒顯現與否，使用on-off的做法，按一下隱藏，再按一下顯現
            ControlBox = !ControlBox;//最小化、最大化及關閉鈕三者合稱控制盒
        }

         private void BtnMax_Click(object sender, EventArgs e)
        {//設定最大化鈕顯現與否，使用on-off的做法，按一下隱藏，再按一下顯現
            MaximizeBox = !MaximizeBox;//最大化及最小化鈕若只設定一個不顯示，它仍會顯示，只是變淡，無法作動
        }

        private void BtnMin_Click(object sender, EventArgs e)
        {//設定最小化鈕顯現與否，使用on-off的做法，按一下隱藏，再按一下顯現
            MinimizeBox = !MinimizeBox;//最大化及最小化鈕若只設定一個不顯示，它仍會顯示，只是變淡，無法作動
        }

        private void BtnHelp_Click(object sender, EventArgs e)
        {//設定說明鈕顯現與否，使用on-off的做法，按一下隱藏，再按一下顯現
            HelpButton = !HelpButton;//說明鈕需最大及最小鈕皆消失才會出現
        }

        private void BtnMinIcon_Click(object sender, EventArgs e)
        {//設家最小化時是否顯示圖示在工具列，使用on-off的做法，按一下不顯示，再按一下會顯示
            ShowInTaskbar = !ShowInTaskbar;
        }

       private void BtnTop_Click(object sender, EventArgs e)
        {//設定表單在最上層與否，使用on-off的做法，按一下隱藏，再按一下顯現
            TopMost = !TopMost;
        }

        private void BtnLcnSize_Click(object sender, EventArgs e)
        {//設定表單位置
            int FormH, FormW, FormX, FormY;//設定4個變數，先將表單的高、寬及XY座標存起來，以便復原時使用
            FormH = Height;//也可以用Size.Height
            FormW = Width;//也可以用Size.Width
            FormX = Location.X;
            FormY = Location.Y;

            Size = new Size(100,150);//設定Size的語法要用new，因為Size不是一個值，是個類別(結構)要用建構子
            MessageBox.Show("改變大小為(100,150)");
            Height = FormH;//用Size.Height語法會錯
            Width = FormW;//用Size.Width語法會錯
            MessageBox.Show("還原");
            Location = new Point(500, 600);//設定Location的語法是設定到某個Point，要用new，因為Point不是一個值，是個類別(結構)要用建構子
            MessageBox.Show("改變位置原點(500, 600)");
            Left = FormX;//取得原點X座標用Location.X，但設定用Left
            Top = FormY;//取得原點Y座標用Location.Y，但設定用Top
            MessageBox.Show("還原");
        }

        private void BtnStarPos_Click(object sender, EventArgs e)
        {//視窗啟動位置設定
            Form Form2 = new Form();//建一個新表單
            int Form2Width = Form2.Width; int Form2Height = Form2.Height;//將新表單的寬高先存起來，以便復原時使用
            Form2.Location = new Point(800, 800);//設定新表單原點位置，以便啟動位置使用手動時使用
            Form2.StartPosition = FormStartPosition.Manual;//設定成手動，表單原點為目前設定的位置。其實此指令不用，只要設定Location即可
            Form2.Text = "手動設定在(800, 800)";
            Form2.ShowDialog();//顯示表單(，表單本就是一種對話方塊)
            Form2.Location = new Point(600, 600);//設定新表單原點位置，不用使用Form2.StartPosition = FormStartPosition.Manual;亦可
            Form2.Text = "手動設定在(600, 600)";
            Form2.ShowDialog();//顯示表單(，表單本就是一種對話方塊)
            Form2.StartPosition = FormStartPosition.CenterScreen;
            Form2.Text = "設定在螢幕中間";
            Form2.ShowDialog();
            Form2.StartPosition = FormStartPosition.WindowsDefaultLocation;
            Form2.Text = "設定在預設位置";
            Form2.ShowDialog();
            Form2.StartPosition = FormStartPosition.WindowsDefaultBounds;
            Form2.Text = "設定在預設邊界(螢幕中央調整大小)";
            Form2.ShowDialog();
            Form2.StartPosition = FormStartPosition.CenterParent;
            Form2.Text = "設定在父視窗中央(用上次的大小)";
            Form2.ShowDialog();
            Form2.Width = Form2Width; Form2.Height = Form2Height;//將表單2的寬高設定成已儲存的原寬高，以便恢復原大小
            Form2.StartPosition = FormStartPosition.CenterParent;
            Form2.Text = "設定在父視窗中央(用最初存起來的大小)";
            Form2.ShowDialog();
        }

        private void BtnWinState_Click(object sender, EventArgs e)
        {//視窗狀態設定
            WindowState = FormWindowState.Maximized;
            MessageBox.Show("最大化");
            WindowState = FormWindowState.Normal;
            MessageBox.Show("原設計大小");
            MessageBox.Show("最小化(下一步)");
            WindowState = FormWindowState.Minimized;
        }

        private void BtnMsClick_Click(object sender, EventArgs e)
        {
            MessageBox.Show("這是Click");
        }

        private void BtnMsClick_MouseClick(object sender, MouseEventArgs e)
        {
            MessageBox.Show("這是MouseClick，滑鼠位置在"+e.Location);

        }

        private void Form1_MouseClick(object sender, MouseEventArgs e)
        {
            MessageBox.Show("這是MouseClick，滑鼠位置在" + e.Location);
        }
    }
}
