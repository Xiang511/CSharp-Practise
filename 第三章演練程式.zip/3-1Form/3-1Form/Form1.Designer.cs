﻿namespace _3_1Form
{
    partial class Form1
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.BtnBColor = new System.Windows.Forms.Button();
            this.BtnBGImage = new System.Windows.Forms.Button();
            this.BtnCursor = new System.Windows.Forms.Button();
            this.BtnFont = new System.Windows.Forms.Button();
            this.BtnBorder = new System.Windows.Forms.Button();
            this.BtnBorder2 = new System.Windows.Forms.Button();
            this.BtnBorder3 = new System.Windows.Forms.Button();
            this.BtnText = new System.Windows.Forms.Button();
            this.BtnCtrlBox = new System.Windows.Forms.Button();
            this.BtnMinIcon = new System.Windows.Forms.Button();
            this.BtnTop = new System.Windows.Forms.Button();
            this.BtnMax = new System.Windows.Forms.Button();
            this.BtnMin = new System.Windows.Forms.Button();
            this.BtnHelp = new System.Windows.Forms.Button();
            this.BtnLcnSize = new System.Windows.Forms.Button();
            this.BtnStarPos = new System.Windows.Forms.Button();
            this.BtnWinState = new System.Windows.Forms.Button();
            this.BtnMsClick = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // BtnBColor
            // 
            this.BtnBColor.AutoSize = true;
            this.BtnBColor.Location = new System.Drawing.Point(45, 33);
            this.BtnBColor.Name = "BtnBColor";
            this.BtnBColor.Size = new System.Drawing.Size(82, 26);
            this.BtnBColor.TabIndex = 0;
            this.BtnBColor.Text = "背景黃色";
            this.BtnBColor.UseVisualStyleBackColor = true;
            this.BtnBColor.Click += new System.EventHandler(this.BtnBColor_Click);
            // 
            // BtnBGImage
            // 
            this.BtnBGImage.AutoSize = true;
            this.BtnBGImage.Location = new System.Drawing.Point(45, 89);
            this.BtnBGImage.Name = "BtnBGImage";
            this.BtnBGImage.Size = new System.Drawing.Size(130, 26);
            this.BtnBGImage.TabIndex = 1;
            this.BtnBGImage.Text = "載入背景圖二法";
            this.BtnBGImage.UseVisualStyleBackColor = true;
            this.BtnBGImage.Click += new System.EventHandler(this.BtnBGImage_Click);
            // 
            // BtnCursor
            // 
            this.BtnCursor.AllowDrop = true;
            this.BtnCursor.AutoSize = true;
            this.BtnCursor.Location = new System.Drawing.Point(45, 145);
            this.BtnCursor.Name = "BtnCursor";
            this.BtnCursor.Size = new System.Drawing.Size(82, 26);
            this.BtnCursor.TabIndex = 2;
            this.BtnCursor.Text = "改變游標";
            this.BtnCursor.UseVisualStyleBackColor = true;
            this.BtnCursor.Click += new System.EventHandler(this.BtnCursor_Click);
            // 
            // BtnFont
            // 
            this.BtnFont.AllowDrop = true;
            this.BtnFont.AutoSize = true;
            this.BtnFont.Location = new System.Drawing.Point(45, 207);
            this.BtnFont.Name = "BtnFont";
            this.BtnFont.Size = new System.Drawing.Size(82, 26);
            this.BtnFont.TabIndex = 3;
            this.BtnFont.Text = "設定字型";
            this.BtnFont.UseVisualStyleBackColor = true;
            this.BtnFont.Click += new System.EventHandler(this.BtnFont_Click);
            // 
            // BtnBorder
            // 
            this.BtnBorder.AllowDrop = true;
            this.BtnBorder.AutoSize = true;
            this.BtnBorder.Location = new System.Drawing.Point(45, 272);
            this.BtnBorder.Name = "BtnBorder";
            this.BtnBorder.Size = new System.Drawing.Size(82, 26);
            this.BtnBorder.TabIndex = 4;
            this.BtnBorder.Text = "設定邊界";
            this.BtnBorder.UseVisualStyleBackColor = true;
            this.BtnBorder.Click += new System.EventHandler(this.BtnBorder_Click);
            // 
            // BtnBorder2
            // 
            this.BtnBorder2.AllowDrop = true;
            this.BtnBorder2.AutoSize = true;
            this.BtnBorder2.Location = new System.Drawing.Point(251, 33);
            this.BtnBorder2.Name = "BtnBorder2";
            this.BtnBorder2.Size = new System.Drawing.Size(114, 26);
            this.BtnBorder2.TabIndex = 5;
            this.BtnBorder2.Text = "設定邊界雙線";
            this.BtnBorder2.UseVisualStyleBackColor = true;
            this.BtnBorder2.Click += new System.EventHandler(this.BtnBorder2_Click);
            // 
            // BtnBorder3
            // 
            this.BtnBorder3.AllowDrop = true;
            this.BtnBorder3.AutoSize = true;
            this.BtnBorder3.Location = new System.Drawing.Point(251, 89);
            this.BtnBorder3.Name = "BtnBorder3";
            this.BtnBorder3.Size = new System.Drawing.Size(114, 26);
            this.BtnBorder3.TabIndex = 6;
            this.BtnBorder3.Text = "設定邊界立體";
            this.BtnBorder3.UseVisualStyleBackColor = true;
            this.BtnBorder3.Click += new System.EventHandler(this.BtnBorder3_Click);
            // 
            // BtnText
            // 
            this.BtnText.AllowDrop = true;
            this.BtnText.AutoSize = true;
            this.BtnText.Location = new System.Drawing.Point(251, 145);
            this.BtnText.Name = "BtnText";
            this.BtnText.Size = new System.Drawing.Size(82, 26);
            this.BtnText.TabIndex = 7;
            this.BtnText.Text = "設定標題";
            this.BtnText.UseVisualStyleBackColor = true;
            this.BtnText.Click += new System.EventHandler(this.BtnText_Click);
            // 
            // BtnCtrlBox
            // 
            this.BtnCtrlBox.AllowDrop = true;
            this.BtnCtrlBox.AutoSize = true;
            this.BtnCtrlBox.Location = new System.Drawing.Point(251, 207);
            this.BtnCtrlBox.Name = "BtnCtrlBox";
            this.BtnCtrlBox.Size = new System.Drawing.Size(66, 26);
            this.BtnCtrlBox.TabIndex = 8;
            this.BtnCtrlBox.Text = "控制盒";
            this.BtnCtrlBox.UseVisualStyleBackColor = true;
            this.BtnCtrlBox.Click += new System.EventHandler(this.BtnCtrlBox_Click);
            // 
            // BtnMinIcon
            // 
            this.BtnMinIcon.AllowDrop = true;
            this.BtnMinIcon.AutoSize = true;
            this.BtnMinIcon.Location = new System.Drawing.Point(463, 145);
            this.BtnMinIcon.Name = "BtnMinIcon";
            this.BtnMinIcon.Size = new System.Drawing.Size(98, 26);
            this.BtnMinIcon.TabIndex = 12;
            this.BtnMinIcon.Text = "最小化圖示";
            this.BtnMinIcon.UseVisualStyleBackColor = true;
            this.BtnMinIcon.Click += new System.EventHandler(this.BtnMinIcon_Click);
            // 
            // BtnTop
            // 
            this.BtnTop.AllowDrop = true;
            this.BtnTop.AutoSize = true;
            this.BtnTop.Location = new System.Drawing.Point(463, 207);
            this.BtnTop.Name = "BtnTop";
            this.BtnTop.Size = new System.Drawing.Size(98, 26);
            this.BtnTop.TabIndex = 13;
            this.BtnTop.Text = "永遠最上層";
            this.BtnTop.UseVisualStyleBackColor = true;
            this.BtnTop.Click += new System.EventHandler(this.BtnTop_Click);
            // 
            // BtnMax
            // 
            this.BtnMax.AllowDrop = true;
            this.BtnMax.AutoSize = true;
            this.BtnMax.Location = new System.Drawing.Point(251, 269);
            this.BtnMax.Name = "BtnMax";
            this.BtnMax.Size = new System.Drawing.Size(82, 26);
            this.BtnMax.TabIndex = 9;
            this.BtnMax.Text = "最大化鈕";
            this.BtnMax.UseVisualStyleBackColor = true;
            this.BtnMax.Click += new System.EventHandler(this.BtnMax_Click);
            // 
            // BtnMin
            // 
            this.BtnMin.AllowDrop = true;
            this.BtnMin.AutoSize = true;
            this.BtnMin.Location = new System.Drawing.Point(463, 33);
            this.BtnMin.Name = "BtnMin";
            this.BtnMin.Size = new System.Drawing.Size(82, 26);
            this.BtnMin.TabIndex = 10;
            this.BtnMin.Text = "最小化鈕";
            this.BtnMin.UseVisualStyleBackColor = true;
            this.BtnMin.Click += new System.EventHandler(this.BtnMin_Click);
            // 
            // BtnHelp
            // 
            this.BtnHelp.AllowDrop = true;
            this.BtnHelp.AutoSize = true;
            this.BtnHelp.Location = new System.Drawing.Point(463, 89);
            this.BtnHelp.Name = "BtnHelp";
            this.BtnHelp.Size = new System.Drawing.Size(66, 26);
            this.BtnHelp.TabIndex = 11;
            this.BtnHelp.Text = "說明鈕";
            this.BtnHelp.UseVisualStyleBackColor = true;
            this.BtnHelp.Click += new System.EventHandler(this.BtnHelp_Click);
            // 
            // BtnLcnSize
            // 
            this.BtnLcnSize.AllowDrop = true;
            this.BtnLcnSize.AutoSize = true;
            this.BtnLcnSize.Location = new System.Drawing.Point(463, 269);
            this.BtnLcnSize.Name = "BtnLcnSize";
            this.BtnLcnSize.Size = new System.Drawing.Size(82, 26);
            this.BtnLcnSize.TabIndex = 14;
            this.BtnLcnSize.Text = "位置大小";
            this.BtnLcnSize.UseVisualStyleBackColor = true;
            this.BtnLcnSize.Click += new System.EventHandler(this.BtnLcnSize_Click);
            // 
            // BtnStarPos
            // 
            this.BtnStarPos.AllowDrop = true;
            this.BtnStarPos.AutoSize = true;
            this.BtnStarPos.Location = new System.Drawing.Point(628, 33);
            this.BtnStarPos.Name = "BtnStarPos";
            this.BtnStarPos.Size = new System.Drawing.Size(82, 26);
            this.BtnStarPos.TabIndex = 15;
            this.BtnStarPos.Text = "啟動位置";
            this.BtnStarPos.UseVisualStyleBackColor = true;
            this.BtnStarPos.Click += new System.EventHandler(this.BtnStarPos_Click);
            // 
            // BtnWinState
            // 
            this.BtnWinState.AllowDrop = true;
            this.BtnWinState.AutoSize = true;
            this.BtnWinState.Location = new System.Drawing.Point(628, 89);
            this.BtnWinState.Name = "BtnWinState";
            this.BtnWinState.Size = new System.Drawing.Size(82, 26);
            this.BtnWinState.TabIndex = 16;
            this.BtnWinState.Text = "視窗狀態";
            this.BtnWinState.UseVisualStyleBackColor = true;
            this.BtnWinState.Click += new System.EventHandler(this.BtnWinState_Click);
            // 
            // BtnMsClick
            // 
            this.BtnMsClick.AllowDrop = true;
            this.BtnMsClick.AutoSize = true;
            this.BtnMsClick.Location = new System.Drawing.Point(628, 145);
            this.BtnMsClick.Name = "BtnMsClick";
            this.BtnMsClick.Size = new System.Drawing.Size(93, 26);
            this.BtnMsClick.TabIndex = 18;
            this.BtnMsClick.Text = "MouseClick";
            this.BtnMsClick.UseVisualStyleBackColor = true;
            this.BtnMsClick.Click += new System.EventHandler(this.BtnMsClick_Click);
            this.BtnMsClick.MouseClick += new System.Windows.Forms.MouseEventHandler(this.BtnMsClick_MouseClick);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(786, 342);
            this.Controls.Add(this.BtnMsClick);
            this.Controls.Add(this.BtnWinState);
            this.Controls.Add(this.BtnStarPos);
            this.Controls.Add(this.BtnLcnSize);
            this.Controls.Add(this.BtnHelp);
            this.Controls.Add(this.BtnMin);
            this.Controls.Add(this.BtnMax);
            this.Controls.Add(this.BtnTop);
            this.Controls.Add(this.BtnMinIcon);
            this.Controls.Add(this.BtnCtrlBox);
            this.Controls.Add(this.BtnText);
            this.Controls.Add(this.BtnBorder3);
            this.Controls.Add(this.BtnBorder2);
            this.Controls.Add(this.BtnBorder);
            this.Controls.Add(this.BtnFont);
            this.Controls.Add(this.BtnCursor);
            this.Controls.Add(this.BtnBGImage);
            this.Controls.Add(this.BtnBColor);
            this.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Form1";
            this.Text = "Form1";
            this.MouseClick += new System.Windows.Forms.MouseEventHandler(this.Form1_MouseClick);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button BtnBColor;
        private System.Windows.Forms.Button BtnBGImage;
        private System.Windows.Forms.Button BtnCursor;
        private System.Windows.Forms.Button BtnFont;
        private System.Windows.Forms.Button BtnBorder;
        private System.Windows.Forms.Button BtnBorder2;
        private System.Windows.Forms.Button BtnBorder3;
        private System.Windows.Forms.Button BtnText;
        private System.Windows.Forms.Button BtnCtrlBox;
        private System.Windows.Forms.Button BtnMinIcon;
        private System.Windows.Forms.Button BtnTop;
        private System.Windows.Forms.Button BtnMax;
        private System.Windows.Forms.Button BtnMin;
        private System.Windows.Forms.Button BtnHelp;
        private System.Windows.Forms.Button BtnLcnSize;
        private System.Windows.Forms.Button BtnStarPos;
        private System.Windows.Forms.Button BtnWinState;
        private System.Windows.Forms.Button BtnMsClick;
    }
}

