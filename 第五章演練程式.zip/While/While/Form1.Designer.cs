﻿namespace While
{
    partial class FrmWhl
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.BtnWhl1 = new System.Windows.Forms.Button();
            this.BtnWhl2 = new System.Windows.Forms.Button();
            this.BtnDoWhl1 = new System.Windows.Forms.Button();
            this.BtnDoWhl2 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // BtnWhl1
            // 
            this.BtnWhl1.AutoSize = true;
            this.BtnWhl1.Location = new System.Drawing.Point(30, 36);
            this.BtnWhl1.Name = "BtnWhl1";
            this.BtnWhl1.Size = new System.Drawing.Size(141, 34);
            this.BtnWhl1.TabIndex = 0;
            this.BtnWhl1.Text = "第一種while";
            this.BtnWhl1.UseVisualStyleBackColor = true;
            this.BtnWhl1.Click += new System.EventHandler(this.BtnWhl1_Click);
            // 
            // BtnWhl2
            // 
            this.BtnWhl2.AutoSize = true;
            this.BtnWhl2.Location = new System.Drawing.Point(30, 100);
            this.BtnWhl2.Name = "BtnWhl2";
            this.BtnWhl2.Size = new System.Drawing.Size(141, 34);
            this.BtnWhl2.TabIndex = 1;
            this.BtnWhl2.Text = "第二種while";
            this.BtnWhl2.UseVisualStyleBackColor = true;
            this.BtnWhl2.Click += new System.EventHandler(this.BtnWhl2_Click);
            // 
            // BtnDoWhl1
            // 
            this.BtnDoWhl1.AutoSize = true;
            this.BtnDoWhl1.Location = new System.Drawing.Point(218, 36);
            this.BtnDoWhl1.Name = "BtnDoWhl1";
            this.BtnDoWhl1.Size = new System.Drawing.Size(181, 34);
            this.BtnDoWhl1.TabIndex = 2;
            this.BtnDoWhl1.Text = "第一種do...while";
            this.BtnDoWhl1.UseVisualStyleBackColor = true;
            this.BtnDoWhl1.Click += new System.EventHandler(this.BtnDoWhl1_Click);
            // 
            // BtnDoWhl2
            // 
            this.BtnDoWhl2.AutoSize = true;
            this.BtnDoWhl2.Location = new System.Drawing.Point(218, 100);
            this.BtnDoWhl2.Name = "BtnDoWhl2";
            this.BtnDoWhl2.Size = new System.Drawing.Size(181, 34);
            this.BtnDoWhl2.TabIndex = 3;
            this.BtnDoWhl2.Text = "第二種do...while";
            this.BtnDoWhl2.UseVisualStyleBackColor = true;
            this.BtnDoWhl2.Click += new System.EventHandler(this.BtnDoWhl2_Click);
            // 
            // FrmWhl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(443, 163);
            this.Controls.Add(this.BtnDoWhl2);
            this.Controls.Add(this.BtnDoWhl1);
            this.Controls.Add(this.BtnWhl2);
            this.Controls.Add(this.BtnWhl1);
            this.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Margin = new System.Windows.Forms.Padding(6, 5, 6, 5);
            this.Name = "FrmWhl";
            this.Text = "四種前後測while";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button BtnWhl1;
        private System.Windows.Forms.Button BtnWhl2;
        private System.Windows.Forms.Button BtnDoWhl1;
        private System.Windows.Forms.Button BtnDoWhl2;
    }
}

