﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace While
{
    public partial class FrmWhl : Form
    {
        public FrmWhl()
        {
            InitializeComponent();
        }

        private void BtnWhl1_Click(object sender, EventArgs e)
        {
            //第一種while
            int i = 1, sum1 = 0;//迴圈初始值1，且加總初值
            while (i < 11)//只加到10
            {
                sum1 += i;//累加，先累加，再變i
                i++;//迴圈運算式改變計數變數或說條件運算式結果
            }
            MessageBox.Show("1+2+3+…+10=" + sum1);//訊息方塊顯示結果
        }

        private void BtnWhl2_Click(object sender, EventArgs e)
        {
            //第二種while，課本用法
            int j = 0, sum2 = 0;//迴圈初始值0，且加總初值
            while (j < 10)//加到10，因先j++，所以j只到9
            {
                j++;//迴圈運算式改變計數變數或說條件運算式結果
                sum2 += j;//累加，先變j，再累加
            }
            MessageBox.Show("1+2+3+…+10=" + sum2);//訊息方塊顯示結果
        }

        private void BtnDoWhl1_Click(object sender, EventArgs e)
        {
            //第一種do while
            int i = 1, sum1 = 0;//迴圈初始值1，且加總初值
            do
            {
                sum1 += i;//累加，先累加，再變i
                i++;//迴圈運算式改變計數變數或說條件運算式結果
            } while (i < 11);//只加到10
            MessageBox.Show("1+2+3+…+10=" + sum1);//訊息方塊顯示結果
        }

        private void BtnDoWhl2_Click(object sender, EventArgs e)
        {
            //第二種do while，課本用法
            int j = 0, sum2 = 0;//迴圈初始值0，且加總初值
            do
            {
                j++;//迴圈運算式改變計數變數或說條件運算式結果
                sum2 += j;//累加，先變j，再累加
            } while (j < 10);//加到10，因先j++，所以i只到9
            MessageBox.Show("1+2+3+…+10=" + sum2);//訊息方塊顯示結果
        }
    }
}
