﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;

namespace For
{
    public partial class FrmFor : Form
    {
        public FrmFor()
        {
            InitializeComponent();
        }

        private void BtnFor1_Click(object sender, EventArgs e)
        {
            int sum = 0;//給初值，一般累計值都要初始化
            for (int i = 1; i < 11; i++) sum += i;//條件運算式也可用i<=10
            MessageBox.Show("1+2+…+10=" + sum);//用訊息方塊輸出
            //i = 0;//i在for內，所以是區域變數，跳出大括號就無效
            /*{
                int k;
                sum = 0;
            }
            k=0;//刮號內變數，刮號外無效 */
        }

        private void BtnFor2_Click(object sender, EventArgs e)
        {
            int sum1 = 0, sum2 = 0;//累加前給初值，一般累計常必須給初值
            for (int i = 1, j = 10; i < 6 && j > 1; i++, j -= 2)//條件運算式i可改為i<=5，j改為j>=2
            {
                sum1 += i;//累加
                sum2 += j;
            }
            MessageBox.Show("1+2+3+4+5=" + sum1 + ", 10+8+6+4+2=" + sum2);//輸出，把兩個輸出串在一起
        }

        private void BtnStep_Click(object sender, EventArgs e)
        {
            float sum = 0;//給初值，0預設為整數，所以自動可以轉成float 
            for (int i = 1; i < 11; i++) //整數計數，但要轉換成累加的數值
            //for (float k = 0.5f; k <= 5; k+=0.5)//真接用累加的數值 
            {
                sum += (float)(i * 0.5);//整數乘0.5轉換成累加的值
              //sum += k;//直接是累加的值，所以直接累加
            }
            MessageBox.Show("0.5+1+1.5+…+5=" + sum);//用訊息方塊輸出
        }

        Thread InfinThrd;
        private void BtnInfinLoop_Click(object sender, EventArgs e)
        {//用另一個執行緒跑無窮迴圈，免得來程式執行緒被鎖住，完全無法動作
                InfinThrd = new Thread(new ThreadStart(InfinLoop));//定義新執行緒InfinThrd執行自訂程序InfinLoop
            InfinThrd.Start();//執行緒InfinThrd啟動
        }

        private void InfinLoop()
        {//執行緒InfinThrd所執行的自訂程序
            long j = 0;
            for (int i = 0; i % 5 == 0; i += 5)//條件運算式永遠成立，構成無窮迴圈
            {
                j++;//算迴圈次數
                Lbli.InvokeIfRequired(() =>
                {
                    Lbli.Text = "現在計數(i,j)=(" + i + "," + j + ")";//秀出計數j，比較知道迴圈有在動
                });//控制項Lbli跨執行緒作業無效，Lbli是在原執行緒，此程序是在新執行緒InfinThrd，所以需使用擴充方法InvokeIfRequired，定義在最下面
                Thread.Sleep(250);//程式睡覺即暫停1/4秒，不然會太快
            }
        }

        private void BtnStop_Click(object sender, EventArgs e)
        {
            InfinThrd.Abort();//執行緒InfinThrd終止
        }

        //同上手法，這次無窮迴圈是for未寫迴圈式
        Thread InfinThrd2;
        private void BtnInfinLoop2_Click(object sender, EventArgs e)
        {
            InfinThrd2 = new Thread(new ThreadStart(InfinLoop2));
            InfinThrd2.Start();
        }

        private void InfinLoop2()
        {
            long j = 0;
            for (int i = 0; i < 5;)//未寫迴圈運算式，構成無窮迴圈
            {
                j++;
                Lbli2.InvokeIfRequired(() =>
                {
                    Lbli2.Text = "現在計數(i,j)=(" + i + "," + j + ")";//秀出計數j，比較知道迴圈有在動
                });
                Thread.Sleep(250);//程式睡覺即暫停1/4秒，不然會太快
            }
        }

        private void BtnStop2_Click(object sender, EventArgs e)
        {
            InfinThrd2.Abort();
        }

        private void BtnMulBrk_Click(object sender, EventArgs e)
        {
            for (int i = 0, j = 100; i < 30 || j > 80; i++, j-=2)
            {
                LblMul.Text = "乘積=" + i * j + "。(i,j)=(" + i + "," + j + ")";
                Thread.Sleep(250);//程式睡覺即暫停，不然會太快
                //Refresh();//要求即時更新畫面的方法
                if (i + j < 80) { MessageBox.Show("(i,j)=(" + i + "," + j + ")"); break; }
            }
        }

        Thread InfinThrd3;
        private void BtnNestFor_Click(object sender, EventArgs e)
        {
            InfinThrd3 = new Thread(new ThreadStart(NestFor));
            InfinThrd3.Start();
        }

        private void NestFor()
        {
            for (int i = 0; i < 5; i++)
            {
                for (int j = 0; j < 4; j++)
                {
                    LblNest.InvokeIfRequired(() =>
                    {
                        LblNest.Text = "第" + (i * 4 + (j + 1)) + "次，外圈i=" + i + "，內圈j=" + j;//秀出第幾輪、內圈計數i及外圈計數j
                    });
                    Thread.Sleep(1000);//程式睡覺即暫停，不然會太快
                    //Refresh();//這是未用thread時要求即時更新畫面的方法
                }
            }
        }
    }

    //擴充方法
    public static class Extension
    {
        //非同步委派更新UI
        public static void InvokeIfRequired(this Control control, MethodInvoker action)
        {
            if (control.InvokeRequired)//在非當前執行緒內 使用委派
            {
                control.Invoke(action);
            }
            else
            {
                action();
            }
        }
    }
}
