﻿namespace For
{
    partial class FrmFor
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.BtnInfinLoop = new System.Windows.Forms.Button();
            this.Lbli = new System.Windows.Forms.Label();
            this.BtnStop = new System.Windows.Forms.Button();
            this.BtnInfinLoop2 = new System.Windows.Forms.Button();
            this.BtnStop2 = new System.Windows.Forms.Button();
            this.Lbli2 = new System.Windows.Forms.Label();
            this.BtnMulBrk = new System.Windows.Forms.Button();
            this.LblMul = new System.Windows.Forms.Label();
            this.BtnNestFor = new System.Windows.Forms.Button();
            this.LblNest = new System.Windows.Forms.Label();
            this.BtnStep = new System.Windows.Forms.Button();
            this.BtnFor2 = new System.Windows.Forms.Button();
            this.BtnFor1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // BtnInfinLoop
            // 
            this.BtnInfinLoop.AutoSize = true;
            this.BtnInfinLoop.Location = new System.Drawing.Point(36, 82);
            this.BtnInfinLoop.Name = "BtnInfinLoop";
            this.BtnInfinLoop.Size = new System.Drawing.Size(180, 34);
            this.BtnInfinLoop.TabIndex = 0;
            this.BtnInfinLoop.Text = "無窮迴圈(條件)";
            this.BtnInfinLoop.UseVisualStyleBackColor = true;
            this.BtnInfinLoop.Click += new System.EventHandler(this.BtnInfinLoop_Click);
            // 
            // Lbli
            // 
            this.Lbli.AutoSize = true;
            this.Lbli.Location = new System.Drawing.Point(308, 88);
            this.Lbli.Name = "Lbli";
            this.Lbli.Size = new System.Drawing.Size(70, 16);
            this.Lbli.TabIndex = 1;
            this.Lbli.Text = "計數(i,j)=";
            // 
            // BtnStop
            // 
            this.BtnStop.AutoSize = true;
            this.BtnStop.Location = new System.Drawing.Point(222, 82);
            this.BtnStop.Name = "BtnStop";
            this.BtnStop.Size = new System.Drawing.Size(75, 34);
            this.BtnStop.TabIndex = 2;
            this.BtnStop.Text = "停止";
            this.BtnStop.UseVisualStyleBackColor = true;
            this.BtnStop.Click += new System.EventHandler(this.BtnStop_Click);
            // 
            // BtnInfinLoop2
            // 
            this.BtnInfinLoop2.AutoSize = true;
            this.BtnInfinLoop2.Location = new System.Drawing.Point(36, 138);
            this.BtnInfinLoop2.Name = "BtnInfinLoop2";
            this.BtnInfinLoop2.Size = new System.Drawing.Size(180, 34);
            this.BtnInfinLoop2.TabIndex = 3;
            this.BtnInfinLoop2.Text = "無窮迴圈(迴圈)";
            this.BtnInfinLoop2.UseVisualStyleBackColor = true;
            this.BtnInfinLoop2.Click += new System.EventHandler(this.BtnInfinLoop2_Click);
            // 
            // BtnStop2
            // 
            this.BtnStop2.AutoSize = true;
            this.BtnStop2.Location = new System.Drawing.Point(222, 138);
            this.BtnStop2.Name = "BtnStop2";
            this.BtnStop2.Size = new System.Drawing.Size(75, 34);
            this.BtnStop2.TabIndex = 4;
            this.BtnStop2.Text = "停止";
            this.BtnStop2.UseVisualStyleBackColor = true;
            this.BtnStop2.Click += new System.EventHandler(this.BtnStop2_Click);
            // 
            // Lbli2
            // 
            this.Lbli2.AutoSize = true;
            this.Lbli2.Location = new System.Drawing.Point(308, 142);
            this.Lbli2.Name = "Lbli2";
            this.Lbli2.Size = new System.Drawing.Size(70, 16);
            this.Lbli2.TabIndex = 5;
            this.Lbli2.Text = "計數(i,j)=";
            // 
            // BtnMulBrk
            // 
            this.BtnMulBrk.AutoSize = true;
            this.BtnMulBrk.Location = new System.Drawing.Point(36, 196);
            this.BtnMulBrk.Name = "BtnMulBrk";
            this.BtnMulBrk.Size = new System.Drawing.Size(180, 34);
            this.BtnMulBrk.TabIndex = 6;
            this.BtnMulBrk.Text = "多條件及break";
            this.BtnMulBrk.UseVisualStyleBackColor = true;
            this.BtnMulBrk.Click += new System.EventHandler(this.BtnMulBrk_Click);
            // 
            // LblMul
            // 
            this.LblMul.AutoSize = true;
            this.LblMul.Location = new System.Drawing.Point(243, 202);
            this.LblMul.Name = "LblMul";
            this.LblMul.Size = new System.Drawing.Size(48, 16);
            this.LblMul.TabIndex = 7;
            this.LblMul.Text = "乘積=";
            // 
            // BtnNestFor
            // 
            this.BtnNestFor.AutoSize = true;
            this.BtnNestFor.Location = new System.Drawing.Point(36, 251);
            this.BtnNestFor.Name = "BtnNestFor";
            this.BtnNestFor.Size = new System.Drawing.Size(180, 34);
            this.BtnNestFor.TabIndex = 8;
            this.BtnNestFor.Text = "巢式外5內4";
            this.BtnNestFor.UseVisualStyleBackColor = true;
            this.BtnNestFor.Click += new System.EventHandler(this.BtnNestFor_Click);
            // 
            // LblNest
            // 
            this.LblNest.AutoSize = true;
            this.LblNest.Location = new System.Drawing.Point(243, 257);
            this.LblNest.Name = "LblNest";
            this.LblNest.Size = new System.Drawing.Size(72, 16);
            this.LblNest.TabIndex = 9;
            this.LblNest.Text = "迴圈計數";
            // 
            // BtnStep
            // 
            this.BtnStep.AutoSize = true;
            this.BtnStep.Location = new System.Drawing.Point(252, 25);
            this.BtnStep.Name = "BtnStep";
            this.BtnStep.Size = new System.Drawing.Size(140, 34);
            this.BtnStep.TabIndex = 12;
            this.BtnStep.Text = "非整數步階";
            this.BtnStep.UseVisualStyleBackColor = true;
            this.BtnStep.Click += new System.EventHandler(this.BtnStep_Click);
            // 
            // BtnFor2
            // 
            this.BtnFor2.AutoSize = true;
            this.BtnFor2.Location = new System.Drawing.Point(145, 25);
            this.BtnFor2.Name = "BtnFor2";
            this.BtnFor2.Size = new System.Drawing.Size(95, 34);
            this.BtnFor2.TabIndex = 11;
            this.BtnFor2.Text = "二個for";
            this.BtnFor2.UseVisualStyleBackColor = true;
            this.BtnFor2.Click += new System.EventHandler(this.BtnFor2_Click);
            // 
            // BtnFor1
            // 
            this.BtnFor1.AutoSize = true;
            this.BtnFor1.Location = new System.Drawing.Point(38, 25);
            this.BtnFor1.Name = "BtnFor1";
            this.BtnFor1.Size = new System.Drawing.Size(95, 34);
            this.BtnFor1.TabIndex = 10;
            this.BtnFor1.Text = "一個for";
            this.BtnFor1.UseVisualStyleBackColor = true;
            this.BtnFor1.Click += new System.EventHandler(this.BtnFor1_Click);
            // 
            // FrmFor
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(539, 309);
            this.Controls.Add(this.BtnStep);
            this.Controls.Add(this.BtnFor2);
            this.Controls.Add(this.BtnFor1);
            this.Controls.Add(this.LblNest);
            this.Controls.Add(this.BtnNestFor);
            this.Controls.Add(this.LblMul);
            this.Controls.Add(this.BtnMulBrk);
            this.Controls.Add(this.Lbli2);
            this.Controls.Add(this.BtnStop2);
            this.Controls.Add(this.BtnInfinLoop2);
            this.Controls.Add(this.BtnStop);
            this.Controls.Add(this.Lbli);
            this.Controls.Add(this.BtnInfinLoop);
            this.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "FrmFor";
            this.Text = "FrmFor";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button BtnInfinLoop;
        private System.Windows.Forms.Label Lbli;
        private System.Windows.Forms.Button BtnStop;
        private System.Windows.Forms.Button BtnInfinLoop2;
        private System.Windows.Forms.Button BtnStop2;
        private System.Windows.Forms.Label Lbli2;
        private System.Windows.Forms.Button BtnMulBrk;
        private System.Windows.Forms.Label LblMul;
        private System.Windows.Forms.Button BtnNestFor;
        private System.Windows.Forms.Label LblNest;
        private System.Windows.Forms.Button BtnStep;
        private System.Windows.Forms.Button BtnFor2;
        private System.Windows.Forms.Button BtnFor1;
    }
}

