﻿namespace TmrDemo
{
    partial class FrmTmrDemo
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.BtnEnable = new System.Windows.Forms.Button();
            this.BtnIntvl = new System.Windows.Forms.Button();
            this.LblShow = new System.Windows.Forms.Label();
            this.Tmr = new System.Windows.Forms.Timer(this.components);
            this.BtnStart = new System.Windows.Forms.Button();
            this.BtnStop = new System.Windows.Forms.Button();
            this.LblEnabled = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // BtnEnable
            // 
            this.BtnEnable.AutoSize = true;
            this.BtnEnable.Location = new System.Drawing.Point(37, 30);
            this.BtnEnable.Name = "BtnEnable";
            this.BtnEnable.Size = new System.Drawing.Size(75, 34);
            this.BtnEnable.TabIndex = 0;
            this.BtnEnable.Text = "作動";
            this.BtnEnable.UseVisualStyleBackColor = true;
            this.BtnEnable.Click += new System.EventHandler(this.BtnEnable_Click);
            // 
            // BtnIntvl
            // 
            this.BtnIntvl.AutoSize = true;
            this.BtnIntvl.Location = new System.Drawing.Point(37, 89);
            this.BtnIntvl.Name = "BtnIntvl";
            this.BtnIntvl.Size = new System.Drawing.Size(75, 34);
            this.BtnIntvl.TabIndex = 1;
            this.BtnIntvl.Text = "週期";
            this.BtnIntvl.UseVisualStyleBackColor = true;
            this.BtnIntvl.Click += new System.EventHandler(this.BtnIntvl_Click);
            // 
            // LblShow
            // 
            this.LblShow.AutoSize = true;
            this.LblShow.Location = new System.Drawing.Point(207, 38);
            this.LblShow.Name = "LblShow";
            this.LblShow.Size = new System.Drawing.Size(0, 16);
            this.LblShow.TabIndex = 3;
            // 
            // Tmr
            // 
            this.Tmr.Tick += new System.EventHandler(this.Tmr_Tick);
            // 
            // BtnStart
            // 
            this.BtnStart.AutoSize = true;
            this.BtnStart.Location = new System.Drawing.Point(132, 89);
            this.BtnStart.Name = "BtnStart";
            this.BtnStart.Size = new System.Drawing.Size(75, 34);
            this.BtnStart.TabIndex = 5;
            this.BtnStart.Text = "啟動";
            this.BtnStart.UseVisualStyleBackColor = true;
            this.BtnStart.Click += new System.EventHandler(this.BtnStart_Click);
            // 
            // BtnStop
            // 
            this.BtnStop.AutoSize = true;
            this.BtnStop.Location = new System.Drawing.Point(228, 89);
            this.BtnStop.Name = "BtnStop";
            this.BtnStop.Size = new System.Drawing.Size(75, 34);
            this.BtnStop.TabIndex = 6;
            this.BtnStop.Text = "停止";
            this.BtnStop.UseVisualStyleBackColor = true;
            this.BtnStop.Click += new System.EventHandler(this.BtnStop_Click);
            // 
            // LblEnabled
            // 
            this.LblEnabled.AutoSize = true;
            this.LblEnabled.Location = new System.Drawing.Point(129, 39);
            this.LblEnabled.Name = "LblEnabled";
            this.LblEnabled.Size = new System.Drawing.Size(0, 16);
            this.LblEnabled.TabIndex = 7;
            // 
            // FrmTmrDemo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(338, 146);
            this.Controls.Add(this.LblEnabled);
            this.Controls.Add(this.BtnStop);
            this.Controls.Add(this.BtnStart);
            this.Controls.Add(this.LblShow);
            this.Controls.Add(this.BtnIntvl);
            this.Controls.Add(this.BtnEnable);
            this.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "FrmTmrDemo";
            this.Text = "計時器示範";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button BtnEnable;
        private System.Windows.Forms.Button BtnIntvl;
        private System.Windows.Forms.Label LblShow;
        private System.Windows.Forms.Timer Tmr;
        private System.Windows.Forms.Button BtnStart;
        private System.Windows.Forms.Button BtnStop;
        private System.Windows.Forms.Label LblEnabled;
    }
}

