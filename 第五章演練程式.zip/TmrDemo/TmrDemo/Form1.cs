﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TmrDemo
{
    public partial class FrmTmrDemo : Form
    {
        public FrmTmrDemo()
        {
            InitializeComponent();
        }

        private void BtnEnable_Click(object sender, EventArgs e)
        {//採on-off作法，且秀出目前屬性值
            Tmr.Enabled = !Tmr.Enabled;
            LblEnabled.Text = Tmr.Enabled.ToString();
        }

        private void BtnIntvl_Click(object sender, EventArgs e)
        {
            double Intval;
            do
            {//輸入處理的SOP，空字串或取消則回表單，否則判斷是否有例外。有例外則警示並重來，無則判斷是否符合範圍。不在範圍則警示並重來，在則動作
                string StrIn = Microsoft.VisualBasic.Interaction.InputBox("請輸入週期時間（秒，最多小數3位）");
                if (StrIn == "")
                {//看輸入是否空字串或取消，是則結束，返回表單
                    MessageBox.Show("輸入空字串或按取消，故結束此程序");
                    return;
                }
                else
                {
                    try { Intval = Convert.ToDouble(StrIn); }
                    catch { MessageBox.Show("輸入非數值，請重新輸入"); continue; }
                }
                //確定整數則判斷是否超出範圍，是則警示（並進行下一輪迴圈，不用continue，因為後面無敘述）
                if (Intval <= 0) { MessageBox.Show("輸入非正值，請重新輸入"); continue; }//continue可以不用寫，因為已是迴圈最後了，沒寫一樣會進行下一輪
                else { Tmr.Interval = (int)(Intval*1000); break; }//輸入符合則指定給計時器並跳出迴圈
            } while (true);
        }

        private void Tmr_Tick(object sender, EventArgs e)
        {//秀出現在時間
            LblShow.Text = DateTime.Now.ToLongTimeString();
        }

        private void BtnStart_Click(object sender, EventArgs e)
        {//啟動並顯示Enabled屬性值
            Tmr.Start();
            LblEnabled.Text = Tmr.Enabled.ToString();
        }

        private void BtnStop_Click(object sender, EventArgs e)
        {//停止並顯示Enabled屬性值
            Tmr.Stop();
            LblEnabled.Text = Tmr.Enabled.ToString();
        }
    }
}
